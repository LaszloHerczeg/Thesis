import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { authService, configService } from "@/api";
import type { AppSettings, LoginRequest, RegisterRequest, User } from "@/api/types";

interface AppState {
  ready: boolean;
  bootError: boolean;
  user: User | null;
  settings: AppSettings | null;
  setUser: (u: User | null) => void;
  login: (body: LoginRequest) => Promise<User>;
  register: (body: RegisterRequest) => Promise<User>;
  logout: () => Promise<void>;
  reload: () => void;
}

const Ctx = createContext<AppState | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);
  const [bootError, setBootError] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [settings, setSettings] = useState<AppSettings | null>(null);
  const [nonce, setNonce] = useState(0);

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        await authService.csrf();
        const [s, me] = await Promise.all([configService.get(), authService.me()]);
        if (!alive) return;
        setSettings(s);
        setUser(me);
        setBootError(false);
      } catch {
        if (alive) setBootError(true);
      } finally {
        if (alive) setReady(true);
      }
    })();
    return () => {
      alive = false;
    };
  }, [nonce]);

  const login = useCallback(async (body: LoginRequest) => {
    const u = await authService.login(body);
    setUser(u);
    return u;
  }, []);
  const register = useCallback(async (body: RegisterRequest) => {
    const u = await authService.register(body);
    setUser(u);
    return u;
  }, []);
  const logout = useCallback(async () => {
    try {
      await authService.logout();
    } finally {
      setUser(null);
    }
  }, []);

  const value = useMemo<AppState>(
    () => ({ ready, bootError, user, settings, setUser, login, register, logout, reload: () => setNonce((n) => n + 1) }),
    [ready, bootError, user, settings, login, register, logout],
  );
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useApp(): AppState {
  const v = useContext(Ctx);
  if (!v) throw new Error("useApp outside AppProvider");
  return v;
}

/** Settings are guaranteed once the app shell has booted. */
export function useSettings(): AppSettings {
  const s = useApp().settings;
  if (!s) throw new Error("settings not loaded");
  return s;
}
