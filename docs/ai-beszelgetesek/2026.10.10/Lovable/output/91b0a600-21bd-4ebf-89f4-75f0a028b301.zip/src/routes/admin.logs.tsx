import { createFileRoute } from "@tanstack/react-router";
import { AdminLogsPage } from "@/pages/admin/AdminPages";

export const Route = createFileRoute("/admin/logs")({
  head: () => ({
    meta: [
      { title: "Naplók – Jogútmutató" },
      { name: "description", content: "Naplók." },
      { property: "og:title", content: "Naplók – Jogútmutató" },
      { property: "og:description", content: "Naplók." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return <AdminLogsPage />;
}
