import { createFileRoute } from "@tanstack/react-router";
import { NewScreeningPage } from "@/pages/screening/ScreeningPages";

export const Route = createFileRoute("/screening/")({
  head: () => ({
    meta: [
      { title: "Felmérés – Jogútmutató" },
      { name: "description", content: "Jogi probléma felmérése lépésről lépésre." },
      { property: "og:title", content: "Felmérés – Jogútmutató" },
      { property: "og:description", content: "Jogi probléma felmérése lépésről lépésre." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return <NewScreeningPage />;
}
