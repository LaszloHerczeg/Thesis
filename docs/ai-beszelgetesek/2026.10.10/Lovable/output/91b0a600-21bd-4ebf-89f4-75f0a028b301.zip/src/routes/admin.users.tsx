import { createFileRoute } from "@tanstack/react-router";
import { AdminUsersPage } from "@/pages/admin/AdminPages";

export const Route = createFileRoute("/admin/users")({
  head: () => ({
    meta: [
      { title: "Felhasználók – Jogútmutató" },
      { name: "description", content: "Felhasználók." },
      { property: "og:title", content: "Felhasználók – Jogútmutató" },
      { property: "og:description", content: "Felhasználók." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return <AdminUsersPage />;
}
