import { createFileRoute } from "@tanstack/react-router";
import { AccountStatusPage } from "@/pages/InfoPages";

export const Route = createFileRoute("/account-status")({
  head: () => ({
    meta: [
      { title: "Fiók állapota – Jogútmutató" },
      { name: "description", content: "Fiókja jelenleg nem használható." },
      { property: "og:title", content: "Fiók állapota – Jogútmutató" },
      { property: "og:description", content: "Fiókja jelenleg nem használható." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return <AccountStatusPage />;
}
