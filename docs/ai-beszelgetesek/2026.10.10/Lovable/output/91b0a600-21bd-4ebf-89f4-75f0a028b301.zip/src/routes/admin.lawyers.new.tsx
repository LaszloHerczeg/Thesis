import { createFileRoute } from "@tanstack/react-router";
import { AdminLawyerNewPage } from "@/pages/admin/AdminPages";

export const Route = createFileRoute("/admin/lawyers/new")({
  head: () => ({
    meta: [
      { title: "Új ügyvéd – Jogútmutató" },
      { name: "description", content: "Új ügyvédprofil létrehozása." },
      { property: "og:title", content: "Új ügyvéd – Jogútmutató" },
      { property: "og:description", content: "Új ügyvédprofil létrehozása." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return <AdminLawyerNewPage />;
}
