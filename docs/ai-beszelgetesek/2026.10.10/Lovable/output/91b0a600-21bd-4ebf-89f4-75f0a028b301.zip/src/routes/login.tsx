import { createFileRoute } from "@tanstack/react-router";
import { LoginPage } from "@/pages/AuthPages";
import type { AuthSearch } from "@/pages/AuthPages";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Bejelentkezés – Jogútmutató" },
      { name: "description", content: "Jelentkezzen be fiókjába." },
      { property: "og:title", content: "Bejelentkezés – Jogútmutató" },
      { property: "og:description", content: "Jelentkezzen be fiókjába." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  validateSearch: (s: Record<string, unknown>): AuthSearch => ({
    redirect: typeof s["redirect"] === "string" ? s["redirect"] : undefined,
    from: s["from"] === "screening" ? "screening" : undefined,
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return <LoginPage search={Route.useSearch()} />;
}
