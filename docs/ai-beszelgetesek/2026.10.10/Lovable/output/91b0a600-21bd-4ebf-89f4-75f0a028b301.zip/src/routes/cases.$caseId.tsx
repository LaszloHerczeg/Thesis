import { createFileRoute } from "@tanstack/react-router";
import { CaseDetailPage } from "@/pages/cases/CasePages";

export const Route = createFileRoute("/cases/$caseId")({
  head: () => ({
    meta: [
      { title: "Ügy részletei – Jogútmutató" },
      { name: "description", content: "Ügy részletei és ajánlott ügyvédek." },
      { property: "og:title", content: "Ügy részletei – Jogútmutató" },
      { property: "og:description", content: "Ügy részletei és ajánlott ügyvédek." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return <CaseDetailPage caseId={Route.useParams().caseId} />;
}
