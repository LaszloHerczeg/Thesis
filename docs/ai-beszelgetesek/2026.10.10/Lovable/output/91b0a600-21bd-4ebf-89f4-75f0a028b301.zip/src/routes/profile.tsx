import { createFileRoute } from "@tanstack/react-router";
import { ProfilePage } from "@/pages/ProfilePage";

export const Route = createFileRoute("/profile")({
  head: () => ({
    meta: [
      { title: "Profil – Jogútmutató" },
      { name: "description", content: "Profil, jelszó és adatkezelési beállítások." },
      { property: "og:title", content: "Profil – Jogútmutató" },
      { property: "og:description", content: "Profil, jelszó és adatkezelési beállítások." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return <ProfilePage />;
}
