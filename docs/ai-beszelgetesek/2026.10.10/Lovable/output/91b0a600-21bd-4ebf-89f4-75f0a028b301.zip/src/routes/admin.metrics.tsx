import { createFileRoute } from "@tanstack/react-router";
import { AdminMetricsPage } from "@/pages/admin/MetricsPage";

export const Route = createFileRoute("/admin/metrics")({
  head: () => ({
    meta: [
      { title: "Metrikák – Jogútmutató" },
      { name: "description", content: "Besorolási pontosság." },
      { property: "og:title", content: "Metrikák – Jogútmutató" },
      { property: "og:description", content: "Besorolási pontosság." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return <AdminMetricsPage />;
}
