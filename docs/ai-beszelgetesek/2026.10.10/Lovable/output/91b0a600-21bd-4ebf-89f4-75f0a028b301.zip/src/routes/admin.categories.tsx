import { createFileRoute } from "@tanstack/react-router";
import { AdminCategoriesPage } from "@/pages/admin/AdminPages";

export const Route = createFileRoute("/admin/categories")({
  head: () => ({
    meta: [
      { title: "Kategóriák – Jogútmutató" },
      { name: "description", content: "Jogi kategóriák kezelése." },
      { property: "og:title", content: "Kategóriák – Jogútmutató" },
      { property: "og:description", content: "Jogi kategóriák kezelése." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return <AdminCategoriesPage />;
}
