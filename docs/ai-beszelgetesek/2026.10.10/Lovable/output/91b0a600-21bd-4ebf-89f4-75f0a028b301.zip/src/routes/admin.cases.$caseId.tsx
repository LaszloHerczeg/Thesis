import { createFileRoute } from "@tanstack/react-router";
import { AdminCaseDetailPage } from "@/pages/admin/AdminPages";

export const Route = createFileRoute("/admin/cases/$caseId")({
  head: () => ({
    meta: [
      { title: "Ügy – Jogútmutató admin" },
      { name: "description", content: "Ügy csak olvasható nézete." },
      { property: "og:title", content: "Ügy – Jogútmutató admin" },
      { property: "og:description", content: "Ügy csak olvasható nézete." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return <AdminCaseDetailPage caseId={Route.useParams().caseId} />;
}
