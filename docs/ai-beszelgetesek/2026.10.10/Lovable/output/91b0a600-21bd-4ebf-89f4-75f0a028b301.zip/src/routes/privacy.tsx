import { createFileRoute } from "@tanstack/react-router";
import { PrivacyPage } from "@/pages/InfoPages";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title: "Adatkezelési tájékoztató – Jogútmutató" },
      { name: "description", content: "Hogyan kezeljük személyes adatait." },
      { property: "og:title", content: "Adatkezelési tájékoztató – Jogútmutató" },
      { property: "og:description", content: "Hogyan kezeljük személyes adatait." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return <PrivacyPage />;
}
