import { createFileRoute } from "@tanstack/react-router";
import { LawyerDirectoryPage } from "@/pages/cases/CasePages";

export const Route = createFileRoute("/lawyers")({
  head: () => ({
    meta: [
      { title: "Ügyvédek – Jogútmutató" },
      { name: "description", content: "Az összes aktív ügyvéd a platformon." },
      { property: "og:title", content: "Ügyvédek – Jogútmutató" },
      { property: "og:description", content: "Az összes aktív ügyvéd a platformon." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return <LawyerDirectoryPage />;
}
