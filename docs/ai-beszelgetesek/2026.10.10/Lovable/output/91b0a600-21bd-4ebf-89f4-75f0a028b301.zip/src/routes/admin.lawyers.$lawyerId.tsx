import { createFileRoute } from "@tanstack/react-router";
import { AdminLawyerEditPage } from "@/pages/admin/AdminPages";

export const Route = createFileRoute("/admin/lawyers/$lawyerId")({
  head: () => ({
    meta: [
      { title: "Ügyvéd szerkesztése – Jogútmutató" },
      { name: "description", content: "Ügyvédprofil szerkesztése." },
      { property: "og:title", content: "Ügyvéd szerkesztése – Jogútmutató" },
      { property: "og:description", content: "Ügyvédprofil szerkesztése." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return <AdminLawyerEditPage lawyerId={Route.useParams().lawyerId} />;
}
