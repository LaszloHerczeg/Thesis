import { createFileRoute } from "@tanstack/react-router";
import { DisclaimerPage } from "@/pages/InfoPages";

export const Route = createFileRoute("/disclaimer")({
  head: () => ({
    meta: [
      { title: "Jogi nyilatkozat – Jogútmutató" },
      { name: "description", content: "A Jogútmutató szolgáltatás jogi nyilatkozata." },
      { property: "og:title", content: "Jogi nyilatkozat – Jogútmutató" },
      { property: "og:description", content: "A Jogútmutató szolgáltatás jogi nyilatkozata." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return <DisclaimerPage />;
}
