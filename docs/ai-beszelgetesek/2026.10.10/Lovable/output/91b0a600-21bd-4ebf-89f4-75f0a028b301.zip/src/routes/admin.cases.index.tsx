import { createFileRoute } from "@tanstack/react-router";
import { AdminCasesPage } from "@/pages/admin/AdminPages";

export const Route = createFileRoute("/admin/cases/")({
  head: () => ({
    meta: [
      { title: "Ügyek – Jogútmutató admin" },
      { name: "description", content: "Összes ügy szűrése." },
      { property: "og:title", content: "Ügyek – Jogútmutató admin" },
      { property: "og:description", content: "Összes ügy szűrése." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return <AdminCasesPage />;
}
