import { createFileRoute } from "@tanstack/react-router";
import { ScreeningCasePage } from "@/pages/screening/ScreeningPages";

export const Route = createFileRoute("/screening/$caseId")({
  head: () => ({
    meta: [
      { title: "Felmérés folytatása – Jogútmutató" },
      { name: "description", content: "Folytassa a megkezdett felmérést." },
      { property: "og:title", content: "Felmérés folytatása – Jogútmutató" },
      { property: "og:description", content: "Folytassa a megkezdett felmérést." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return <ScreeningCasePage caseId={Route.useParams().caseId} />;
}
