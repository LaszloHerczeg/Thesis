import { createFileRoute } from "@tanstack/react-router";
import { ForgotPasswordPage } from "@/pages/InfoPages";

export const Route = createFileRoute("/forgot-password")({
  head: () => ({
    meta: [
      { title: "Elfelejtett jelszó – Jogútmutató" },
      { name: "description", content: "Jelszó visszaállítása." },
      { property: "og:title", content: "Elfelejtett jelszó – Jogútmutató" },
      { property: "og:description", content: "Jelszó visszaállítása." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return <ForgotPasswordPage />;
}
