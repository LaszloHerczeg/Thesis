import { createFileRoute } from "@tanstack/react-router";
import { HomePage } from "@/pages/HomePage";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Jogútmutató – Jogi probléma felmérése és ügyvédkeresés" },
      { name: "description", content: "Írja le jogi problémáját saját szavaival, és ajánlunk három Önhöz illő ügyvédet." },
      { property: "og:title", content: "Jogútmutató – Jogi probléma felmérése és ügyvédkeresés" },
      { property: "og:description", content: "Írja le jogi problémáját saját szavaival, és ajánlunk három Önhöz illő ügyvédet." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return <HomePage />;
}
