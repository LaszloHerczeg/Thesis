import { createFileRoute } from "@tanstack/react-router";
import { MyCasesPage } from "@/pages/cases/CasePages";

export const Route = createFileRoute("/cases/")({
  head: () => ({
    meta: [
      { title: "Ügyeim – Jogútmutató" },
      { name: "description", content: "Korábbi és folyamatban lévő ügyei." },
      { property: "og:title", content: "Ügyeim – Jogútmutató" },
      { property: "og:description", content: "Korábbi és folyamatban lévő ügyei." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return <MyCasesPage />;
}
