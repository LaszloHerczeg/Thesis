import { createFileRoute } from "@tanstack/react-router";
import { RegisterPage } from "@/pages/AuthPages";
import type { AuthSearch } from "@/pages/AuthPages";

export const Route = createFileRoute("/register")({
  head: () => ({
    meta: [
      { title: "Regisztráció – Jogútmutató" },
      { name: "description", content: "Hozzon létre fiókot a jogi szűrőszolgáltatás használatához." },
      { property: "og:title", content: "Regisztráció – Jogútmutató" },
      { property: "og:description", content: "Hozzon létre fiókot a jogi szűrőszolgáltatás használatához." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  validateSearch: (s: Record<string, unknown>): AuthSearch => ({
    redirect: typeof s["redirect"] === "string" ? s["redirect"] : undefined,
    from: s["from"] === "screening" ? "screening" : undefined,
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return <RegisterPage search={Route.useSearch()} />;
}
