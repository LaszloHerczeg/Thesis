import { createFileRoute } from "@tanstack/react-router";
import { AdminDashboardPage } from "@/pages/admin/AdminPages";

export const Route = createFileRoute("/admin/")({
  head: () => ({
    meta: [
      { title: "Admin – Jogútmutató" },
      { name: "description", content: "Adminisztrációs áttekintés." },
      { property: "og:title", content: "Admin – Jogútmutató" },
      { property: "og:description", content: "Adminisztrációs áttekintés." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return <AdminDashboardPage />;
}
