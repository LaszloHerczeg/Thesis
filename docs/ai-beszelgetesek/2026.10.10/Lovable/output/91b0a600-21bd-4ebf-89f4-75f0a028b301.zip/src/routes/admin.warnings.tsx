import { createFileRoute } from "@tanstack/react-router";
import { AdminWarningsPage } from "@/pages/admin/AdminPages";

export const Route = createFileRoute("/admin/warnings")({
  head: () => ({
    meta: [
      { title: "Figyelmeztetések – Jogútmutató" },
      { name: "description", content: "Figyelmeztetések." },
      { property: "og:title", content: "Figyelmeztetések – Jogútmutató" },
      { property: "og:description", content: "Figyelmeztetések." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return <AdminWarningsPage />;
}
