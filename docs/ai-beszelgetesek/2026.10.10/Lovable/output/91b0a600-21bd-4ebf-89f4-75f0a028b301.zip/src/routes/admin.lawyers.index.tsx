import { createFileRoute } from "@tanstack/react-router";
import { AdminLawyersPage } from "@/pages/admin/AdminPages";

export const Route = createFileRoute("/admin/lawyers/")({
  head: () => ({
    meta: [
      { title: "Ügyvédek kezelése – Jogútmutató" },
      { name: "description", content: "Ügyvédprofilok kezelése." },
      { property: "og:title", content: "Ügyvédek kezelése – Jogútmutató" },
      { property: "og:description", content: "Ügyvédprofilok kezelése." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return <AdminLawyersPage />;
}
