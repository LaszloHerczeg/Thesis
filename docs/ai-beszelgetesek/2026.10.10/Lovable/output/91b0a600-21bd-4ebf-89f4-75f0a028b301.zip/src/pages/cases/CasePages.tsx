import { Link, useRouter } from "@tanstack/react-router";
import { useState } from "react";
import { casesService, categoriesService, lawyersService } from "@/api";
import type { CaseDetail, CaseStatus, CaseSummary } from "@/api/types";
import { CASE_STATUSES } from "@/api/types";
import { useSettings } from "@/context/AppContext";
import { useI18n } from "@/i18n";
import { RequireAuth } from "@/components/Guard";
import { DataView, EmptyState } from "@/components/DataState";
import { DeleteCaseDialog } from "@/components/DeleteCaseDialog";
import { PageHeader, Pagination, ShortDisclaimer, StatusBadge } from "@/components/Misc";
import { RecommendationsPanel } from "@/components/Recommendations";
import { NotSupported } from "@/pages/screening/Wizard";
import { setFlash } from "@/lib/flash";
import { useAsync } from "@/hooks/useAsync";
import { shortId } from "@/lib/password";

function MyCases() {
  const { t, formatDate } = useI18n();
  const settings = useSettings();
  const [status, setStatus] = useState<CaseStatus | "">("");
  const [category, setCategory] = useState("");
  const [page, setPage] = useState(1);
  const [toDelete, setToDelete] = useState<CaseSummary | null>(null);
  const cats = useAsync(() => categoriesService.list(), []);
  const state = useAsync(
    () => casesService.list({ ...(status ? { status } : {}), ...(category ? { category_id: category } : {}), page, page_size: settings.page_size_my_cases }),
    [status, category, page],
  );
  const filtered = status !== "" || category !== "";

  return (
    <div className="container">
      <PageHeader title={t("myCases.title")}>
        <Link to="/screening" className="btn btn-primary">+ {t("myCases.newCase")}</Link>
      </PageHeader>
      <div className="filters">
        <label className="field-inline">
          <span className="label">{t("myCases.filterStatus")}</span>
          <select className="input" value={status} onChange={(e) => { setStatus(e.target.value as CaseStatus | ""); setPage(1); }}>
            <option value="">{t("common.all")}</option>
            {CASE_STATUSES.map((s) => <option key={s} value={s}>{t(`status.${s}`)}</option>)}
          </select>
        </label>
        <label className="field-inline">
          <span className="label">{t("myCases.filterCategory")}</span>
          <select className="input" value={category} onChange={(e) => { setCategory(e.target.value); setPage(1); }}>
            <option value="">{t("common.all")}</option>
            {cats.data?.items.map((c) => <option key={c.id} value={c.id}>{c.plain_name}</option>)}
          </select>
        </label>
        {filtered && <button type="button" className="btn btn-ghost btn-sm" onClick={() => { setStatus(""); setCategory(""); setPage(1); }}>{t("common.clearFilters")}</button>}
      </div>
      <DataView state={state}>
        {(data) =>
          data.items.length === 0 ? (
            filtered ? <EmptyState title={t("myCases.emptyFiltered")} /> : (
              <EmptyState title={t("myCases.emptyTitle")} text={t("myCases.emptyText")} action={<Link to="/screening" className="btn btn-primary">{t("myCases.startFirst")}</Link>} />
            )
          ) : (
            <>
              <p className="hint">{t("common.total", { count: data.total })}</p>
              <ul className="case-list">
                {data.items.map((c) => (
                  <li key={c.id} className="card case-row">
                    <div className="case-main">
                      <p className="hint">{formatDate(c.created_at)} · {t("common.caseNumber")} {shortId(c.id)}</p>
                      <h2 className="case-title"><Link to="/cases/$caseId" params={{ caseId: c.id }}>{c.title}</Link></h2>
                      {c.category && (
                        <p className="case-cat">{c.category.plain_name}<small>{c.category.name}</small></p>
                      )}
                      <div className="row-wrap">
                        <StatusBadge status={c.status} />
                        {c.chosen_lawyer_name && <span className="hint">{t("myCases.lawyer")}: <strong>{c.chosen_lawyer_name}</strong></span>}
                      </div>
                    </div>
                    <div className="case-actions">
                      {c.current_step !== "done" && c.current_step !== "recommendations" || c.status === "recommendations_ready" ? (
                        <Link to="/screening/$caseId" params={{ caseId: c.id }} className="btn btn-primary btn-sm">{t("myCases.continue")}</Link>
                      ) : null}
                      <Link to="/cases/$caseId" params={{ caseId: c.id }} className="btn btn-secondary btn-sm">{t("myCases.open")}</Link>
                      <button type="button" className="btn btn-ghost btn-sm btn-danger-text" onClick={() => setToDelete(c)}>
                        <span aria-hidden="true">🗑 </span>{t("myCases.deleteCase")}
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
              <Pagination page={data.page} pageSize={data.page_size} total={data.total} onPage={setPage} />
            </>
          )
        }
      </DataView>
      <DeleteCaseDialog
        target={toDelete}
        onClose={() => setToDelete(null)}
        onDeleted={() => {
          setToDelete(null);
          setFlash(t("deleteCase.deleted"));
          state.reload();
        }}
      />
    </div>
  );
}

export function MyCasesPage() {
  return (
    <RequireAuth>
      <MyCases />
    </RequireAuth>
  );
}

export function CaseAnswers({ data }: { data: Pick<CaseDetail, "question_rounds"> }) {
  const { t } = useI18n();
  const rounds = data.question_rounds.filter((r) => r.submitted_at !== null);
  if (rounds.length === 0) return <p className="hint">{t("caseDetail.noAnswers")}</p>;
  return (
    <>
      {rounds.map((r) => (
        <div key={r.round}>
          <h3 className="h4">{t("caseDetail.round", { round: r.round })}</h3>
          <dl className="dl">
            {r.questions.map((q) => (
              <div key={q.id} className="dl-row">
                <dt>{q.text}</dt>
                <dd>
                  {q.answer?.status === "answered" && q.answer.value !== null
                    ? (q.options.find((o) => o.value === q.answer?.value)?.label ?? q.answer.value)
                    : <em className="hint">{t("caseDetail.notAnswered")}</em>}
                </dd>
              </div>
            ))}
          </dl>
        </div>
      ))}
    </>
  );
}

function CaseDetailView({ initial }: { initial: CaseDetail }) {
  const { t, formatDate, formatPercent } = useI18n();
  const router = useRouter();
  const [data, setData] = useState(initial);
  const [del, setDel] = useState(false);
  const title = data.description.split(/\s+/).slice(0, 8).join(" ") + "…";
  const unfinished = !["lawyer_chosen", "unclassified", "recommendations_ready"].includes(data.status);
  const docs = data.documents.filter((d) => d.confirmed);

  return (
    <div className="container stack">
      <p><Link to="/cases">← {t("caseDetail.back")}</Link></p>
      <PageHeader title={t("caseDetail.title")}>
        {unfinished && <Link to="/screening/$caseId" params={{ caseId: data.id }} className="btn btn-primary">{t("caseDetail.continue")}</Link>}
        <button type="button" className="btn btn-secondary btn-danger-text" onClick={() => setDel(true)}><span aria-hidden="true">🗑 </span>{t("common.delete")}</button>
      </PageHeader>
      <p className="row-wrap">
        <StatusBadge status={data.status} />
        <span className="hint">{formatDate(data.created_at)} · {t("common.caseNumber")} {data.id.slice(0, 8)}</span>
      </p>
      {unfinished && <div className="alert alert-info"><p>{t("caseDetail.unfinished")}</p></div>}

      <section className="card">
        <h2>{t("caseDetail.description")}</h2>
        <p className="pre">{data.description}</p>
      </section>
      <section className="card">
        <h2>{t("caseDetail.answers")}</h2>
        <CaseAnswers data={data} />
      </section>
      <section className="card">
        <h2>{t("caseDetail.documentData")}</h2>
        {data.files_deleted_at && <p className="alert alert-info">{t("caseDetail.filesDeleted", { date: formatDate(data.files_deleted_at) })}</p>}
        {docs.length === 0 ? <p className="hint">{t("caseDetail.noDocuments")}</p> : docs.map((d) => (
          <div key={d.id}>
            <h3 className="h4">{d.filename}</h3>
            <dl className="dl">
              {d.extracted_fields.map((f) => (
                <div key={f.key} className="dl-row">
                  <dt>{t(`wizard.fields.${f.key as "document_type"}`)}</dt>
                  <dd>{f.confirmed_value ?? f.value}</dd>
                </div>
              ))}
            </dl>
          </div>
        ))}
      </section>
      <section className="card">
        <h2>{t("caseDetail.classification")}</h2>
        {!data.classification || data.classification.result === "needs_more_info" ? (
          <p className="hint">{t("caseDetail.notClassified")}</p>
        ) : data.classification.result === "classified" && data.classification.category ? (
          <>
            <p className="case-cat">{data.classification.category.plain_name}<small>{data.classification.category.name}</small></p>
            {data.classification.confidence !== null && <p>{t("wizard.confidence", { value: formatPercent(data.classification.confidence) })}</p>}
          </>
        ) : (
          <NotSupported />
        )}
      </section>
      {data.recommendations.length > 0 && (
        <section className="card">
          <h2>{t("caseDetail.recommendations")}</h2>
          <RecommendationsPanel data={data} onChange={setData} />
        </section>
      )}
      <ShortDisclaimer withGuarantee />
      <DeleteCaseDialog
        target={del ? { id: data.id, created_at: data.created_at, title } : null}
        onClose={() => setDel(false)}
        onDeleted={() => {
          setFlash(t("deleteCase.deleted"));
          void router.navigate({ to: "/cases" });
        }}
      />
    </div>
  );
}

function CaseDetailLoader({ caseId }: { caseId: string }) {
  const state = useAsync(() => casesService.get(caseId), [caseId]);
  return <DataView state={state}>{(c) => <CaseDetailView key={c.id} initial={c} />}</DataView>;
}

export function CaseDetailPage({ caseId }: { caseId: string }) {
  return (
    <RequireAuth>
      <CaseDetailLoader caseId={caseId} />
    </RequireAuth>
  );
}

export function LawyerDirectoryPage() {
  return (
    <RequireAuth>
      <LawyerDirectory />
    </RequireAuth>
  );
}


function LawyerDirectory() {
  const { t, formatCurrency, languageName } = useI18n();
  const settings = useSettings();
  const [city, setCity] = useState("");
  const [category, setCategory] = useState("");
  const [page, setPage] = useState(1);
  const cats = useAsync(() => categoriesService.list(), []);
  const state = useAsync(
    () => lawyersService.directory({ ...(city ? { city } : {}), ...(category ? { category_id: category } : {}), page, page_size: settings.page_size_lawyer_directory }),
    [city, category, page],
  );
  const catName = (id: string) => cats.data?.items.find((c) => c.id === id)?.plain_name;
  return (
    <div className="container">
      <PageHeader title={t("lawyersDir.title")} />
      <p>{t("lawyersDir.intro")}</p>
      <div className="filters">
        <label className="field-inline">
          <span className="label">{t("lawyersDir.city")}</span>
          <select className="input" value={city} onChange={(e) => { setCity(e.target.value); setPage(1); }}>
            <option value="">{t("common.all")}</option>
            {["Budapest", "Debrecen", "Szeged", "Pécs", "Győr", "Miskolc"].map((c) => <option key={c}>{c}</option>)}
          </select>
        </label>
        <label className="field-inline">
          <span className="label">{t("lawyersDir.category")}</span>
          <select className="input" value={category} onChange={(e) => { setCategory(e.target.value); setPage(1); }}>
            <option value="">{t("common.all")}</option>
            {cats.data?.items.map((c) => <option key={c.id} value={c.id}>{c.plain_name}</option>)}
          </select>
        </label>
      </div>
      <DataView state={state}>
        {(data) => data.items.length === 0 ? <EmptyState title={t("lawyersDir.empty")} /> : (
          <>
            <ul className="card-grid">
              {data.items.map((l) => (
                <li key={l.id} className="card">
                  <h2 className="h3">{l.name}</h2>
                  <p className="hint">{l.city} · {t("common.perHour", { price: formatCurrency(l.price_per_hour) })}</p>
                  <p>{l.category_ids.map(catName).filter(Boolean).join(", ")}</p>
                  <p className="hint">{l.languages.map(languageName).join(", ")} · {l.consultation_formats.map((f) => t(`formats.${f}`)).join(", ")}</p>
                </li>
              ))}
            </ul>
            <Pagination page={data.page} pageSize={data.page_size} total={data.total} onPage={setPage} />
          </>
        )}
      </DataView>
    </div>
  );
}
