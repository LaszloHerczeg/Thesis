import { useRouter } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { accountService } from "@/api";
import type { User } from "@/api/types";
import { useApp, useSettings } from "@/context/AppContext";
import { useI18n } from "@/i18n";
import { Dialog } from "@/components/Dialog";
import { Field, FormAlert, PasswordInput, StrengthMeter, apiFieldErrors } from "@/components/Form";
import { RequireAuth } from "@/components/Guard";
import { setFlash } from "@/lib/flash";

function AccountForm({ user }: { user: User }) {
  const { t } = useI18n();
  const { setUser } = useApp();
  const initial = { username: user.username, email: user.email, current_password: "" };
  const [form, setForm] = useState(initial);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [msg, setMsg] = useState<{ tone: "error" | "success"; text: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const emailChanged = form.email.trim().toLowerCase() !== user.email.toLowerCase();

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const errs: Record<string, string> = {};
    if (!/^[A-Za-z0-9_]{3,30}$/.test(form.username.trim())) errs["username"] = t("validation.usernameFormat");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(form.email.trim())) errs["email"] = t("validation.emailFormat");
    if (emailChanged && !form.current_password) errs["current_password"] = t("profile.currentPasswordHint");
    setErrors(errs);
    if (Object.keys(errs).length) return setMsg({ tone: "error", text: t("errors.fixFields") });
    setBusy(true);
    setMsg(null);
    try {
      const u = await accountService.updateProfile({
        username: form.username.trim(),
        email: form.email.trim(),
        ...(emailChanged ? { current_password: form.current_password } : {}),
      });
      setUser(u);
      setForm({ username: u.username, email: u.email, current_password: "" });
      setMsg({ tone: "success", text: t("profile.saved") });
    } catch (err) {
      setErrors(apiFieldErrors(err));
      setMsg({ tone: "error", text: t("errors.fixFields") });
    } finally {
      setBusy(false);
    }
  };

  return (
    <form className="card stack" onSubmit={(e) => void submit(e)} noValidate aria-labelledby="acc-h">
      <h2 id="acc-h">{t("profile.accountSection")}</h2>
      <FormAlert tone={msg?.tone ?? "error"} message={msg?.text ?? null} />
      <Field label={t("profile.username")} hint={t("auth.usernameHint")} error={errors["username"]}>
        {(a) => <input {...a} className="input" autoComplete="username" value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} />}
      </Field>
      <Field label={t("profile.email")} error={errors["email"]}>
        {(a) => <input {...a} className="input" type="email" autoComplete="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />}
      </Field>
      {emailChanged && (
        <Field label={t("profile.currentPassword")} hint={t("profile.currentPasswordHint")} error={errors["current_password"]}>
          {(a) => <PasswordInput a11y={a} autoComplete="current-password" value={form.current_password} onChange={(v) => setForm({ ...form, current_password: v })} />}
        </Field>
      )}
      <Field label={t("profile.role")} hint={t("profile.roleHint")}>
        {(a) => <input {...a} className="input" readOnly value={t(`profile.roles.${user.role}`)} />}
      </Field>
      <div className="row">
        <button type="submit" className="btn btn-primary" disabled={busy}>{t("common.save")}</button>
        <button type="button" className="btn btn-secondary" onClick={() => { setForm(initial); setErrors({}); setMsg(null); }}>{t("common.cancel")}</button>
      </div>
    </form>
  );
}

function PasswordForm() {
  const { t } = useI18n();
  const settings = useSettings();
  const empty = { current_password: "", new_password: "", new_password_confirm: "" };
  const [form, setForm] = useState(empty);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [msg, setMsg] = useState<{ tone: "error" | "success"; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const errs: Record<string, string> = {};
    if (!form.current_password) errs["current_password"] = t("validation.required");
    if ([...form.new_password].length < settings.password_min_length) errs["new_password"] = t("validation.passwordMin", { min: settings.password_min_length });
    if (form.new_password !== form.new_password_confirm) errs["new_password_confirm"] = t("validation.passwordMismatch");
    setErrors(errs);
    if (Object.keys(errs).length) return setMsg({ tone: "error", text: t("errors.fixFields") });
    setBusy(true);
    try {
      await accountService.changePassword(form);
      setForm(empty);
      setMsg({ tone: "success", text: t("profile.passwordChanged") });
    } catch (err) {
      setErrors(apiFieldErrors(err));
      setMsg({ tone: "error", text: t("errors.fixFields") });
    } finally {
      setBusy(false);
    }
  };

  return (
    <form className="card stack" onSubmit={(e) => void submit(e)} noValidate aria-labelledby="pw-h">
      <h2 id="pw-h">{t("profile.passwordSection")}</h2>
      <FormAlert tone={msg?.tone ?? "error"} message={msg?.text ?? null} />
      <Field label={t("profile.currentPassword")} error={errors["current_password"]}>
        {(a) => <PasswordInput a11y={a} autoComplete="current-password" value={form.current_password} onChange={(v) => setForm({ ...form, current_password: v })} />}
      </Field>
      <Field label={t("profile.newPassword")} hint={t("auth.passwordHint", { min: settings.password_min_length })} error={errors["new_password"]}>
        {(a) => (
          <>
            <PasswordInput a11y={a} autoComplete="new-password" value={form.new_password} onChange={(v) => setForm({ ...form, new_password: v })} />
            <StrengthMeter password={form.new_password} />
          </>
        )}
      </Field>
      <Field label={t("profile.newPasswordConfirm")} error={errors["new_password_confirm"]}>
        {(a) => <PasswordInput a11y={a} autoComplete="new-password" value={form.new_password_confirm} onChange={(v) => setForm({ ...form, new_password_confirm: v })} />}
      </Field>
      <div className="row">
        <button type="submit" className="btn btn-primary" disabled={busy}>{t("profile.changePassword")}</button>
        <button type="button" className="btn btn-secondary" onClick={() => { setForm(empty); setErrors({}); setMsg(null); }}>{t("common.cancel")}</button>
      </div>
    </form>
  );
}

function Profile() {
  const { t, formatDate } = useI18n();
  const settings = useSettings();
  const { user, setUser } = useApp();
  const router = useRouter();
  const [withdrawOpen, setWithdrawOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [delPassword, setDelPassword] = useState("");
  const [delError, setDelError] = useState<string | undefined>(undefined);
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState<string | null>(null);
  if (!user) return null;

  const setConsent = async (given: boolean) => {
    setBusy(true);
    try {
      setUser(await accountService.setConsent(given));
      setNote(t("profile.consentUpdated"));
      setWithdrawOpen(false);
    } catch {
      setNote(t("errors.generic"));
    } finally {
      setBusy(false);
    }
  };

  const download = async () => {
    setBusy(true);
    try {
      const data = await accountService.exportData();
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `jogutmutato-adataim-${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      setNote(t("profile.downloaded"));
    } catch {
      setNote(t("errors.generic"));
    } finally {
      setBusy(false);
    }
  };

  const deleteAccount = async () => {
    if (!delPassword) return setDelError(t("validation.required"));
    setBusy(true);
    setDelError(undefined);
    try {
      await accountService.deleteAccount({ password: delPassword });
      setUser(null);
      setFlash(t("profile.deleted"));
      void router.navigate({ to: "/" });
    } catch (err) {
      setDelError(apiFieldErrors(err)["password"] ?? t("errors.generic"));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="container narrow stack">
      <h1>{t("profile.title")}</h1>
      <FormAlert tone="success" message={note} />
      <AccountForm user={user} />
      <PasswordForm />
      <section className="card stack" aria-labelledby="consent-h">
        <h2 id="consent-h">{t("profile.consentSection")}</h2>
        <p>{user.consent_given && user.consent_given_at ? t("profile.consentGiven", { date: formatDate(user.consent_given_at) }) : t("profile.consentNotGiven")}</p>
        <div className="row">
          {user.consent_given ? (
            <button type="button" className="btn btn-secondary" onClick={() => setWithdrawOpen(true)}>{t("profile.withdraw")}</button>
          ) : (
            <button type="button" className="btn btn-primary" disabled={busy} onClick={() => void setConsent(true)}>{t("profile.give")}</button>
          )}
        </div>
      </section>
      <section className="card" aria-labelledby="ret-h">
        <h2 id="ret-h">{t("profile.retentionSection")}</h2>
        <ul>
          <li>{t("profile.fileRetention", { days: settings.file_retention_days })}</li>
          <li>{t("profile.accountRetention", { days: settings.account_inactivity_deletion_days })}</li>
        </ul>
      </section>
      <section className="card stack" aria-labelledby="data-h">
        <h2 id="data-h">{t("profile.dataSection")}</h2>
        <p className="hint">{t("profile.downloadHint")}</p>
        <div className="row"><button type="button" className="btn btn-secondary" disabled={busy} onClick={() => void download()}>{t("profile.download")}</button></div>
      </section>
      <section className="card stack danger-zone" aria-labelledby="del-h">
        <h2 id="del-h">{t("profile.deleteSection")}</h2>
        <p className="hint">{t("profile.deleteHint")}</p>
        <div className="row"><button type="button" className="btn btn-danger" onClick={() => setDeleteOpen(true)}>{t("profile.deleteAccount")}</button></div>
      </section>

      <Dialog
        open={withdrawOpen}
        title={t("profile.withdrawTitle")}
        onClose={() => setWithdrawOpen(false)}
        actions={
          <>
            <button type="button" className="btn btn-secondary" onClick={() => setWithdrawOpen(false)}>{t("common.cancel")}</button>
            <button type="button" className="btn btn-danger" disabled={busy} onClick={() => void setConsent(false)}>{t("profile.withdraw")}</button>
          </>
        }
      >
        <p>{t("profile.withdrawText")}</p>
      </Dialog>
      <Dialog
        open={deleteOpen}
        title={t("profile.deleteTitle")}
        onClose={() => setDeleteOpen(false)}
        actions={
          <>
            <button type="button" className="btn btn-secondary" onClick={() => setDeleteOpen(false)}>{t("common.cancel")}</button>
            <button type="button" className="btn btn-danger" disabled={busy} onClick={() => void deleteAccount()}>{t("profile.deleteConfirm")}</button>
          </>
        }
      >
        <p>{t("profile.deleteText")}</p>
        <Field label={t("profile.deletePassword")} error={delError}>
          {(a) => <PasswordInput a11y={a} autoComplete="current-password" value={delPassword} onChange={setDelPassword} />}
        </Field>
      </Dialog>
    </div>
  );
}

export function ProfilePage() {
  return (
    <RequireAuth>
      <Profile />
    </RequireAuth>
  );
}
