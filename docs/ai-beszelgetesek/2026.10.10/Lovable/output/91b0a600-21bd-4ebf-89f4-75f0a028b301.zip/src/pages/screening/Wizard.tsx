import { Link, useRouter } from "@tanstack/react-router";
import { useEffect, useRef, useState, type FormEvent } from "react";
import { casesService, isApiError } from "@/api";
import type { AnswerSubmission, CaseDetail, CaseDocument, ConsultationPreference, LanguageCode } from "@/api/types";
import { LANGUAGE_CODES } from "@/api/types";
import { useApp, useSettings } from "@/context/AppContext";
import { useI18n } from "@/i18n";
import { CheckboxGroup, Field, FormAlert, RadioGroup, apiFieldErrors } from "@/components/Form";
import { Loading } from "@/components/DataState";
import { ShortDisclaimer } from "@/components/Misc";
import { RecommendationsPanel } from "@/components/Recommendations";
import styles from "./Wizard.module.css";

export type View = "describe" | "documents" | "questions" | "classification" | "result" | "preferences" | "recommendations";
const STEP_KEYS = ["describe", "documents", "questions", "classification", "preferences", "recommendations"] as const;

function stepIndex(v: View): number {
  if (v === "result") return 3;
  return STEP_KEYS.indexOf(v);
}

export function Stepper({ view }: { view: View }) {
  const { t } = useI18n();
  const idx = stepIndex(view);
  return (
    <nav aria-label={t("steps.progress")}>
      <ol className={styles.stepper}>
        {STEP_KEYS.map((k, i) => (
          <li key={k} className={i < idx ? styles.done : i === idx ? styles.current : ""} aria-current={i === idx ? "step" : undefined}>
            <span className={styles.dot} aria-hidden="true">{i < idx ? "✓" : i + 1}</span>
            <span className={styles.stepLabel}>{t(`steps.${k}`)}</span>
            <span className="sr-only">{i < idx ? ` (${t("steps.done")})` : i === idx ? ` (${t("steps.current")})` : ""}</span>
          </li>
        ))}
      </ol>
    </nav>
  );
}

export function WizardFrame({ view, children }: { view: View; children: React.ReactNode }) {
  const { t } = useI18n();
  return (
    <div className="container">
      <h1 className={styles.title}>{t("wizard.title")}</h1>
      <Stepper view={view} />
      <ShortDisclaimer withGuarantee={view === "recommendations"} />
      <div className={styles.panel}>{children}</div>
    </div>
  );
}

function AnalysisError({ onRetry, busy }: { onRetry: () => void; busy: boolean }) {
  const { t } = useI18n();
  return (
    <div className="alert alert-error" role="alert">
      <p><strong>{t("wizard.analysisErrorTitle")}</strong></p>
      <p>{t("wizard.analysisErrorText")}</p>
      <button type="button" className="btn btn-primary btn-sm" disabled={busy} onClick={onRetry}>
        {busy ? t("common.working") : t("wizard.tryAgain")}
      </button>
    </div>
  );
}

// ---------------- Step 1: describe ----------------

export function DescribeStep({ onCreated }: { onCreated: (c: CaseDetail) => void }) {
  const { t, formatNumber } = useI18n();
  const settings = useSettings();
  const { user } = useApp();
  const [text, setText] = useState("");
  const [attempted, setAttempted] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const min = settings.description_min_length;
  const max = settings.description_max_length;
  const len = text.trim().length;
  const tooShort = len < min;
  const tooLong = len > max;

  if (user && !user.consent_given) {
    return (
      <div className="alert alert-warning" role="alert">
        <p>{t("wizard.consentMissing")}</p>
        <Link to="/profile" className="btn btn-primary btn-sm">{t("wizard.goToProfile")}</Link>
      </div>
    );
  }

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setAttempted(true);
    if (tooShort || tooLong) return;
    setBusy(true);
    setError(null);
    try {
      onCreated(await casesService.create({ description: text }));
    } catch (err) {
      setError(apiFieldErrors(err)["description"] ?? (isApiError(err) && err.code === "consent_required" ? t("wizard.consentMissing") : t("errors.generic")));
    } finally {
      setBusy(false);
    }
  };

  const showShort = attempted && tooShort;
  return (
    <form onSubmit={(e) => void submit(e)} className="stack" noValidate>
      <h2>{t("wizard.describeTitle")}</h2>
      <Field label={t("wizard.describeLabel")} hint={t("wizard.describeHint")} error={error ?? (tooLong ? t("wizard.tooLong", { max: formatNumber(max) }) : undefined)}>
        {(a) => (
          <>
            <textarea {...a} className="input textarea" rows={9} value={text} onChange={(e) => setText(e.target.value)} />
            <p className={`${styles.counter} ${tooLong ? styles.counterOver : ""}`} aria-live="polite">
              {t("wizard.counter", { count: formatNumber(len), max: formatNumber(max) })}
            </p>
          </>
        )}
      </Field>
      {showShort && (
        <div className="alert alert-info" role="alert">
          <p><strong>{t("wizard.tooShortTitle")}</strong></p>
          <p>{t("wizard.tooShort", { remaining: min - len })}</p>
          <p className={styles.exampleLabel}>{t("wizard.exampleLabel")}</p>
          <blockquote className={styles.example}>{t("wizard.example")}</blockquote>
        </div>
      )}
      <div className="row">
        <button type="submit" className="btn btn-primary" disabled={busy}>{busy ? t("common.working") : t("wizard.submitDescription")}</button>
      </div>
    </form>
  );
}

// ---------------- Step 2: documents ----------------

function DocumentCard({ caseId, doc, onUpdate, onRemove }: { caseId: string; doc: CaseDocument; onUpdate: (d: CaseDocument) => void; onRemove: () => void }) {
  const { t } = useI18n();
  const [values, setValues] = useState<Record<string, string>>(() =>
    Object.fromEntries(doc.extracted_fields.map((f) => [f.key, f.confirmed_value ?? f.value])),
  );
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const confirm = async () => {
    setBusy(true);
    setError(null);
    try {
      onUpdate(await casesService.confirmDocument(caseId, doc.id, { fields: Object.entries(values).map(([key, value]) => ({ key, value })) }));
    } catch {
      setError(t("errors.generic"));
    } finally {
      setBusy(false);
    }
  };
  const remove = async () => {
    setBusy(true);
    try {
      await casesService.deleteDocument(caseId, doc.id);
      onRemove();
    } catch {
      setError(t("errors.generic"));
      setBusy(false);
    }
  };

  return (
    <section className="card stack">
      <div className="row-between">
        <h3 className={styles.docTitle}>{t("wizard.extractedTitle", { file: doc.filename })}</h3>
        {doc.confirmed && <span className="badge badge-lawyer_chosen">{t("wizard.confirmedBadge")}</span>}
      </div>
      {!doc.confirmed && <p className="hint">{t("wizard.checkFields")}</p>}
      <div className="grid-2">
        {doc.extracted_fields.map((f) => (
          <Field key={f.key} label={t(`wizard.fields.${f.key as "document_type"}`)}>
            {(a) => (
              <input {...a} className="input" value={values[f.key] ?? ""} readOnly={doc.confirmed} onChange={(e) => setValues({ ...values, [f.key]: e.target.value })} />
            )}
          </Field>
        ))}
      </div>
      {error && <p className="error-text" role="alert">{error}</p>}
      <div className="row">
        {!doc.confirmed && (
          <button type="button" className="btn btn-primary btn-sm" disabled={busy} onClick={() => void confirm()}>{t("wizard.confirmFields")}</button>
        )}
        <button type="button" className="btn btn-ghost btn-sm" disabled={busy} onClick={() => void remove()}>{t("wizard.removeDocument")}</button>
      </div>
    </section>
  );
}

function DocumentsStep({ data, onChange }: { data: CaseDetail; onChange: (c: CaseDetail) => void }) {
  const { t } = useI18n();
  const settings = useSettings();
  const fileRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [warning, setWarning] = useState(false);
  const [analysisFailed, setAnalysisFailed] = useState(false);
  const [busy, setBusy] = useState(false);

  const upload = async () => {
    if (!file) {
      setUploadError(t("validation.required"));
      return;
    }
    if (file.size > settings.max_upload_size_mb * 1024 * 1024 || !settings.allowed_upload_types.includes(file.type)) {
      setUploadError(t("wizard.fileHint", { mb: settings.max_upload_size_mb }));
      return;
    }
    setUploading(true);
    setUploadError(null);
    try {
      const doc = await casesService.uploadDocument(data.id, file);
      onChange({ ...data, documents: [...data.documents, doc] });
      setFile(null);
      if (fileRef.current) fileRef.current.value = "";
    } catch (e) {
      setUploadError(apiFieldErrors(e)["file"] ?? t("wizard.analysisErrorTitle"));
    } finally {
      setUploading(false);
    }
  };

  const next = async () => {
    if (data.documents.some((d) => !d.confirmed)) {
      setWarning(true);
      return;
    }
    setBusy(true);
    setAnalysisFailed(false);
    try {
      onChange(await casesService.requestQuestions(data.id));
    } catch {
      setAnalysisFailed(true);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="stack">
      <h2>{t("wizard.documentsTitle")}</h2>
      <p>{t("wizard.documentsIntro")}</p>
      <div className="card stack">
        <Field label={t("wizard.chooseFile")} hint={t("wizard.fileHint", { mb: settings.max_upload_size_mb })} error={uploadError ?? undefined}>
          {(a) => (
            <input {...a} ref={fileRef} type="file" className="input" accept={settings.allowed_upload_types.join(",")} onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
          )}
        </Field>
        <div className="row">
          <button type="button" className="btn btn-secondary" disabled={uploading} onClick={() => void upload()}>
            {uploading ? t("wizard.uploading") : t("wizard.upload")}
          </button>
        </div>
        {uploading && <Loading label={t("wizard.uploading")} />}
      </div>
      {data.documents.map((d) => (
        <DocumentCard
          key={d.id}
          caseId={data.id}
          doc={d}
          onUpdate={(nd) => onChange({ ...data, documents: data.documents.map((x) => (x.id === nd.id ? nd : x)) })}
          onRemove={() => onChange({ ...data, documents: data.documents.filter((x) => x.id !== d.id) })}
        />
      ))}
      {warning && data.documents.some((d) => !d.confirmed) && <FormAlert message={t("wizard.unconfirmedWarning")} />}
      {analysisFailed && <AnalysisError busy={busy} onRetry={() => void next()} />}
      {busy && <Loading label={t("wizard.analysing")} />}
      <div className="row">
        <button type="button" className="btn btn-primary" disabled={busy} onClick={() => void next()}>
          {data.documents.length ? t("wizard.toQuestions") : t("wizard.skipDocuments")}
        </button>
      </div>
    </div>
  );
}

// ---------------- Step 3: questions ----------------

function QuestionsStep({ data, onChange, onClassified }: { data: CaseDetail; onChange: (c: CaseDetail) => void; onClassified: (c: CaseDetail) => void }) {
  const { t } = useI18n();
  const settings = useSettings();
  const round = data.question_rounds.find((r) => r.submitted_at === null);
  const [answers, setAnswers] = useState<Record<string, { value: string; skipped: boolean }>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    setAnswers({});
    setErrors({});
  }, [round?.round]);

  if (!round) return <ClassificationRunner data={data} onDone={onClassified} />;

  const set = (id: string, patch: Partial<{ value: string; skipped: boolean }>) =>
    setAnswers((a) => ({ ...a, [id]: { value: a[id]?.value ?? "", skipped: a[id]?.skipped ?? false, ...patch } }));

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const errs: Record<string, string> = {};
    const payload: AnswerSubmission[] = round.questions.map((q) => {
      const a = answers[q.id];
      if (a?.skipped) return { question_id: q.id, status: "not_answered", value: null };
      if (!a || !a.value.trim()) errs[q.id] = t("wizard.answerOrSkip");
      return { question_id: q.id, status: "answered", value: a?.value.trim() ?? "" };
    });
    setErrors(errs);
    if (Object.keys(errs).length) return;
    setBusy(true);
    setFailed(false);
    try {
      const saved = await casesService.submitAnswers(data.id, round.round, { answers: payload });
      onChange(saved);
      try {
        onClassified(await casesService.classify(data.id));
      } catch {
        setFailed(true);
      }
    } catch (err) {
      const fe = apiFieldErrors(err);
      setErrors(Object.fromEntries(Object.entries(fe).map(([k, v]) => [k.replace("answers.", ""), v])));
    } finally {
      setBusy(false);
    }
  };

  return (
    <form onSubmit={(e) => void submit(e)} className="stack" noValidate>
      <h2>{t("wizard.questionsTitle")}</h2>
      <p>{t("wizard.questionsIntro", { round: round.round, max: settings.max_question_rounds })}</p>
      {round.questions.map((q, i) => {
        const a = answers[q.id];
        const skipped = a?.skipped ?? false;
        const name = `q-${q.id}`;
        return (
          <fieldset key={q.id} className={`card ${styles.question} ${errors[q.id] ? "field-invalid" : ""}`} disabled={busy}>
            <legend className={styles.qLegend}>
              <span className={styles.qNum}>{i + 1}.</span> {q.text}
            </legend>
            {!skipped && (q.type === "multiple_choice" || q.type === "yes_no") && (
              <div className="choice-grid">
                {q.options.map((o) => (
                  <label key={o.value} className="choice">
                    <input type="radio" name={name} checked={a?.value === o.value} onChange={() => set(q.id, { value: o.value })} />
                    <span>{o.label}</span>
                  </label>
                ))}
              </div>
            )}
            {!skipped && q.type === "date" && (
              <input type="date" className="input" aria-label={q.text} value={a?.value ?? ""} onChange={(e) => set(q.id, { value: e.target.value })} />
            )}
            {!skipped && q.type === "short_text" && (
              <input type="text" className="input" aria-label={q.text} placeholder={t("wizard.shortAnswer")} maxLength={200} value={a?.value ?? ""} onChange={(e) => set(q.id, { value: e.target.value })} />
            )}
            <label className={`choice ${styles.skip}`}>
              <input type="checkbox" checked={skipped} onChange={(e) => set(q.id, { skipped: e.target.checked })} />
              <span>{t("wizard.skipQuestion")}</span>
            </label>
            {errors[q.id] && <p className="error-text" role="alert">{errors[q.id]}</p>}
          </fieldset>
        );
      })}
      {failed && <ClassificationRunner data={data} onDone={onClassified} autoStart={false} initiallyFailed />}
      {busy && <Loading label={t("wizard.analysing")} />}
      {!failed && (
        <div className="row">
          <button type="submit" className="btn btn-primary" disabled={busy}>{t("wizard.submitAnswers")}</button>
        </div>
      )}
    </form>
  );
}

// ---------------- Step 4: classification ----------------

function ClassificationRunner({ data, onDone, autoStart = true, initiallyFailed = false }: { data: CaseDetail; onDone: (c: CaseDetail) => void; autoStart?: boolean; initiallyFailed?: boolean }) {
  const { t } = useI18n();
  const [busy, setBusy] = useState(false);
  const [failed, setFailed] = useState(initiallyFailed);
  const started = useRef(false);

  const run = async () => {
    setBusy(true);
    setFailed(false);
    try {
      onDone(await casesService.classify(data.id));
    } catch {
      setFailed(true);
    } finally {
      setBusy(false);
    }
  };

  useEffect(() => {
    if (autoStart && !started.current) {
      started.current = true;
      void run();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (failed) return <AnalysisError busy={busy} onRetry={() => void run()} />;
  if (busy) return <Loading label={t("wizard.analysing")} />;
  return (
    <button type="button" className="btn btn-primary" onClick={() => void run()}>{t("wizard.runAnalysis")}</button>
  );
}

export function NotSupported() {
  const { t } = useI18n();
  return (
    <div className="stack">
      <div className="alert alert-warning" role="status">
        <p><strong>{t("wizard.notSupportedTitle")}</strong></p>
        <p>{t("wizard.notSupportedText")}</p>
      </div>
      <h3>{t("wizard.nextStepsTitle")}</h3>
      <ul>
        <li>{t("wizard.next1")}</li>
        <li>{t("wizard.next2")}</li>
        <li>{t("wizard.next3")}</li>
      </ul>
      <div className="row">
        <Link to="/lawyers" className="btn btn-secondary">{t("wizard.browseLawyers")}</Link>
        <Link to="/screening" className="btn btn-primary">{t("wizard.newScreening")}</Link>
      </div>
    </div>
  );
}

function ClassificationResult({ data, onContinue }: { data: CaseDetail; onContinue: () => void }) {
  const { t, formatPercent } = useI18n();
  const c = data.classification;
  if (!c || c.result !== "classified" || !c.category) return <NotSupported />;
  return (
    <div className="stack">
      <h2>{t("wizard.classifiedTitle")}</h2>
      <div className={`card ${styles.category}`}>
        <p className={styles.categoryName}>{c.category.plain_name}</p>
        <p className="hint">{t("wizard.legalTerm", { term: c.category.name })}</p>
        {c.confidence !== null && (
          <>
            <p>{t("wizard.confidence", { value: formatPercent(c.confidence) })}</p>
            <meter className={styles.meter} min={0} max={1} low={0.5} high={0.8} optimum={1} value={c.confidence} aria-label={t("wizard.confidence", { value: formatPercent(c.confidence) })} />
          </>
        )}
      </div>
      <div className="row">
        <button type="button" className="btn btn-primary" onClick={onContinue}>{t("wizard.toPreferences")}</button>
      </div>
    </div>
  );
}

// ---------------- Step 5: preferences ----------------

function PreferencesStep({ data, onChange }: { data: CaseDetail; onChange: (c: CaseDetail) => void }) {
  const { t, lang, languageName, formatPercent } = useI18n();
  const p = data.preferences;
  const [city, setCity] = useState(p?.city ?? "");
  const [languages, setLanguages] = useState<LanguageCode[]>(p?.languages ?? [lang]);
  const [format, setFormat] = useState<ConsultationPreference>(p?.consultation_format ?? "either");
  const [maxPrice, setMaxPrice] = useState(p?.max_price ? String(p.max_price) : "");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const [recFailed, setRecFailed] = useState(false);

  const recommend = async () => {
    setBusy(true);
    setRecFailed(false);
    try {
      onChange(await casesService.recommend(data.id));
    } catch {
      setRecFailed(true);
    } finally {
      setBusy(false);
    }
  };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const errs: Record<string, string> = {};
    if (languages.length === 0) errs["languages"] = t("validation.selectAtLeastOne");
    const price = maxPrice.trim() === "" ? null : Number(maxPrice.replace(/\s/g, ""));
    if (price !== null && (!Number.isInteger(price) || price <= 0)) errs["max_price"] = t("validation.positiveNumber");
    setErrors(errs);
    if (Object.keys(errs).length) return;
    setBusy(true);
    try {
      const saved = await casesService.savePreferences(data.id, { city: city.trim(), languages, consultation_format: format, max_price: price });
      onChange(saved);
      setBusy(false);
      await recommend();
    } catch (err) {
      setErrors(apiFieldErrors(err));
      setBusy(false);
    }
  };

  const c = data.classification?.category;
  return (
    <form onSubmit={(e) => void submit(e)} className="stack" noValidate>
      {c && (
        <p className={styles.summaryLine}>
          <strong>{c.plain_name}</strong> <span className="hint">({c.name}{data.classification?.confidence ? `, ${formatPercent(data.classification.confidence)}` : ""})</span>
        </p>
      )}
      <h2>{t("wizard.preferencesTitle")}</h2>
      <p>{t("wizard.preferencesIntro")}</p>
      <div className="card stack">
        <Field label={t("wizard.city")} hint={t("wizard.cityHint")} optional error={errors["city"]}>
          {(a) => (
            <>
              <input {...a} className="input" list="city-list" autoComplete="address-level2" value={city} onChange={(e) => setCity(e.target.value)} />
              <datalist id="city-list">
                {["Budapest", "Debrecen", "Szeged", "Pécs", "Győr", "Miskolc", "Nyíregyháza", "Kecskemét", "Székesfehérvár"].map((x) => <option key={x} value={x} />)}
              </datalist>
            </>
          )}
        </Field>
        <CheckboxGroup
          legend={t("wizard.languages")}
          options={LANGUAGE_CODES.map((l) => ({ value: l, label: languageName(l) }))}
          value={languages}
          onChange={setLanguages}
          error={errors["languages"]}
        />
        <RadioGroup
          legend={t("wizard.format")}
          name="format"
          options={[
            { value: "online" as const, label: t("formats.online") },
            { value: "in_person" as const, label: t("formats.in_person") },
            { value: "either" as const, label: t("wizard.formatEither") },
          ]}
          value={format}
          onChange={setFormat}
          error={errors["consultation_format"]}
        />
        <Field label={t("wizard.maxPrice")} hint={t("wizard.maxPriceHint")} optional error={errors["max_price"]}>
          {(a) => <input {...a} className="input input-narrow" inputMode="numeric" value={maxPrice} onChange={(e) => setMaxPrice(e.target.value)} />}
        </Field>
      </div>
      {recFailed && <AnalysisError busy={busy} onRetry={() => void recommend()} />}
      {busy && <Loading label={t("wizard.analysing")} />}
      {!recFailed && (
        <div className="row">
          <button type="submit" className="btn btn-primary" disabled={busy}>{t("wizard.showRecommendations")}</button>
        </div>
      )}
    </form>
  );
}

// ---------------- Step 6: recommendations ----------------

function RecommendationsStep({ data, onChange }: { data: CaseDetail; onChange: (c: CaseDetail) => void }) {
  const { t } = useI18n();
  const [busy, setBusy] = useState(false);
  const [failed, setFailed] = useState(false);
  const ready = data.status === "recommendations_ready" || data.status === "lawyer_chosen";

  const run = async () => {
    setBusy(true);
    setFailed(false);
    try {
      onChange(await casesService.recommend(data.id));
    } catch {
      setFailed(true);
    } finally {
      setBusy(false);
    }
  };

  if (!ready) {
    return (
      <div className="stack">
        <h2>{t("wizard.recommendationsTitle")}</h2>
        {failed ? <AnalysisError busy={busy} onRetry={() => void run()} /> : busy ? <Loading label={t("wizard.analysing")} /> : (
          <button type="button" className="btn btn-primary" onClick={() => void run()}>{t("wizard.showRecommendations")}</button>
        )}
      </div>
    );
  }
  return (
    <div className="stack">
      <h2>{t("wizard.recommendationsTitle")}</h2>
      <p>{t("wizard.recommendationsIntro")}</p>
      <RecommendationsPanel data={data} onChange={onChange} />
      {data.choice && (
        <div className="alert alert-success" role="status">
          <p>{t("wizard.finished")}</p>
          <Link to="/cases" className="btn btn-secondary btn-sm">{t("wizard.toMyCases")}</Link>
        </div>
      )}
    </div>
  );
}

// ---------------- Controller ----------------

function viewFor(c: CaseDetail): View {
  switch (c.current_step) {
    case "documents": return "documents";
    case "questions": return "questions";
    case "classification": return "classification";
    case "preferences": return "preferences";
    case "recommendations": return "recommendations";
    case "done": return c.status === "unclassified" ? "result" : "recommendations";
  }
}

export function CaseWizard({ initial }: { initial: CaseDetail }) {
  const { t } = useI18n();
  const router = useRouter();
  const [data, setData] = useState(initial);
  const [override, setOverride] = useState<View | null>(null);
  const view = override ?? viewFor(data);
  const headingRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    headingRef.current?.querySelector<HTMLElement>("h2")?.focus();
  }, [view]);

  const update = (c: CaseDetail) => {
    setData(c);
    setOverride(null);
  };
  const classified = (c: CaseDetail) => {
    setData(c);
    setOverride(c.classification?.result === "needs_more_info" ? null : "result");
  };

  return (
    <WizardFrame view={view}>
      <div ref={headingRef} className={styles.focusScope}>
        {view === "documents" && <DocumentsStep data={data} onChange={update} />}
        {view === "questions" && (
          <>
            <QuestionsStep data={data} onChange={setData} onClassified={classified} />
          </>
        )}
        {view === "classification" && (
          <div className="stack">
            <h2>{t("steps.classification")}</h2>
            <ClassificationRunner data={data} onDone={classified} />
          </div>
        )}
        {view === "result" && <ClassificationResult data={data} onContinue={() => setOverride("preferences")} />}
        {view === "preferences" && <PreferencesStep data={data} onChange={update} />}
        {view === "recommendations" && <RecommendationsStep data={data} onChange={update} />}
      </div>
      <p className={styles.back}>
        <button type="button" className="btn btn-ghost btn-sm" onClick={() => void router.navigate({ to: "/cases" })}>← {t("caseDetail.back")}</button>
      </p>
    </WizardFrame>
  );
}
