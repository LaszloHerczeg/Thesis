import { useRouter } from "@tanstack/react-router";
import { casesService } from "@/api";
import { RequireAuth } from "@/components/Guard";
import { DataView } from "@/components/DataState";
import { useAsync } from "@/hooks/useAsync";
import { CaseWizard, DescribeStep, WizardFrame } from "./Wizard";

export function NewScreeningPage() {
  const router = useRouter();
  return (
    <RequireAuth screening>
      <WizardFrame view="describe">
        <DescribeStep onCreated={(c) => void router.navigate({ to: "/screening/$caseId", params: { caseId: c.id }, replace: true })} />
      </WizardFrame>
    </RequireAuth>
  );
}

function Resume({ caseId }: { caseId: string }) {
  const state = useAsync(() => casesService.get(caseId), [caseId]);
  return <DataView state={state}>{(c) => <CaseWizard key={c.id} initial={c} />}</DataView>;
}

export function ScreeningCasePage({ caseId }: { caseId: string }) {
  return (
    <RequireAuth screening>
      <Resume caseId={caseId} />
    </RequireAuth>
  );
}
