import { Link } from "@tanstack/react-router";
import { useApp } from "@/context/AppContext";
import { useI18n } from "@/i18n";
import { ShortDisclaimer } from "@/components/Misc";
import styles from "./HomePage.module.css";

export function HomePage() {
  const { t } = useI18n();
  const { user } = useApp();
  return (
    <>
      <section className={styles.hero}>
        <div className={`container ${styles.heroInner}`}>
          <h1 className={styles.title}>{t("home.title")}</h1>
          <p className={styles.lead}>{t("home.lead")}</p>
          <div className="row">
            <Link to="/screening" className="btn btn-primary btn-lg">{t("home.start")}</Link>
            {user && <Link to="/cases" className="btn btn-secondary btn-lg">{t("home.myCases")}</Link>}
          </div>
        </div>
      </section>
      <section className="container section" aria-labelledby="how">
        <h2 id="how">{t("home.howTitle")}</h2>
        <ol className={styles.steps}>
          {([1, 2, 3] as const).map((n) => (
            <li key={n} className="card">
              <span className={styles.num} aria-hidden="true">{n}</span>
              <h3>{t(`home.how${n}Title`)}</h3>
              <p>{t(`home.how${n}`)}</p>
            </li>
          ))}
        </ol>
      </section>
      <section className="container section" aria-labelledby="trust">
        <div className={styles.trust}>
          <h2 id="trust">{t("home.trustTitle")}</h2>
          <ul>
            <li>{t("home.trust1")}</li>
            <li>{t("home.trust2")}</li>
            <li>{t("home.trust3")}</li>
          </ul>
        </div>
        <ShortDisclaimer />
      </section>
    </>
  );
}
