import { Link, useRouter } from "@tanstack/react-router";
import { useState, type FormEvent, type ReactNode } from "react";
import { adminService, categoriesService, isApiError, lawyersService } from "@/api";
import type {
  AdminCategory,
  AdminCaseQuery,
  AdminCaseSort,
  CaseStatus,
  CategoryInput,
  ConsultationFormat,
  LanguageCode,
  Lawyer,
  LawyerInput,
  LawyerRefDto,
  SortOrder,
} from "@/api/types";
import { CASE_STATUSES, CONSULTATION_FORMATS, LANGUAGE_CODES } from "@/api/types";
import { useSettings } from "@/context/AppContext";
import { useI18n } from "@/i18n";
import { DataView, EmptyState } from "@/components/DataState";
import { Dialog } from "@/components/Dialog";
import { CheckboxGroup, Field, FormAlert, apiFieldErrors } from "@/components/Form";
import { RequireAuth } from "@/components/Guard";
import { PageHeader, Pagination, StatusBadge } from "@/components/Misc";
import { CaseAnswers } from "@/pages/cases/CasePages";
import { useAsync } from "@/hooks/useAsync";
import { setFlash } from "@/lib/flash";
import { shortId } from "@/lib/password";

export function AdminOnly({ children }: { children: ReactNode }) {
  return <RequireAuth role="admin">{children}</RequireAuth>;
}

// ---------------- Dashboard ----------------

function Dashboard() {
  const { t, formatNumber, formatPercent } = useI18n();
  const state = useAsync(() => adminService.dashboard(), []);
  return (
    <div className="container">
      <PageHeader title={t("admin.dashboardTitle")} />
      <DataView state={state}>
        {(d) => (
          <>
            <ul className="stat-grid">
              {[
                [t("admin.activeLawyers"), formatNumber(d.active_lawyers)],
                [t("admin.inactiveLawyers"), formatNumber(d.inactive_lawyers)],
                [t("admin.activeCategories"), formatNumber(d.active_categories)],
                [t("admin.taxonomyVersion"), `v${d.taxonomy_version}`],
                [t("admin.totalCases"), formatNumber(d.total_cases)],
                [t("admin.unclassifiedCases"), formatNumber(d.unclassified_cases)],
                [t("admin.casesLast7"), formatNumber(d.cases_last_7_days)],
                [t("admin.latestAccuracy"), d.latest_accuracy === null ? "—" : formatPercent(d.latest_accuracy)],
              ].map(([label, value]) => (
                <li key={label} className="card stat">
                  <span className="stat-value">{value}</span>
                  <span className="stat-label">{label}</span>
                </li>
              ))}
            </ul>
            <h2>{t("admin.quickLinks")}</h2>
            <div className="row-wrap">
              <Link to="/admin/lawyers" className="btn btn-secondary">{t("admin.manageLawyers")}</Link>
              <Link to="/admin/categories" className="btn btn-secondary">{t("admin.manageCategories")}</Link>
              <Link to="/admin/cases" className="btn btn-secondary">{t("admin.browseCases")}</Link>
              <Link to="/admin/metrics" className="btn btn-secondary">{t("admin.viewMetrics")}</Link>
            </div>
          </>
        )}
      </DataView>
    </div>
  );
}
export const AdminDashboardPage = () => <AdminOnly><Dashboard /></AdminOnly>;

// ---------------- Lawyers list ----------------

function Lawyers() {
  const { t, formatCurrency, languageName } = useI18n();
  const settings = useSettings();
  const empty = { q: "", category_id: "", city: "", language: "", format: "", active: "" };
  const [f, setF] = useState(empty);
  const [q, setQ] = useState("");
  const [page, setPage] = useState(1);
  const cats = useAsync(() => categoriesService.adminList(), []);
  const state = useAsync(
    () =>
      lawyersService.list({
        ...(f.q ? { q: f.q } : {}),
        ...(f.category_id ? { category_id: f.category_id } : {}),
        ...(f.city ? { city: f.city } : {}),
        ...(f.language ? { language: f.language as LanguageCode } : {}),
        ...(f.format ? { format: f.format as ConsultationFormat } : {}),
        ...(f.active ? { active: f.active === "true" } : {}),
        page,
        page_size: settings.page_size_admin_lawyers,
      }),
    [f, page],
  );
  const set = (k: keyof typeof empty, v: string) => {
    setF({ ...f, [k]: v });
    setPage(1);
  };
  const catName = (id: string) => cats.data?.items.find((c) => c.id === id)?.name ?? "";
  return (
    <div className="container">
      <PageHeader title={t("adminLawyers.title")}>
        <Link to="/admin/lawyers/new" className="btn btn-primary">+ {t("adminLawyers.new")}</Link>
      </PageHeader>
      <form className="filters" role="search" onSubmit={(e) => { e.preventDefault(); set("q", q); }}>
        <label className="field-inline grow">
          <span className="label">{t("adminLawyers.search")}</span>
          <input className="input" type="search" value={q} onChange={(e) => setQ(e.target.value)} />
        </label>
        <button type="submit" className="btn btn-secondary">{t("common.search")}</button>
        <label className="field-inline">
          <span className="label">{t("adminLawyers.category")}</span>
          <select className="input" value={f.category_id} onChange={(e) => set("category_id", e.target.value)}>
            <option value="">{t("common.all")}</option>
            {cats.data?.items.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </label>
        <label className="field-inline">
          <span className="label">{t("adminLawyers.city")}</span>
          <select className="input" value={f.city} onChange={(e) => set("city", e.target.value)}>
            <option value="">{t("common.all")}</option>
            {["Budapest", "Debrecen", "Szeged", "Pécs", "Győr", "Miskolc"].map((c) => <option key={c}>{c}</option>)}
          </select>
        </label>
        <label className="field-inline">
          <span className="label">{t("adminLawyers.language")}</span>
          <select className="input" value={f.language} onChange={(e) => set("language", e.target.value)}>
            <option value="">{t("common.all")}</option>
            {LANGUAGE_CODES.map((l) => <option key={l} value={l}>{languageName(l)}</option>)}
          </select>
        </label>
        <label className="field-inline">
          <span className="label">{t("adminLawyers.format")}</span>
          <select className="input" value={f.format} onChange={(e) => set("format", e.target.value)}>
            <option value="">{t("common.all")}</option>
            {CONSULTATION_FORMATS.map((x) => <option key={x} value={x}>{t(`formats.${x}`)}</option>)}
          </select>
        </label>
        <label className="field-inline">
          <span className="label">{t("adminLawyers.status")}</span>
          <select className="input" value={f.active} onChange={(e) => set("active", e.target.value)}>
            <option value="">{t("common.all")}</option>
            <option value="true">{t("adminLawyers.activeOnly")}</option>
            <option value="false">{t("adminLawyers.inactiveOnly")}</option>
          </select>
        </label>
        <button type="button" className="btn btn-ghost btn-sm" onClick={() => { setF(empty); setQ(""); setPage(1); }}>{t("common.clearFilters")}</button>
      </form>
      <DataView state={state}>
        {(data) => data.items.length === 0 ? <EmptyState title={t("adminLawyers.empty")} /> : (
          <>
            <p className="hint">{t("common.total", { count: data.total })}</p>
            <div className="table-wrap">
              <table className="table">
                <thead>
                  <tr>
                    <th scope="col">{t("adminLawyers.name")}</th>
                    <th scope="col">{t("adminLawyers.city")}</th>
                    <th scope="col">{t("adminLawyers.expertise")}</th>
                    <th scope="col">{t("adminLawyers.languages")}</th>
                    <th scope="col">{t("adminLawyers.formats")}</th>
                    <th scope="col">{t("adminLawyers.price")}</th>
                    <th scope="col">{t("adminLawyers.status")}</th>
                    <th scope="col"><span className="sr-only">{t("common.actions")}</span></th>
                  </tr>
                </thead>
                <tbody>
                  {data.items.map((l) => (
                    <tr key={l.id}>
                      <td><strong>{l.name}</strong><br /><span className="hint">{l.email}</span></td>
                      <td>{l.city}</td>
                      <td>{l.category_ids.map(catName).join(", ")}</td>
                      <td>{l.languages.map((x) => x.toUpperCase()).join(", ")}</td>
                      <td>{l.consultation_formats.map((x) => t(`formats.${x}`)).join(", ")}</td>
                      <td>{formatCurrency(l.price_per_hour)}</td>
                      <td><span className={`badge ${l.active ? "badge-lawyer_chosen" : "badge-unclassified"}`}>{l.active ? t("adminLawyers.active") : t("adminLawyers.inactive")}</span></td>
                      <td><Link to="/admin/lawyers/$lawyerId" params={{ lawyerId: l.id }} className="btn btn-secondary btn-sm">{t("common.edit")}<span className="sr-only">: {l.name}</span></Link></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <Pagination page={data.page} pageSize={data.page_size} total={data.total} onPage={setPage} />
          </>
        )}
      </DataView>
    </div>
  );
}
export const AdminLawyersPage = () => <AdminOnly><Lawyers /></AdminOnly>;

// ---------------- Lawyer form ----------------

const EMPTY_LAWYER: LawyerInput = {
  name: "", phone: "", email: "", website: null, booking_url: null, office_address: "", city: "",
  category_ids: [], languages: ["hu"], consultation_formats: [], price_per_hour: 0, active: true,
};

function LawyerForm({ initial }: { initial: Lawyer | null }) {
  const { t, languageName } = useI18n();
  const router = useRouter();
  const cats = useAsync(() => categoriesService.list(), []);
  const [form, setForm] = useState<LawyerInput>(() => (initial ? { ...EMPTY_LAWYER, ...initial } : EMPTY_LAWYER));
  const [price, setPrice] = useState(initial ? String(initial.price_per_hour) : "");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [msg, setMsg] = useState<{ tone: "error" | "success"; text: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const set = <K extends keyof LawyerInput>(k: K, v: LawyerInput[K]) => setForm((f) => ({ ...f, [k]: v }));

  const validate = (): Record<string, string> => {
    const e: Record<string, string> = {};
    const req = t("validation.required");
    if (!form.name.trim()) e["name"] = req;
    if (!form.phone.trim()) e["phone"] = req;
    else if (!/^\+?[0-9 ()/-]{7,20}$/.test(form.phone.trim())) e["phone"] = t("validation.phone");
    if (!form.email.trim()) e["email"] = req;
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(form.email.trim())) e["email"] = t("validation.emailFormat");
    if (form.website && !/^https?:\/\//.test(form.website)) e["website"] = t("validation.url");
    if (form.booking_url && !/^https?:\/\//.test(form.booking_url)) e["booking_url"] = t("validation.url");
    if (!form.office_address.trim()) e["office_address"] = req;
    if (!form.city.trim()) e["city"] = req;
    if (form.category_ids.length === 0) e["category_ids"] = t("validation.selectAtLeastOne");
    if (form.languages.length === 0) e["languages"] = t("validation.selectAtLeastOne");
    if (form.consultation_formats.length === 0) e["consultation_formats"] = t("validation.selectAtLeastOne");
    const p = Number(price.replace(/\s/g, ""));
    if (!Number.isInteger(p) || p <= 0) e["price_per_hour"] = t("validation.positiveNumber");
    return e;
  };

  const submit = async (ev: FormEvent) => {
    ev.preventDefault();
    const e = validate();
    setErrors(e);
    if (Object.keys(e).length) return setMsg({ tone: "error", text: t("errors.fixFields") });
    setBusy(true);
    setMsg(null);
    const body: LawyerInput = {
      ...form,
      website: form.website?.trim() || null,
      booking_url: form.booking_url?.trim() || null,
      price_per_hour: Number(price.replace(/\s/g, "")),
    };
    try {
      if (initial) {
        await lawyersService.update(initial.id, body);
        setMsg({ tone: "success", text: t("lawyerForm.saved") });
      } else {
        const created = await lawyersService.create(body);
        setFlash(t("lawyerForm.created"));
        void router.navigate({ to: "/admin/lawyers/$lawyerId", params: { lawyerId: created.id } });
      }
    } catch (err) {
      setErrors(apiFieldErrors(err));
      setMsg({ tone: "error", text: t("errors.fixFields") });
    } finally {
      setBusy(false);
    }
  };

  const text = (k: "name" | "phone" | "email" | "office_address" | "city", label: string, type = "text") => (
    <Field label={label} error={errors[k]}>
      {(a) => <input {...a} className="input" type={type} value={form[k]} onChange={(e) => set(k, e.target.value)} />}
    </Field>
  );

  return (
    <div className="container narrow">
      <p><Link to="/admin/lawyers">← {t("lawyerForm.back")}</Link></p>
      <h1>{initial ? t("lawyerForm.titleEdit") : t("lawyerForm.titleNew")}</h1>
      <FormAlert tone={msg?.tone ?? "error"} message={msg?.text ?? null} />
      <form className="card stack" onSubmit={(e) => void submit(e)} noValidate>
        {text("name", t("lawyerForm.name"))}
        <div className="grid-2">
          {text("phone", t("lawyerForm.phone"), "tel")}
          {text("email", t("lawyerForm.email"), "email")}
        </div>
        <div className="grid-2">
          <Field label={t("lawyerForm.website")} optional error={errors["website"]}>
            {(a) => <input {...a} className="input" type="url" value={form.website ?? ""} onChange={(e) => set("website", e.target.value)} />}
          </Field>
          <Field label={t("lawyerForm.booking")} optional error={errors["booking_url"]}>
            {(a) => <input {...a} className="input" type="url" value={form.booking_url ?? ""} onChange={(e) => set("booking_url", e.target.value)} />}
          </Field>
        </div>
        {text("office_address", t("lawyerForm.address"))}
        {text("city", t("lawyerForm.city"))}
        <CheckboxGroup
          legend={t("lawyerForm.expertise")}
          options={(cats.data?.items ?? []).map((c) => ({ value: c.id, label: c.name }))}
          value={form.category_ids}
          onChange={(v) => set("category_ids", v)}
          error={errors["category_ids"]}
        />
        <CheckboxGroup
          legend={t("lawyerForm.languages")}
          options={LANGUAGE_CODES.map((l) => ({ value: l, label: languageName(l) }))}
          value={form.languages}
          onChange={(v) => set("languages", v)}
          error={errors["languages"]}
        />
        <CheckboxGroup
          legend={t("lawyerForm.formats")}
          options={CONSULTATION_FORMATS.map((x) => ({ value: x, label: t(`formats.${x}`) }))}
          value={form.consultation_formats}
          onChange={(v) => set("consultation_formats", v)}
          error={errors["consultation_formats"]}
        />
        <Field label={t("lawyerForm.price")} error={errors["price_per_hour"]}>
          {(a) => <input {...a} className="input input-narrow" inputMode="numeric" value={price} onChange={(e) => setPrice(e.target.value)} />}
        </Field>
        <label className="choice">
          <input type="checkbox" checked={form.active} onChange={(e) => set("active", e.target.checked)} />
          <span>{t("lawyerForm.active")}</span>
        </label>
        <div className="row">
          <button type="submit" className="btn btn-primary" disabled={busy}>{busy ? t("common.working") : t("common.save")}</button>
          <Link to="/admin/lawyers" className="btn btn-secondary">{t("common.cancel")}</Link>
        </div>
      </form>
    </div>
  );
}

export const AdminLawyerNewPage = () => <AdminOnly><LawyerForm initial={null} /></AdminOnly>;

function LawyerEdit({ lawyerId }: { lawyerId: string }) {
  const state = useAsync(() => lawyersService.get(lawyerId), [lawyerId]);
  return <DataView state={state}>{(l) => <LawyerForm key={l.id} initial={l} />}</DataView>;
}
export const AdminLawyerEditPage = ({ lawyerId }: { lawyerId: string }) => <AdminOnly><LawyerEdit lawyerId={lawyerId} /></AdminOnly>;

// ---------------- Categories ----------------

const EMPTY_CAT: CategoryInput = { code: "", name: "", plain_name: "", description: "", example_problems: [], active: true };

function CategoryEditor({ initial, onSaved, onCancel }: { initial: AdminCategory | null; onSaved: () => void; onCancel: () => void }) {
  const { t } = useI18n();
  const [form, setForm] = useState<CategoryInput>(initial ? { ...initial } : EMPTY_CAT);
  const [examples, setExamples] = useState((initial?.example_problems ?? []).join("\n"));
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [blocked, setBlocked] = useState<LawyerRefDto[] | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setBlocked(null);
    const body = { ...form, example_problems: examples.split("\n").map((x) => x.trim()).filter(Boolean) };
    try {
      if (initial) await categoriesService.update(initial.id, body);
      else await categoriesService.create(body);
      setFlash(t("adminCategories.saved"));
      onSaved();
    } catch (err) {
      if (isApiError(err) && err.code === "category_in_use") setBlocked(lawyersFrom(err.details));
      setErrors(apiFieldErrors(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <form className="card stack" onSubmit={(e) => void submit(e)} noValidate>
      <h2>{initial ? t("adminCategories.editTitle") : t("adminCategories.newTitle")}</h2>
      {blocked && <BlockedLawyers lawyers={blocked} />}
      <div className="grid-2">
        <Field label={t("adminCategories.code")} hint={t("adminCategories.codeHint")} error={errors["code"]}>
          {(a) => <input {...a} className="input" value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} />}
        </Field>
        <Field label={t("adminCategories.name")} error={errors["name"]}>
          {(a) => <input {...a} lang="hu" className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />}
        </Field>
      </div>
      <Field label={t("adminCategories.plainName")} error={errors["plain_name"]}>
        {(a) => <input {...a} lang="hu" className="input" value={form.plain_name} onChange={(e) => setForm({ ...form, plain_name: e.target.value })} />}
      </Field>
      <Field label={t("adminCategories.description")} error={errors["description"]}>
        {(a) => <textarea {...a} lang="hu" className="input textarea" rows={3} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />}
      </Field>
      <Field label={t("adminCategories.examples")} error={errors["example_problems"]}>
        {(a) => <textarea {...a} lang="hu" className="input textarea" rows={4} value={examples} onChange={(e) => setExamples(e.target.value)} />}
      </Field>
      <label className="choice">
        <input type="checkbox" checked={form.active} onChange={(e) => setForm({ ...form, active: e.target.checked })} />
        <span>{t("adminCategories.active")}</span>
      </label>
      <div className="row">
        <button type="submit" className="btn btn-primary" disabled={busy}>{t("common.save")}</button>
        <button type="button" className="btn btn-secondary" onClick={onCancel}>{t("common.cancel")}</button>
      </div>
    </form>
  );
}

function lawyersFrom(details: Record<string, unknown> | undefined): LawyerRefDto[] {
  const raw = details?.["lawyers"];
  return Array.isArray(raw)
    ? raw.filter((x): x is LawyerRefDto => typeof x === "object" && x !== null && "id" in x && "name" in x)
    : [];
}

function BlockedLawyers({ lawyers }: { lawyers: LawyerRefDto[] }) {
  const { t } = useI18n();
  return (
    <div className="alert alert-warning" role="alert">
      <p><strong>{t("adminCategories.inUseTitle")}</strong></p>
      <p>{t("adminCategories.inUseText")}</p>
      <ul>
        {lawyers.map((l) => (
          <li key={l.id}><Link to="/admin/lawyers/$lawyerId" params={{ lawyerId: l.id }}>{l.name}</Link></li>
        ))}
      </ul>
    </div>
  );
}

function Categories() {
  const { t, formatDateTime } = useI18n();
  const state = useAsync(() => categoriesService.adminList(), []);
  const versions = useAsync(() => categoriesService.versions(), []);
  const [editing, setEditing] = useState<AdminCategory | "new" | null>(null);
  const [toDelete, setToDelete] = useState<AdminCategory | null>(null);
  const [blocked, setBlocked] = useState<LawyerRefDto[] | null>(null);
  const [busy, setBusy] = useState(false);

  const reload = () => {
    setEditing(null);
    state.reload();
    versions.reload();
  };

  const remove = async () => {
    if (!toDelete) return;
    setBusy(true);
    try {
      await categoriesService.remove(toDelete.id);
      setToDelete(null);
      setFlash(t("adminCategories.deleted"));
      reload();
    } catch (err) {
      if (isApiError(err) && err.code === "category_in_use") setBlocked(lawyersFrom(err.details));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="container">
      <PageHeader title={t("adminCategories.title")}>
        <button type="button" className="btn btn-primary" onClick={() => setEditing("new")}>+ {t("adminCategories.new")}</button>
      </PageHeader>
      <DataView state={state}>
        {(data) => (
          <div className="stack">
            <div className="alert alert-info">
              <p><strong>{t("adminCategories.version", { version: data.taxonomy_version.version })}</strong></p>
              <p className="hint">{t("adminCategories.versionInfo", { date: formatDateTime(data.taxonomy_version.created_at), by: data.taxonomy_version.created_by, summary: data.taxonomy_version.change_summary })}</p>
            </div>
            {editing && <CategoryEditor key={editing === "new" ? "new" : editing.id} initial={editing === "new" ? null : editing} onSaved={reload} onCancel={() => setEditing(null)} />}
            <ul className="card-grid">
              {data.items.map((c) => (
                <li key={c.id} className="card stack-sm" lang="hu">
                  <div className="row-between">
                    <h2 className="h3">{c.name}</h2>
                    {!c.active && <span className="badge badge-unclassified">{t("adminCategories.inactiveBadge")}</span>}
                  </div>
                  <p className="hint"><code>{c.code}</code> · {c.plain_name} · {t("adminCategories.lawyers", { count: c.active_lawyer_count })}</p>
                  <p>{c.description}</p>
                  <details>
                    <summary>{t("adminCategories.examplesTitle")}</summary>
                    <ul>{c.example_problems.map((e) => <li key={e}>{e}</li>)}</ul>
                  </details>
                  <div className="row">
                    <button type="button" className="btn btn-secondary btn-sm" onClick={() => setEditing(c)}>{t("common.edit")}<span className="sr-only">: {c.name}</span></button>
                    <button type="button" className="btn btn-ghost btn-sm btn-danger-text" onClick={() => { setBlocked(null); setToDelete(c); }}>{t("common.delete")}<span className="sr-only">: {c.name}</span></button>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        )}
      </DataView>
      <section className="section">
        <h2>{t("adminCategories.history")}</h2>
        <DataView state={versions}>
          {(vs) => (
            <ol className="timeline">
              {vs.map((v) => (
                <li key={v.id}><strong>v{v.version}</strong> – {formatDateTime(v.created_at)} – {v.created_by}: <span lang="hu">{v.change_summary}</span></li>
              ))}
            </ol>
          )}
        </DataView>
      </section>
      <Dialog
        open={toDelete !== null}
        title={t("adminCategories.deleteTitle")}
        onClose={() => setToDelete(null)}
        actions={
          <>
            <button type="button" className="btn btn-secondary" onClick={() => setToDelete(null)}>{t("common.cancel")}</button>
            {!blocked && <button type="button" className="btn btn-danger" disabled={busy} onClick={() => void remove()}>{t("common.delete")}</button>}
          </>
        }
      >
        {blocked ? <BlockedLawyers lawyers={blocked} /> : toDelete && <p>{t("adminCategories.deleteText", { name: toDelete.name })}</p>}
      </Dialog>
    </div>
  );
}
export const AdminCategoriesPage = () => <AdminOnly><Categories /></AdminOnly>;

// ---------------- Cases ----------------

interface CaseFilters {
  q: string;
  category_id: string;
  status: CaseStatus | "";
  date_from: string;
  date_to: string;
  confidence_max: string;
  lawyer_id: string;
  has_documents: "" | "true" | "false";
}
const EMPTY_FILTERS: CaseFilters = { q: "", category_id: "", status: "", date_from: "", date_to: "", confidence_max: "", lawyer_id: "", has_documents: "" };

function Cases() {
  const { t, formatDateTime, formatPercent } = useI18n();
  const settings = useSettings();
  const [draft, setDraft] = useState<CaseFilters>(EMPTY_FILTERS);
  const [filters, setFilters] = useState<CaseFilters>(EMPTY_FILTERS);
  const [sort, setSort] = useState<{ by: AdminCaseSort; order: SortOrder }>({ by: "created_at", order: "desc" });
  const [page, setPage] = useState(1);
  const cats = useAsync(() => categoriesService.adminList(), []);
  const lawyers = useAsync(() => lawyersService.list({ page_size: 200 }), []);

  const query: AdminCaseQuery = {
    ...(filters.q ? { q: filters.q } : {}),
    ...(filters.category_id ? { category_id: filters.category_id } : {}),
    ...(filters.status ? { status: filters.status } : {}),
    ...(filters.date_from ? { date_from: filters.date_from } : {}),
    ...(filters.date_to ? { date_to: filters.date_to } : {}),
    ...(filters.confidence_max ? { confidence_max: Number(filters.confidence_max) } : {}),
    ...(filters.lawyer_id ? { lawyer_id: filters.lawyer_id } : {}),
    ...(filters.has_documents ? { has_documents: filters.has_documents === "true" } : {}),
    sort: sort.by,
    order: sort.order,
    page,
    page_size: settings.page_size_admin_cases,
  };
  const state = useAsync(() => adminService.listCases(query), [JSON.stringify(query)]);

  const apply = (e: FormEvent) => {
    e.preventDefault();
    setFilters(draft);
    setPage(1);
  };
  const clear = () => {
    setDraft(EMPTY_FILTERS);
    setFilters(EMPTY_FILTERS);
    setPage(1);
  };
  const toggleSort = (by: AdminCaseSort) => {
    setSort((s) => ({ by, order: s.by === by && s.order === "asc" ? "desc" : "asc" }));
    setPage(1);
  };
  const th = (by: AdminCaseSort, label: string) => (
    <th scope="col" aria-sort={sort.by === by ? (sort.order === "asc" ? "ascending" : "descending") : "none"}>
      <button type="button" className="sort-btn" onClick={() => toggleSort(by)}>
        {label} <span aria-hidden="true">{sort.by === by ? (sort.order === "asc" ? "▲" : "▼") : "↕"}</span>
        <span className="sr-only">{t("adminCases.sortBy", { column: label })}</span>
      </button>
    </th>
  );
  const d = (k: keyof CaseFilters, v: string) => setDraft({ ...draft, [k]: v });

  return (
    <div className="container wide">
      <PageHeader title={t("adminCases.title")} />
      <form className="card filters-panel" onSubmit={apply} aria-label={t("adminCases.filters")}>
        <label className="field-inline">
          <span className="label">{t("adminCases.user")}</span>
          <input className="input" type="search" value={draft.q} onChange={(e) => d("q", e.target.value)} />
        </label>
        <label className="field-inline">
          <span className="label">{t("adminCases.category")}</span>
          <select className="input" value={draft.category_id} onChange={(e) => d("category_id", e.target.value)}>
            <option value="">{t("common.all")}</option>
            {cats.data?.items.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </label>
        <label className="field-inline">
          <span className="label">{t("adminCases.status")}</span>
          <select className="input" value={draft.status} onChange={(e) => d("status", e.target.value)}>
            <option value="">{t("common.all")}</option>
            {CASE_STATUSES.map((s) => <option key={s} value={s}>{t(`status.${s}`)}</option>)}
          </select>
        </label>
        <label className="field-inline">
          <span className="label">{t("adminCases.dateFrom")}</span>
          <input className="input" type="date" value={draft.date_from} onChange={(e) => d("date_from", e.target.value)} />
        </label>
        <label className="field-inline">
          <span className="label">{t("adminCases.dateTo")}</span>
          <input className="input" type="date" value={draft.date_to} onChange={(e) => d("date_to", e.target.value)} />
        </label>
        <label className="field-inline">
          <span className="label">{t("adminCases.confidence")}</span>
          <select className="input" value={draft.confidence_max} onChange={(e) => d("confidence_max", e.target.value)}>
            <option value="">{t("adminCases.confAny")}</option>
            {[0.5, 0.7, 0.85].map((v) => <option key={v} value={String(v)}>{t("adminCases.confLow", { value: formatPercent(v) })}</option>)}
          </select>
        </label>
        <label className="field-inline">
          <span className="label">{t("adminCases.lawyer")}</span>
          <select className="input" value={draft.lawyer_id} onChange={(e) => d("lawyer_id", e.target.value)}>
            <option value="">{t("common.all")}</option>
            {lawyers.data?.items.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}
          </select>
        </label>
        <label className="field-inline">
          <span className="label">{t("adminCases.documents")}</span>
          <select className="input" value={draft.has_documents} onChange={(e) => d("has_documents", e.target.value)}>
            <option value="">{t("common.all")}</option>
            <option value="true">{t("adminCases.docsYes")}</option>
            <option value="false">{t("adminCases.docsNo")}</option>
          </select>
        </label>
        <div className="row filters-actions">
          <button type="submit" className="btn btn-primary">{t("common.search")}</button>
          <button type="button" className="btn btn-secondary" onClick={clear}>{t("common.clearFilters")}</button>
        </div>
      </form>
      <DataView state={state}>
        {(data) => (
          <>
            <p className="hint" aria-live="polite">{t("adminCases.results", { count: data.total })}</p>
            {data.items.length === 0 ? <EmptyState title={t("adminCases.empty")} /> : (
              <div className="table-wrap">
                <table className="table">
                  <thead>
                    <tr>
                      {th("created_at", t("adminCases.created"))}
                      {th("case_number", t("common.caseNumber"))}
                      {th("username", t("adminCases.username"))}
                      {th("category", t("adminCases.category"))}
                      {th("status", t("adminCases.status"))}
                      {th("chosen_lawyer", t("adminCases.lawyer"))}
                      {th("updated_at", t("adminCases.updated"))}
                    </tr>
                  </thead>
                  <tbody>
                    {data.items.map((r) => (
                      <tr key={r.id}>
                        <td>{formatDateTime(r.created_at)}</td>
                        <td><Link to="/admin/cases/$caseId" params={{ caseId: r.id }}><code>{shortId(r.id)}</code></Link></td>
                        <td>{r.username}</td>
                        <td>{r.category?.name ?? "—"}{r.confidence !== null && <span className="hint"> ({formatPercent(r.confidence)})</span>}</td>
                        <td><StatusBadge status={r.status} /></td>
                        <td>{r.chosen_lawyer_name ?? "—"}</td>
                        <td>{formatDateTime(r.updated_at)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            <Pagination page={data.page} pageSize={data.page_size} total={data.total} onPage={setPage} />
          </>
        )}
      </DataView>
    </div>
  );
}
export const AdminCasesPage = () => <AdminOnly><Cases /></AdminOnly>;

function AdminCase({ caseId }: { caseId: string }) {
  const { t, formatDate, formatDateTime, formatPercent, formatNumber, languageName, formatCurrency } = useI18n();
  const state = useAsync(() => adminService.getCase(caseId), [caseId]);
  return (
    <div className="container">
      <p><Link to="/admin/cases">← {t("adminCaseDetail.back")}</Link></p>
      <DataView state={state}>
        {(c) => (
          <div className="stack">
            <PageHeader title={`${t("adminCaseDetail.title")} · ${shortId(c.id)}`} />
            <div className="alert alert-info"><p>{t("adminCaseDetail.readOnly")}</p></div>
            <p className="row-wrap">
              <StatusBadge status={c.status} />
              <span className="hint">{t("adminCaseDetail.owner")}: <strong>{c.username}</strong> · {formatDateTime(c.created_at)}</span>
            </p>
            <section className="card">
              <h2>{t("adminCaseDetail.maskedDescription")}</h2>
              <p className="pre">{c.masked_description}</p>
            </section>
            <section className="card">
              <h2>{t("caseDetail.answers")}</h2>
              <CaseAnswers data={c} />
            </section>
            <section className="card">
              <h2>{t("caseDetail.documentData")}</h2>
              {c.files_deleted_at && <p className="alert alert-info">{t("caseDetail.filesDeleted", { date: formatDate(c.files_deleted_at) })}</p>}
              {c.documents.length === 0 ? <p className="hint">{t("caseDetail.noDocuments")}</p> : c.documents.map((d) => (
                <div key={d.id}>
                  <h3 className="h4">{t("adminCaseDetail.documentMeta", { type: d.content_type, size: `${formatNumber(Math.round(d.size_bytes / 1024))} KB`, date: formatDate(d.uploaded_at) })}</h3>
                  <dl className="dl">
                    {d.extracted_fields.map((f) => (
                      <div key={f.key} className="dl-row"><dt>{t(`wizard.fields.${f.key as "document_type"}`)}</dt><dd>{f.confirmed_value ?? f.value}</dd></div>
                    ))}
                  </dl>
                </div>
              ))}
            </section>
            <section className="card">
              <h2>{t("caseDetail.classification")}</h2>
              {c.classification ? (
                <dl className="dl">
                  <div className="dl-row"><dt>{t("caseDetail.classification")}</dt><dd>{c.classification.category ? `${c.classification.category.name} (${c.classification.category.code})` : t("status.unclassified")}</dd></div>
                  <div className="dl-row"><dt>{t("metrics.accuracy")}</dt><dd>{c.classification.confidence !== null ? formatPercent(c.classification.confidence) : "—"}</dd></div>
                  <div className="dl-row"><dt>{t("adminCaseDetail.method")}</dt><dd>{t(`adminCaseDetail.methods.${c.classification.method}`)}</dd></div>
                  <div className="dl-row"><dt>{t("adminCaseDetail.taxonomy")}</dt><dd>v{c.classification.taxonomy_version}</dd></div>
                </dl>
              ) : <p className="hint">{t("caseDetail.notClassified")}</p>}
            </section>
            {c.preferences && (
              <section className="card">
                <h2>{t("adminCaseDetail.preferences")}</h2>
                <dl className="dl">
                  <div className="dl-row"><dt>{t("wizard.city")}</dt><dd>{c.preferences.city || "—"}</dd></div>
                  <div className="dl-row"><dt>{t("wizard.languages")}</dt><dd>{c.preferences.languages.map(languageName).join(", ")}</dd></div>
                  <div className="dl-row"><dt>{t("wizard.format")}</dt><dd>{t(`formats.${c.preferences.consultation_format}`)}</dd></div>
                  <div className="dl-row"><dt>{t("wizard.maxPrice")}</dt><dd>{c.preferences.max_price !== null ? formatCurrency(c.preferences.max_price) : "—"}</dd></div>
                </dl>
              </section>
            )}
            {c.recommendations.length > 0 && (
              <section className="card">
                <h2>{t("caseDetail.recommendations")}</h2>
                <ol>
                  {c.recommendations.map((r) => (
                    <li key={r.id}>
                      <strong>{r.lawyer.name}</strong> – {r.summary}{" "}
                      <span className="hint">({r.criteria.map((x) => `${x.matched ? "✓" : "✗"} ${t(`wizard.criteria.${x.criterion}`, { value: "" }).replace(/:\s*$/, "")}`).join(" · ")})</span>
                      {!r.lawyer_active && <span className="badge badge-unclassified">{t("adminLawyers.inactive")}</span>}
                    </li>
                  ))}
                </ol>
                {c.chosen_lawyer && <p>{t("caseDetail.choice")}: {t("adminCaseDetail.chosen", { name: c.chosen_lawyer.name, rank: c.chosen_lawyer.rank, date: formatDateTime(c.chosen_lawyer.chosen_at) })}</p>}
              </section>
            )}
          </div>
        )}
      </DataView>
    </div>
  );
}
export const AdminCaseDetailPage = ({ caseId }: { caseId: string }) => <AdminOnly><AdminCase caseId={caseId} /></AdminOnly>;

// ---------------- Placeholders ----------------

function Placeholder({ title, story }: { title: string; story: string }) {
  const { t } = useI18n();
  return (
    <div className="container">
      <PageHeader title={title} />
      <EmptyState title={t("placeholder.text", { story })} />
    </div>
  );
}
export function AdminUsersPage() {
  const { t } = useI18n();
  return <AdminOnly><Placeholder title={t("placeholder.usersTitle")} story="US-48" /></AdminOnly>;
}
export function AdminWarningsPage() {
  const { t } = useI18n();
  return <AdminOnly><Placeholder title={t("placeholder.warningsTitle")} story="US-49" /></AdminOnly>;
}
export function AdminLogsPage() {
  const { t } = useI18n();
  return <AdminOnly><Placeholder title={t("placeholder.logsTitle")} story="US-37" /></AdminOnly>;
}
