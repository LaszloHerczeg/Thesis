import { Link, useRouter } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { isApiError } from "@/api";
import type { AccountStatus } from "@/api/types";
import { useApp, useSettings } from "@/context/AppContext";
import { useI18n } from "@/i18n";
import { Field, FormAlert, PasswordInput, StrengthMeter, apiFieldErrors } from "@/components/Form";
import { safeRedirect } from "@/components/Guard";
import { setAccountStatus, setFlash } from "@/lib/flash";

export interface AuthSearch {
  redirect?: string | undefined;
  from?: "screening" | undefined;
}

function useAfterAuth(search: AuthSearch) {
  const router = useRouter();
  return () => {
    if (search.from === "screening") router.history.push("/screening");
    else router.history.push(safeRedirect(search.redirect) ?? "/");
  };
}

export function RegisterPage({ search }: { search: AuthSearch }) {
  const { t } = useI18n();
  const settings = useSettings();
  const { register, user } = useApp();
  const after = useAfterAuth(search);
  const [form, setForm] = useState({ username: "", email: "", password: "", password_confirm: "", consent: false });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [summary, setSummary] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (user) after();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const set = <K extends keyof typeof form>(k: K, v: (typeof form)[K]) => setForm((f) => ({ ...f, [k]: v }));

  const validate = (): Record<string, string> => {
    const e: Record<string, string> = {};
    if (!/^[A-Za-z0-9_]{3,30}$/.test(form.username.trim())) e["username"] = t("validation.usernameFormat");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(form.email.trim())) e["email"] = t("validation.emailFormat");
    const len = [...form.password].length;
    if (len < settings.password_min_length) e["password"] = t("validation.passwordMin", { min: settings.password_min_length });
    else if (len > settings.password_max_length) e["password"] = t("validation.passwordMax", { max: settings.password_max_length });
    if (form.password !== form.password_confirm) e["password_confirm"] = t("validation.passwordMismatch");
    if (!form.consent) e["consent"] = t("validation.consentRequired");
    return e;
  };

  const submit = async (ev: FormEvent) => {
    ev.preventDefault();
    const e = validate();
    setErrors(e);
    if (Object.keys(e).length) {
      setSummary(t("errors.fixFields"));
      return;
    }
    setBusy(true);
    setSummary(null);
    try {
      const u = await register({ ...form, username: form.username.trim(), email: form.email.trim() });
      setFlash(t("auth.welcome", { name: u.username }));
      after();
    } catch (err) {
      const fe = apiFieldErrors(err);
      setErrors(fe);
      setSummary(Object.keys(fe).length ? t("errors.fixFields") : isApiError(err) && err.status === 429 ? null : t("errors.generic"));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="container narrow">
      {search.from === "screening" && <FormAlert tone="info" message={t("auth.screeningNotice")} />}
      <div className="page-header">
        <h1>{t("auth.registerTitle")}</h1>
        <Link to="/login" search={search} className="btn btn-secondary">{t("auth.alreadyRegistered")}</Link>
      </div>
      <FormAlert message={summary} />
      <form onSubmit={(e) => void submit(e)} className="card stack" noValidate>
        <Field label={t("auth.username")} hint={t("auth.usernameHint")} error={errors["username"]}>
          {(a) => <input {...a} className="input" autoComplete="username" value={form.username} onChange={(e) => set("username", e.target.value)} />}
        </Field>
        <Field label={t("auth.email")} error={errors["email"]}>
          {(a) => <input {...a} className="input" type="email" autoComplete="email" value={form.email} onChange={(e) => set("email", e.target.value)} />}
        </Field>
        <Field label={t("auth.password")} hint={t("auth.passwordHint", { min: settings.password_min_length })} error={errors["password"]}>
          {(a) => (
            <>
              <PasswordInput a11y={a} autoComplete="new-password" value={form.password} onChange={(v) => set("password", v)} />
              <StrengthMeter password={form.password} />
            </>
          )}
        </Field>
        <Field label={t("auth.passwordConfirm")} error={errors["password_confirm"]}>
          {(a) => <PasswordInput a11y={a} autoComplete="new-password" value={form.password_confirm} onChange={(v) => set("password_confirm", v)} />}
        </Field>
        <div className={`field ${errors["consent"] ? "field-invalid" : ""}`}>
          <label className="choice">
            <input
              type="checkbox"
              checked={form.consent}
              aria-invalid={errors["consent"] ? true : undefined}
              aria-describedby={errors["consent"] ? "consent-err" : undefined}
              onChange={(e) => set("consent", e.target.checked)}
            />
            <span>
              {t("auth.consentBefore")}
              <Link to="/privacy" target="_blank">{t("auth.consentLink")}</Link>
              {t("auth.consentAfter")}
            </span>
          </label>
          {errors["consent"] && <p id="consent-err" className="error-text" role="alert">{errors["consent"]}</p>}
        </div>
        <button type="submit" className="btn btn-primary" disabled={busy}>{busy ? t("common.working") : t("auth.submitRegister")}</button>
      </form>
    </div>
  );
}

export function LoginPage({ search }: { search: AuthSearch }) {
  const { t } = useI18n();
  const { login, user } = useApp();
  const router = useRouter();
  const after = useAfterAuth(search);
  const [form, setForm] = useState({ login: "", password: "" });
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (user) after();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const submit = async (ev: FormEvent) => {
    ev.preventDefault();
    if (!form.login.trim() || !form.password) {
      setError(t("auth.invalidCredentials"));
      return;
    }
    setBusy(true);
    setError(null);
    try {
      await login({ login: form.login.trim(), password: form.password });
      after();
    } catch (err) {
      if (isApiError(err) && err.status === 403 && err.code.startsWith("account_")) {
        const d = err.details ?? {};
        setAccountStatus({
          status: (typeof d["status"] === "string" ? d["status"] : "banned") as Exclude<AccountStatus, "active">,
          suspended_until: typeof d["suspended_until"] === "string" ? d["suspended_until"] : null,
        });
        void router.navigate({ to: "/account-status" });
        return;
      }
      if (isApiError(err) && err.code === "login_locked") setError(t("auth.locked", { seconds: err.retry_after ?? 60 }));
      else if (isApiError(err) && err.status === 401) setError(t("auth.invalidCredentials"));
      else setError(t("errors.generic"));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="container narrow">
      {search.from === "screening" && <FormAlert tone="info" message={t("auth.screeningNotice")} />}
      {search.redirect && search.from !== "screening" && <FormAlert tone="info" message={t("auth.loginRequired")} />}
      <h1>{t("auth.loginTitle")}</h1>
      <FormAlert message={error} />
      <form onSubmit={(e) => void submit(e)} className="card stack" noValidate>
        <Field label={t("auth.loginField")}>
          {(a) => <input {...a} className="input" autoComplete="username" value={form.login} onChange={(e) => setForm({ ...form, login: e.target.value })} />}
        </Field>
        <Field label={t("auth.password")}>
          {(a) => <PasswordInput a11y={a} autoComplete="current-password" value={form.password} onChange={(v) => setForm({ ...form, password: v })} />}
        </Field>
        <button type="submit" className="btn btn-primary" disabled={busy}>{busy ? t("common.working") : t("auth.submitLogin")}</button>
        <p className="row-between">
          <Link to="/forgot-password">{t("auth.forgot")}</Link>
          <Link to="/register" search={search}>{t("auth.noAccount")}</Link>
        </p>
      </form>
    </div>
  );
}
