import { useEffect, useState } from "react";
import { metricsService } from "@/api";
import type { EvaluationRunDetail } from "@/api/types";
import { useI18n } from "@/i18n";
import { DataView, EmptyState, Loading } from "@/components/DataState";
import { PageHeader } from "@/components/Misc";
import { useAsync } from "@/hooks/useAsync";
import { AdminOnly } from "./AdminPages";
import styles from "./Metrics.module.css";

function RunDetail({ run }: { run: EvaluationRunDetail }) {
  const { t, formatPercent, formatNumber, formatDateTime } = useI18n();
  const labels = run.confusion_matrix.labels.map((l) => (l.id === "unclassified" ? t("metrics.unclassified") : l.name));
  const max = Math.max(1, ...run.confusion_matrix.matrix.flat());
  return (
    <div className="stack">
      <p className="hint">{formatDateTime(run.created_at)} · {run.model_version} · v{run.taxonomy_version}</p>
      <ul className="stat-grid">
        <li className="card stat"><span className="stat-value">{formatPercent(run.overall_accuracy)}</span><span className="stat-label">{t("metrics.overall")}</span></li>
        <li className="card stat"><span className="stat-value">{formatPercent(run.low_confidence_fallback_rate)}</span><span className="stat-label">{t("metrics.fallbackRate")}</span></li>
        <li className="card stat"><span className="stat-value">{formatNumber(run.test_set_size)}</span><span className="stat-label">{t("metrics.testSet")}</span></li>
      </ul>
      <section className="card">
        <h2>{t("metrics.perCategory")}</h2>
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th scope="col">{t("adminCases.category")}</th>
                <th scope="col">{t("metrics.support")}</th>
                <th scope="col">{t("metrics.correct")}</th>
                <th scope="col">{t("metrics.accuracy")}</th>
              </tr>
            </thead>
            <tbody>
              {run.per_category.map((c) => (
                <tr key={c.category.id}>
                  <th scope="row">{c.category.name}</th>
                  <td>{c.support}</td>
                  <td>{c.correct}</td>
                  <td>
                    <div className={styles.barCell}>
                      <span className={styles.bar} style={{ inlineSize: `${Math.round(c.accuracy * 100)}%` }} aria-hidden="true" />
                      <span>{formatPercent(c.accuracy)}</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
      <section className="card">
        <h2>{t("metrics.confusion")}</h2>
        <p className="hint">{t("metrics.confusionHelp")}</p>
        <div className="table-wrap">
          <table className={`table ${styles.matrix}`}>
            <thead>
              <tr>
                <th scope="col">{t("metrics.expectedPredicted")}</th>
                {labels.map((l) => <th key={l} scope="col" className={styles.colHead}><span>{l}</span></th>)}
              </tr>
            </thead>
            <tbody>
              {run.confusion_matrix.matrix.map((row, i) => (
                <tr key={labels[i]}>
                  <th scope="row">{labels[i]}</th>
                  {row.map((v, j) => (
                    <td
                      key={j}
                      className={`${styles.cell} ${i === j ? styles.diag : v > 0 ? styles.miss : ""}`}
                      style={{ ["--heat" as string]: String(v / max) }}
                    >
                      {v}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}

function Metrics() {
  const { t, formatDateTime, formatPercent } = useI18n();
  const runs = useAsync(() => metricsService.listEvaluations(), []);
  const [selected, setSelected] = useState<string | null>(null);
  const [running, setRunning] = useState(false);
  const firstId = runs.data?.[0]?.id ?? null;
  const currentId = selected ?? firstId;

  useEffect(() => {
    if (selected === null && firstId) setSelected(firstId);
  }, [firstId, selected]);

  const detail = useAsync(() => (currentId ? metricsService.getEvaluation(currentId) : Promise.resolve(null)), [currentId]);

  const run = async () => {
    setRunning(true);
    try {
      const r = await metricsService.runEvaluation();
      setSelected(r.id);
      runs.reload();
    } finally {
      setRunning(false);
    }
  };

  return (
    <div className="container">
      <PageHeader title={t("metrics.title")}>
        <button type="button" className="btn btn-primary" disabled={running} onClick={() => void run()}>{running ? t("common.working") : t("metrics.run")}</button>
      </PageHeader>
      <p>{t("metrics.intro")}</p>
      {running && <Loading />}
      <DataView state={detail}>{(d) => (d ? <RunDetail run={d} /> : <EmptyState title={t("metrics.noRuns")} />)}</DataView>
      <section className="section">
        <h2>{t("metrics.runs")}</h2>
        <DataView state={runs}>
          {(list) => list.length === 0 ? <EmptyState title={t("metrics.noRuns")} /> : (
            <div className="table-wrap">
              <table className="table">
                <thead>
                  <tr>
                    <th scope="col">{t("metrics.date")}</th>
                    <th scope="col">{t("metrics.model")}</th>
                    <th scope="col">{t("metrics.taxonomy")}</th>
                    <th scope="col">{t("metrics.size")}</th>
                    <th scope="col">{t("metrics.accuracy")}</th>
                    <th scope="col">{t("metrics.fallback")}</th>
                    <th scope="col"><span className="sr-only">{t("common.actions")}</span></th>
                  </tr>
                </thead>
                <tbody>
                  {list.map((r) => (
                    <tr key={r.id} aria-current={r.id === currentId ? "true" : undefined} className={r.id === currentId ? styles.selected : ""}>
                      <td>{formatDateTime(r.created_at)}</td>
                      <td>{r.model_version}</td>
                      <td>v{r.taxonomy_version}</td>
                      <td>{r.test_set_size}</td>
                      <td>{formatPercent(r.overall_accuracy)}</td>
                      <td>{formatPercent(r.low_confidence_fallback_rate)}</td>
                      <td>
                        <button type="button" className="btn btn-secondary btn-sm" disabled={r.id === currentId} onClick={() => setSelected(r.id)}>
                          {r.id === currentId ? t("metrics.viewing") : t("metrics.view")}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </DataView>
      </section>
    </div>
  );
}

export const AdminMetricsPage = () => <AdminOnly><Metrics /></AdminOnly>;
