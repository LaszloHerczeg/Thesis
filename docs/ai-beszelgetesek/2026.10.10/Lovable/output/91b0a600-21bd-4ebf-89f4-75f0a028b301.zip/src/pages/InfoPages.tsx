import { Link } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { useI18n } from "@/i18n";
import { Field, FormAlert } from "@/components/Form";
import { getAccountStatus } from "@/lib/flash";

export function DisclaimerPage() {
  const { t } = useI18n();
  return (
    <article className="container prose">
      <h1>{t("disclaimerPage.title")}</h1>
      <p>{t("disclaimerPage.p1")}</p>
      <p>{t("disclaimerPage.p2")}</p>
      <p>{t("disclaimerPage.p3")}</p>
      <p>{t("disclaimerPage.p4")}</p>
    </article>
  );
}

export function PrivacyPage() {
  const { t } = useI18n();
  return (
    <article className="container prose">
      <h1>{t("privacyPage.title")}</h1>
      <p>{t("privacyPage.intro")}</p>
      {([1, 2, 3, 4] as const).map((n) => (
        <section key={n}>
          <h2>{t(`privacyPage.s${n}Title`)}</h2>
          <p>{t(`privacyPage.s${n}`)}</p>
        </section>
      ))}
    </article>
  );
}

export function ForgotPasswordPage() {
  const { t } = useI18n();
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const submit = (e: FormEvent) => {
    e.preventDefault();
    setSent(true);
  };
  return (
    <div className="container narrow">
      <h1>{t("auth.forgotTitle")}</h1>
      <p>{t("auth.forgotText")}</p>
      <FormAlert tone="info" message={t("auth.forgotPlaceholder")} />
      <form onSubmit={submit} className="card stack" noValidate>
        <Field label={t("auth.email")}>
          {(a) => <input {...a} className="input" type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} />}
        </Field>
        <button type="submit" className="btn btn-primary" disabled={sent}>{t("auth.forgotSubmit")}</button>
      </form>
      <p><Link to="/login" search={{}}>{t("auth.backToLogin")}</Link></p>
    </div>
  );
}

export function AccountStatusPage() {
  const { t, formatDateTime } = useI18n();
  const s = getAccountStatus();
  const message = !s
    ? t("accountStatus.unknown")
    : s.status === "suspended" && s.suspended_until
      ? t("accountStatus.suspended", { date: formatDateTime(s.suspended_until) })
      : s.status === "suspended_auto"
        ? t("accountStatus.suspendedAuto")
        : s.status === "banned"
          ? t("accountStatus.banned")
          : t("accountStatus.unknown");
  return (
    <section className="container narrow status-page">
      <h1>{t("accountStatus.title")}</h1>
      <div className="alert alert-warning" role="alert"><p>{message}</p></div>
      <p>{t("accountStatus.contact", { email: "segitseg@jogutmutato.example.hu" })}</p>
      <Link to="/" className="btn btn-secondary">{t("errors.goHome")}</Link>
    </section>
  );
}
