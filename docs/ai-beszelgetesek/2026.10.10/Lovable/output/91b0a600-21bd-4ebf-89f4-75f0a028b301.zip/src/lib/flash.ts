/** One-shot in-memory messages shown after navigation (e.g. welcome after sign-up). */
import type { AccountStatusErrorDetail } from "@/api/types";

type Listener = (msg: string | null) => void;
let current: string | null = null;
const listeners = new Set<Listener>();

export function setFlash(msg: string | null): void {
  current = msg;
  listeners.forEach((l) => l(msg));
}
export function subscribeFlash(l: Listener): () => void {
  listeners.add(l);
  l(current);
  return () => {
    listeners.delete(l);
  };
}

/** Account status from a blocked log-in, kept in memory only (never in browser storage). */
let accountStatus: Pick<AccountStatusErrorDetail, "status" | "suspended_until"> | null = null;
export function setAccountStatus(s: typeof accountStatus): void {
  accountStatus = s;
}
export function getAccountStatus(): typeof accountStatus {
  return accountStatus;
}
