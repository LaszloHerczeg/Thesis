/** Client-side strength estimate for the live indicator only. The server decides. */
const COMMON = ["password", "12345678", "123456789", "qwertyui", "qwertzui", "iloveyou", "jelszo", "jelszó", "admin123", "letmein", "11111111", "abcd1234"];

export function passwordStrength(pw: string): { score: 0 | 1 | 2 | 3 | 4; common: boolean } {
  const lower = pw.toLowerCase();
  const common = pw.length > 0 && COMMON.some((c) => lower.includes(c));
  if (!pw) return { score: 0, common: false };
  let variety = 0;
  if (/[a-záéíóöőúüű]/.test(pw)) variety++;
  if (/[A-ZÁÉÍÓÖŐÚÜŰ]/.test(pw)) variety++;
  if (/\d/.test(pw)) variety++;
  if (/[^\p{L}\d]/u.test(pw)) variety++;
  const len = [...pw].length;
  let s = len >= 20 ? 4 : len >= 14 ? 3 : len >= 10 ? 2 : len >= 8 ? 1 : 0;
  if (variety >= 3 && s < 4 && len >= 8) s++;
  if (common) s = Math.min(s, 1);
  return { score: Math.max(0, Math.min(4, s)) as 0 | 1 | 2 | 3 | 4, common };
}

export const shortId = (id: string): string => id.slice(0, 8);
