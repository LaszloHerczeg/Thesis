import { audit, type Db, type DbUser } from "../db";
import { MockResult, fail, obj, requireUser, route, str, toUserDto, tr, validation, type Ctx } from "../router";
import { MOCK_SERVER_RULES } from "../settings";
import { checkEmail, checkPassword, checkUsername, normaliseEmail } from "../validators";

function startSession(db: Db, u: DbUser): void {
  const now = new Date().toISOString();
  const id = crypto.randomUUID();
  db.sessions.push({ id, user_id: u.id, created_at: now, last_seen_at: now });
  db.cookie_session_id = id;
}

route("GET", "/auth/csrf", "public", (ctx) => {
  ctx.db.csrf_token = crypto.randomUUID();
  return { csrf_token: ctx.db.csrf_token };
});

route("GET", "/auth/me", "user", (ctx) => toUserDto(requireUser(ctx)));

route("POST", "/auth/register", "public", (ctx) => {
  const b = obj(ctx.body);
  const username = str(b, "username").trim();
  const email = str(b, "email");
  const password = str(b, "password");
  const confirm = str(b, "password_confirm");
  const db = ctx.db;

  const errors: [string, string][] = [];
  let conflict = false;
  let banned = false;
  const u = checkUsername(ctx, username, db);
  if (u) {
    errors.push(["username", u]);
    if (/foglalt|taken/.test(u)) conflict = true;
  }
  const e = checkEmail(ctx, email, db);
  if (e) {
    errors.push(["email", e.msg]);
    if (e.code === "email_taken") conflict = true;
    if (e.code === "email_banned") {
      banned = true;
      audit(db, "visitor", "registration_blocked_banned_email", normaliseEmail(email));
    }
  }
  const p = checkPassword(ctx, password, username, email);
  if (p) errors.push(["password", p]);
  else if (password !== confirm) errors.push(["password_confirm", tr(ctx, "A két jelszó nem egyezik.", "The two passwords do not match.")]);
  if (b["consent"] !== true) {
    errors.push(["consent", tr(ctx, "A regisztrációhoz el kell fogadnia az adatkezelési tájékoztatót.", "You must accept the privacy policy to register.")]);
  }
  if (errors.length) {
    if (conflict || banned) {
      throw fail(conflict ? 409 : 422, banned ? "email_banned" : "conflict", errors[0]?.[1] ?? "", { field_errors: Object.fromEntries(errors) });
    }
    throw validation(errors);
  }
  const now = new Date().toISOString();
  const user: DbUser = {
    id: crypto.randomUUID(),
    username,
    email: normaliseEmail(email),
    password_hash: `mock$${password}`,
    role: "client",
    status: "active",
    suspended_until: null,
    consent_given: true,
    consent_given_at: now,
    created_at: now,
    failed_logins: 0,
    locked_until: null,
  };
  db.users.push(user);
  startSession(db, user);
  audit(db, username, "register", user.id);
  return new MockResult(201, toUserDto(user));
});

route("POST", "/auth/login", "public", (ctx: Ctx) => {
  const b = obj(ctx.body);
  const login = str(b, "login").trim().toLowerCase();
  const password = str(b, "password");
  const db = ctx.db;
  const generic = () => fail(401, "invalid_credentials", tr(ctx, "A felhasználónév/e-mail-cím vagy a jelszó helytelen.", "Username/email or password is incorrect."));
  if (!login || !password) throw generic();
  const user = db.users.find((u) => u.username.toLowerCase() === login || normaliseEmail(u.email) === login);
  if (!user) throw generic();

  if (user.locked_until && new Date(user.locked_until).getTime() > Date.now()) {
    const seconds = Math.ceil((new Date(user.locked_until).getTime() - Date.now()) / 1000);
    throw fail(429, "login_locked", tr(ctx, "Túl sok sikertelen próbálkozás.", "Too many failed attempts."), { retry_after: seconds }, { "retry-after": String(seconds) });
  }
  if (user.password_hash !== `mock$${password}`) {
    user.failed_logins += 1;
    if (user.failed_logins >= MOCK_SERVER_RULES.login_max_failures) {
      user.failed_logins = 0;
      user.locked_until = new Date(Date.now() + MOCK_SERVER_RULES.login_lockout_seconds * 1000).toISOString();
      const seconds = MOCK_SERVER_RULES.login_lockout_seconds;
      throw fail(429, "login_locked", tr(ctx, "Túl sok sikertelen próbálkozás.", "Too many failed attempts."), { retry_after: seconds }, { "retry-after": String(seconds) });
    }
    throw generic();
  }
  user.failed_logins = 0;
  user.locked_until = null;

  if (user.status === "suspended" && user.suspended_until && new Date(user.suspended_until).getTime() <= Date.now()) {
    user.status = "active";
    user.suspended_until = null;
  }
  if (user.status !== "active") {
    audit(db, user.username, "login_blocked", user.status);
    const code = user.status === "suspended" ? "account_suspended" : user.status === "suspended_auto" ? "account_suspended_auto" : "account_banned";
    throw fail(403, code, tr(ctx, "A fiók nem használható.", "The account cannot be used."), { status: user.status, suspended_until: user.suspended_until });
  }
  startSession(db, user);
  audit(db, user.username, "login", user.id);
  return toUserDto(user);
});

route("POST", "/auth/logout", "public", (ctx) => {
  ctx.db.sessions = ctx.db.sessions.filter((s) => s.id !== ctx.db.cookie_session_id);
  ctx.db.cookie_session_id = null;
  return new MockResult(204, undefined);
});

route("POST", "/auth/password-reset", "public", (ctx) => {
  return new MockResult(202, {
    message: tr(ctx, "Ha létezik ilyen fiók, elküldtük a visszaállítási linket.", "If an account exists, we have sent a reset link."),
  });
});
