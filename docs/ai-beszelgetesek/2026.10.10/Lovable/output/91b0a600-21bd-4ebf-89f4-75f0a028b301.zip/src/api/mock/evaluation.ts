import type { Category, ConfusionMatrix, EvaluationRunDetail, QuestionRound } from "../types";
import { classify, toRef } from "./engine";

interface TestItem {
  text: string;
  expected_code: string | null;
}

const OUT_OF_SCOPE: TestItem[] = [
  { text: "Hogyan kérhetek új útlevelet egy külföldi utazás előtt?", expected_code: null },
  { text: "Szeretnék marketingtanácsot kapni az induló kisvállalkozásomhoz.", expected_code: null },
  { text: "Elromlott a számítógépem, és nem tudom, hogyan mentsem meg a fájljaimat.", expected_code: null },
];

/** Labelled test set: every category's example problems + out-of-scope items. */
export function buildTestSet(categories: Category[]): TestItem[] {
  const items: TestItem[] = [];
  for (const c of categories.filter((x) => x.active)) {
    for (const e of c.example_problems) items.push({ text: e, expected_code: c.code });
  }
  return [...items, ...OUT_OF_SCOPE];
}

function finalRounds(maxRounds: number): QuestionRound[] {
  return Array.from({ length: maxRounds }, (_, i) => ({ round: i + 1, questions: [], submitted_at: new Date().toISOString() }));
}

function finish(
  base: Omit<EvaluationRunDetail, "overall_accuracy" | "low_confidence_fallback_rate" | "per_category" | "test_set_size">,
  categories: Category[],
  matrix: number[][],
): EvaluationRunDetail {
  const active = categories.filter((c) => c.active);
  const n = active.length;
  let total = 0;
  let correct = 0;
  let fallback = 0;
  matrix.forEach((row, i) => {
    row.forEach((v, j) => {
      total += v;
      if (i === j) correct += v;
      if (j === n) fallback += v;
    });
  });
  const per_category = active.map((c, i) => {
    const row = matrix[i] ?? [];
    const support = row.reduce((a, b) => a + b, 0);
    const ok = row[i] ?? 0;
    return { category: toRef(c), support, correct: ok, accuracy: support ? ok / support : 0 };
  });
  return {
    ...base,
    test_set_size: total,
    overall_accuracy: total ? correct / total : 0,
    low_confidence_fallback_rate: total ? fallback / total : 0,
    per_category,
  };
}

export function runEvaluation(
  categories: Category[],
  taxonomyVersion: number,
  maxRounds: number,
  modelVersion: string,
  createdAt: string,
  degrade = 0,
): EvaluationRunDetail {
  const active = categories.filter((c) => c.active);
  const labels: ConfusionMatrix["labels"] = [
    ...active.map((c) => ({ id: c.id, name: c.name })),
    { id: "unclassified", name: "unclassified" },
  ];
  const size = labels.length;
  const matrix: number[][] = Array.from({ length: size }, () => Array.from({ length: size }, () => 0));
  for (const item of buildTestSet(categories)) {
    const result = classify({ description: item.text, documents: [], rounds: finalRounds(maxRounds) }, categories, taxonomyVersion, maxRounds);
    const expected = item.expected_code === null ? size - 1 : active.findIndex((c) => c.code === item.expected_code);
    const predicted = result.result === "classified" && result.category
      ? active.findIndex((c) => c.id === result.category?.id)
      : size - 1;
    const row = matrix[expected < 0 ? size - 1 : expected];
    if (row) row[predicted < 0 ? size - 1 : predicted] = (row[predicted < 0 ? size - 1 : predicted] ?? 0) + 1;
  }
  // Older simulated runs: move some correct answers to mistakes.
  for (let k = 0; k < degrade; k++) {
    const i = k % (size - 1);
    const row = matrix[i];
    if (!row || (row[i] ?? 0) === 0) continue;
    row[i] = (row[i] ?? 0) - 1;
    const wrong = k % 2 === 0 ? size - 1 : (i + 1) % (size - 1);
    row[wrong] = (row[wrong] ?? 0) + 1;
  }
  return finish(
    {
      id: crypto.randomUUID(),
      created_at: createdAt,
      model_version: modelVersion,
      taxonomy_version: taxonomyVersion,
      confusion_matrix: { labels, matrix },
    },
    categories,
    matrix,
  );
}
