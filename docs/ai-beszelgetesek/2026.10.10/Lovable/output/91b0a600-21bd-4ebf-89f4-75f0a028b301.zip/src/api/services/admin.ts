import { http } from "../http";
import type { AdminCaseDetail, AdminCaseQuery, AdminCaseRow, AdminDashboard, Page } from "../types";

export const adminService = {
  dashboard: (): Promise<AdminDashboard> => http.get<AdminDashboard>("/admin/dashboard"),
  /** Filtering, sorting and paging are done by the server via query parameters. */
  listCases: (query: AdminCaseQuery): Promise<Page<AdminCaseRow>> => http.get<Page<AdminCaseRow>>("/admin/cases", { query: { ...query } }),
  getCase: (caseId: string): Promise<AdminCaseDetail> => http.get<AdminCaseDetail>(`/admin/cases/${encodeURIComponent(caseId)}`),
};
