import { http } from "../http";
import type { EvaluationRun, EvaluationRunDetail } from "../types";

export const metricsService = {
  listEvaluations: (): Promise<EvaluationRun[]> => http.get<EvaluationRun[]>("/admin/metrics/evaluations"),
  getEvaluation: (runId: string): Promise<EvaluationRunDetail> =>
    http.get<EvaluationRunDetail>(`/admin/metrics/evaluations/${encodeURIComponent(runId)}`),
  runEvaluation: (): Promise<EvaluationRunDetail> => http.post<EvaluationRunDetail>("/admin/metrics/evaluations"),
};
