/**
 * In-browser mock server. Receives the same requests the real backend would
 * (method, path, query, headers incl. CSRF, JSON / FormData body) and answers
 * with status, headers and JSON body — enforcing the same rules.
 */
import { config } from "@/config";
import type { TransportRequest, TransportResponse } from "../http";
import { loadDb, saveDb } from "./db";
import { HttpError, MockResult, matchRoute, type Ctx } from "./router";
import { DEFAULT_SETTINGS } from "./settings";
import "./handlers/auth";
import "./handlers/account";
import "./handlers/catalog";
import "./handlers/cases";
import "./handlers/admin";
import "./handlers/metrics";

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

function clone<T>(v: T): T {
  return v === undefined ? v : (JSON.parse(JSON.stringify(v)) as T);
}

function errorResponse(e: HttpError): TransportResponse {
  return { status: e.status, headers: { "content-type": "application/json", ...e.headers }, body: { detail: e.detail } };
}

export async function mockFetch(req: TransportRequest): Promise<TransportResponse> {
  const { min, max } = config.mockDelayMs;
  await sleep(min + Math.random() * (max - min));

  const db = loadDb();
  const lang = req.headers["Accept-Language"] === "en" ? "en" : "hu";
  const match = matchRoute(req.method, req.path);
  if (!match) {
    return errorResponse(new HttpError(404, { code: "not_found", message: "Not found." }));
  }

  // CSRF: every state-changing request must carry the issued token.
  if (req.method !== "GET") {
    const token = req.headers[config.csrfHeaderName];
    if (!db.csrf_token || token !== db.csrf_token) {
      return errorResponse(new HttpError(403, { code: "csrf_invalid", message: "CSRF token missing or invalid." }));
    }
  }

  // Session from the simulated HttpOnly cookie, with inactivity timeout.
  let session = db.sessions.find((s) => s.id === db.cookie_session_id) ?? null;
  if (session) {
    const idleMs = Date.now() - new Date(session.last_seen_at).getTime();
    const owner = db.users.find((u) => u.id === session?.user_id);
    if (idleMs > DEFAULT_SETTINGS.inactivity_timeout_minutes * 60_000 || !owner || owner.status !== "active") {
      db.sessions = db.sessions.filter((s) => s.id !== session?.id);
      db.cookie_session_id = null;
      session = null;
    } else {
      session.last_seen_at = new Date().toISOString();
    }
  }
  const user = session ? (db.users.find((u) => u.id === session?.user_id) ?? null) : null;

  if (match.def.auth !== "public" && !user) {
    saveDb(db);
    return errorResponse(new HttpError(401, { code: "unauthorized", message: lang === "hu" ? "Bejelentkezés szükséges." : "Authentication required." }));
  }
  if (match.def.auth === "admin" && user?.role !== "admin") {
    db.audit_log.unshift({ id: crypto.randomUUID(), at: new Date().toISOString(), actor: user?.username ?? "?", action: "access_denied", target: `${req.method} ${req.path}` });
    saveDb(db);
    return errorResponse(new HttpError(403, { code: "forbidden", message: lang === "hu" ? "Hozzáférés megtagadva." : "Access denied." }));
  }

  const ctx: Ctx = {
    db,
    params: match.params,
    query: req.query,
    body: req.body instanceof FormData ? req.body : clone(req.body),
    lang,
    user,
    session,
  };

  try {
    const out = await match.def.handler(ctx);
    saveDb(db);
    if (out instanceof MockResult) {
      return { status: out.status, headers: { "content-type": "application/json", ...out.headers }, body: clone(out.body) };
    }
    return { status: 200, headers: { "content-type": "application/json" }, body: clone(out) };
  } catch (e) {
    saveDb(db);
    if (e instanceof HttpError) return errorResponse(e);
    console.error("[mock server] unhandled error", e);
    return errorResponse(new HttpError(500, { code: "server_error", message: "Internal server error." }));
  }
}
