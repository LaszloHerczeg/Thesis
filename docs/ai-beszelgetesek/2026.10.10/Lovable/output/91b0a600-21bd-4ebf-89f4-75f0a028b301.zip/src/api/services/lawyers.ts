import { http } from "../http";
import type { Lawyer, LawyerDirectoryQuery, LawyerInput, LawyerPublic, LawyerQuery, Page } from "../types";

export const lawyersService = {
  /** Public directory of active lawyers (no contact details). */
  directory: (query: LawyerDirectoryQuery = {}): Promise<Page<LawyerPublic>> => http.get<Page<LawyerPublic>>("/lawyers", { query: { ...query } }),

  // Admin
  list: (query: LawyerQuery = {}): Promise<Page<Lawyer>> => http.get<Page<Lawyer>>("/admin/lawyers", { query: { ...query } }),
  get: (lawyerId: string): Promise<Lawyer> => http.get<Lawyer>(`/admin/lawyers/${encodeURIComponent(lawyerId)}`),
  create: (body: LawyerInput): Promise<Lawyer> => http.post<Lawyer>("/admin/lawyers", body),
  update: (lawyerId: string, body: LawyerInput): Promise<Lawyer> => http.put<Lawyer>(`/admin/lawyers/${encodeURIComponent(lawyerId)}`, body),
};
