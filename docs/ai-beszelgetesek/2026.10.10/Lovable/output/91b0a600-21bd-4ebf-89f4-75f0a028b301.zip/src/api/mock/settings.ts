import type { AppSettings } from "../types";

/** Defaults returned by the mock GET /config. The real backend owns these values. */
export const DEFAULT_SETTINGS: AppSettings = {
  description_min_length: 30,
  description_max_length: 5000,
  questions_per_round: 5,
  max_question_rounds: 2,
  page_size_my_cases: 20,
  page_size_admin_cases: 50,
  page_size_admin_lawyers: 20,
  page_size_lawyer_directory: 12,
  password_min_length: 8,
  password_max_length: 128,
  inactivity_timeout_minutes: 30,
  max_upload_size_mb: 10,
  allowed_upload_types: ["application/pdf", "image/jpeg", "image/png"],
  file_retention_days: 30,
  account_inactivity_deletion_days: 730,
};

/** Server-side-only values of the mock (a real backend keeps these in its own config). */
export const MOCK_SERVER_RULES = {
  classification_threshold: 0.7,
  login_max_failures: 5,
  login_lockout_seconds: 120,
  weights: { location: 3, language: 2, format: 2, fee: 1 },
  site_names: ["jogutmutato", "jogútmutató"],
  leaked_passwords: [
    "password",
    "password1",
    "12345678",
    "123456789",
    "1234567890",
    "qwertyui",
    "qwertzui",
    "iloveyou",
    "letmein1",
    "admin123",
    "jelszo123",
    "jelszó123",
    "jelszavam",
    "budapest1",
    "abcd1234",
    "11111111",
  ],
} as const;
