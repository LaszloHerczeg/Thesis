import { toPublic } from "../engine";
import { paginate, route } from "../router";
import { DEFAULT_SETTINGS } from "../settings";

export function currentTaxonomy(db: import("../db").Db) {
  const v = db.taxonomy_versions[db.taxonomy_versions.length - 1];
  if (!v) throw new Error("no taxonomy version");
  return v;
}

route("GET", "/config", "public", () => DEFAULT_SETTINGS);

route("GET", "/categories", "public", (ctx) => ({
  taxonomy_version: currentTaxonomy(ctx.db),
  items: ctx.db.categories.filter((c) => c.active),
}));

route("GET", "/lawyers", "user", (ctx) => {
  const cat = ctx.query.get("category_id");
  const city = ctx.query.get("city")?.trim().toLowerCase();
  const list = ctx.db.lawyers
    .filter((l) => l.active && (!cat || l.category_ids.includes(cat)) && (!city || l.city.toLowerCase() === city))
    .sort((a, b) => a.name.localeCompare(b.name, "hu"))
    .map(toPublic);
  return paginate(list, ctx.query, DEFAULT_SETTINGS.page_size_lawyer_directory);
});
