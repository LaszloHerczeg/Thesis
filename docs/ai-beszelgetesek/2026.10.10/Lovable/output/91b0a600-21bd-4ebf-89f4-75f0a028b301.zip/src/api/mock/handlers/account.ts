import { audit } from "../db";
import { MockResult, fail, obj, requireUser, route, str, toUserDto, tr, validation } from "../router";
import { checkEmail, checkPassword, checkUsername, normaliseEmail } from "../validators";
import { toCaseDetail } from "./cases";

route("PATCH", "/account/profile", "user", (ctx) => {
  const u = requireUser(ctx);
  const b = obj(ctx.body);
  const errors: [string, string][] = [];
  let conflict = false;
  const username = typeof b["username"] === "string" ? b["username"].trim() : u.username;
  const email = typeof b["email"] === "string" ? b["email"] : u.email;
  const emailChanged = normaliseEmail(email) !== normaliseEmail(u.email);

  if (username !== u.username) {
    const err = checkUsername(ctx, username, ctx.db, u.id);
    if (err) {
      errors.push(["username", err]);
      if (/foglalt|taken/.test(err)) conflict = true;
    }
  }
  if (emailChanged) {
    const err = checkEmail(ctx, email, ctx.db, u.id);
    if (err) {
      errors.push(["email", err.msg]);
      if (err.code === "email_taken") conflict = true;
    }
    if (u.password_hash !== `mock$${str(b, "current_password")}`) {
      errors.push(["current_password", tr(ctx, "Az e-mail-cím módosításához adja meg helyesen a jelenlegi jelszavát.", "Enter your correct current password to change your email address.")]);
    }
  }
  if (errors.length) {
    if (conflict) throw fail(409, "conflict", errors[0]?.[1] ?? "", { field_errors: Object.fromEntries(errors) });
    throw validation(errors);
  }
  if (username !== u.username) audit(ctx.db, u.username, "profile_change", "username");
  if (emailChanged) audit(ctx.db, u.username, "profile_change", "email");
  u.username = username;
  u.email = normaliseEmail(email);
  return toUserDto(u);
});

route("POST", "/account/password", "user", (ctx) => {
  const u = requireUser(ctx);
  const b = obj(ctx.body);
  const errors: [string, string][] = [];
  if (u.password_hash !== `mock$${str(b, "current_password")}`) {
    errors.push(["current_password", tr(ctx, "A jelenlegi jelszó helytelen.", "Your current password is incorrect.")]);
  }
  const p = checkPassword(ctx, str(b, "new_password"), u.username, u.email);
  if (p) errors.push(["new_password", p]);
  else if (str(b, "new_password") !== str(b, "new_password_confirm")) {
    errors.push(["new_password_confirm", tr(ctx, "A két új jelszó nem egyezik.", "The two new passwords do not match.")]);
  }
  if (errors.length) throw validation(errors);
  u.password_hash = `mock$${str(b, "new_password")}`;
  // stay logged in here, log out everywhere else
  ctx.db.sessions = ctx.db.sessions.filter((s) => s.user_id !== u.id || s.id === ctx.session?.id);
  audit(ctx.db, u.username, "profile_change", "password");
  return new MockResult(204, undefined);
});

route("POST", "/account/consent", "user", (ctx) => {
  const u = requireUser(ctx);
  const given = obj(ctx.body)["given"] === true;
  u.consent_given = given;
  u.consent_given_at = given ? new Date().toISOString() : null;
  audit(ctx.db, u.username, given ? "consent_given" : "consent_withdrawn", u.id);
  return toUserDto(u);
});

route("GET", "/account/export", "user", (ctx) => {
  const u = requireUser(ctx);
  return {
    exported_at: new Date().toISOString(),
    user: toUserDto(u),
    cases: ctx.db.cases.filter((c) => c.owner_id === u.id).map((c) => toCaseDetail(ctx.db, c)),
  };
});

route("DELETE", "/account", "user", (ctx) => {
  const u = requireUser(ctx);
  if (u.password_hash !== `mock$${str(obj(ctx.body), "password")}`) {
    throw validation([["password", tr(ctx, "A jelszó helytelen.", "The password is incorrect.")]]);
  }
  ctx.db.cases = ctx.db.cases.filter((c) => c.owner_id !== u.id);
  ctx.db.sessions = ctx.db.sessions.filter((s) => s.user_id !== u.id);
  ctx.db.users = ctx.db.users.filter((x) => x.id !== u.id);
  ctx.db.cookie_session_id = null;
  audit(ctx.db, u.username, "account_deleted", u.id);
  return new MockResult(204, undefined);
});
