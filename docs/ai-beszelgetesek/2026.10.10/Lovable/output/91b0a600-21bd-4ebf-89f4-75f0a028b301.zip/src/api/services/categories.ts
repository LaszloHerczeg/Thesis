import { http } from "../http";
import type { AdminCategory, AdminCategoryList, CategoryInput, CategoryList, TaxonomyVersion } from "../types";

export const categoriesService = {
  /** Active categories of the current taxonomy. */
  list: (): Promise<CategoryList> => http.get<CategoryList>("/categories"),

  // Admin
  adminList: (): Promise<AdminCategoryList> => http.get<AdminCategoryList>("/admin/categories"),
  versions: (): Promise<TaxonomyVersion[]> => http.get<TaxonomyVersion[]>("/admin/categories/versions"),
  create: (body: CategoryInput): Promise<AdminCategory> => http.post<AdminCategory>("/admin/categories", body),
  update: (categoryId: string, body: CategoryInput): Promise<AdminCategory> =>
    http.put<AdminCategory>(`/admin/categories/${encodeURIComponent(categoryId)}`, body),
  remove: (categoryId: string): Promise<void> => http.delete<void>(`/admin/categories/${encodeURIComponent(categoryId)}`),
};
