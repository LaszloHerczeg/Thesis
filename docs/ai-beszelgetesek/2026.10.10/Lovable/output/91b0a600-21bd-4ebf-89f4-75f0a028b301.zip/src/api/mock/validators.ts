import type { Db } from "./db";
import { tr, type Ctx } from "./router";
import { DEFAULT_SETTINGS, MOCK_SERVER_RULES } from "./settings";

export const normaliseEmail = (e: string): string => e.trim().toLowerCase();

export function checkUsername(ctx: Ctx, username: string, db: Db, exceptUserId?: string): string | null {
  if (!/^[A-Za-z0-9_]{3,30}$/.test(username)) {
    return tr(ctx, "A felhasználónév 3–30 karakter lehet, csak betű, szám és aláhúzás.", "Username must be 3–30 characters: letters, numbers and underscores only.");
  }
  if (db.users.some((u) => u.id !== exceptUserId && u.username.toLowerCase() === username.toLowerCase())) {
    return tr(ctx, "Ez a felhasználónév már foglalt. Válasszon másikat.", "This username is already taken. Please choose another one.");
  }
  return null;
}

export function checkEmail(ctx: Ctx, email: string, db: Db, exceptUserId?: string): { msg: string; code: string } | null {
  const e = normaliseEmail(email);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e)) {
    return { code: "invalid_email", msg: tr(ctx, "Adjon meg érvényes e-mail-címet (pl. nev@pelda.hu).", "Enter a valid email address (e.g. name@example.com).") };
  }
  if (db.banned_emails.includes(e)) {
    return {
      code: "email_banned",
      msg: tr(
        ctx,
        "Ezzel az e-mail-címmel nem lehet regisztrálni. Ha szerintünk tévedés, kérjük, vegye fel velünk a kapcsolatot.",
        "This email address cannot be used to register. Please contact us if you think this is a mistake.",
      ),
    };
  }
  if (db.users.some((u) => u.id !== exceptUserId && normaliseEmail(u.email) === e)) {
    return { code: "email_taken", msg: tr(ctx, "Ezzel az e-mail-címmel már regisztráltak.", "This email address is already registered.") };
  }
  return null;
}

export function checkPassword(ctx: Ctx, password: string, username: string, email: string): string | null {
  const min = DEFAULT_SETTINGS.password_min_length;
  const max = DEFAULT_SETTINGS.password_max_length;
  if ([...password].length < min) return tr(ctx, `A jelszó legalább ${min} karakter legyen.`, `The password must be at least ${min} characters long.`);
  if ([...password].length > max) return tr(ctx, `A jelszó legfeljebb ${max} karakter lehet.`, `The password can be at most ${max} characters long.`);
  const lower = password.toLowerCase();
  if ((MOCK_SERVER_RULES.leaked_passwords as readonly string[]).includes(lower)) {
    return tr(ctx, "Ez a jelszó szerepel az ismert, kiszivárgott vagy gyakori jelszavak listáján. Válasszon másikat.", "This password appears in a list of known leaked or common passwords. Please choose another one.");
  }
  if (username && lower.includes(username.toLowerCase())) return tr(ctx, "A jelszó nem tartalmazhatja a felhasználónevet.", "The password must not contain your username.");
  const local = normaliseEmail(email).split("@")[0] ?? "";
  if (local.length >= 3 && (lower.includes(normaliseEmail(email)) || lower.includes(local))) {
    return tr(ctx, "A jelszó nem tartalmazhatja az e-mail-címet.", "The password must not contain your email address.");
  }
  if (MOCK_SERVER_RULES.site_names.some((s) => lower.includes(s))) return tr(ctx, "A jelszó nem tartalmazhatja az oldal nevét.", "The password must not contain the site's name.");
  return null;
}
