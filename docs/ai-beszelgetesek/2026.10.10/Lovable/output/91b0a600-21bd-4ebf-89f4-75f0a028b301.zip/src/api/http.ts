/**
 * The single fetch wrapper. Every request of the app goes through `request()`.
 *
 * - credentials: "include", JSON bodies, base URL from config
 * - CSRF token kept in memory and sent on POST/PUT/PATCH/DELETE (auto-retry once on csrf_invalid)
 * - errors normalised into ApiError (FastAPI 422 → field_errors)
 * - global handling: 401 → log-in redirect, 429 → "try again later" respecting Retry-After,
 *   5xx / network → general error notice. 403 / 404 are thrown so pages render
 *   "Access denied" / "Not found" (see components/DataState).
 *
 * The transport is either `fetch` (real backend) or the in-browser mock server,
 * selected by config.useMocks. Callers cannot tell the difference.
 */
import { config } from "@/config";
import type { CsrfResponse, UiLanguage, ValidationErrorItem } from "./types";

export type HttpMethod = "GET" | "POST" | "PUT" | "PATCH" | "DELETE";
export type QueryValue = string | number | boolean | null | undefined;
export type QueryParams = Record<string, QueryValue>;

export interface TransportRequest {
  method: HttpMethod;
  path: string;
  query: URLSearchParams;
  headers: Record<string, string>;
  /** JSON-serialisable value, FormData, or undefined */
  body: unknown;
}

export interface TransportResponse {
  status: number;
  /** Lower-case header names */
  headers: Record<string, string>;
  body: unknown;
}

type Transport = (req: TransportRequest) => Promise<TransportResponse>;

// ---------- ApiError ----------

export class ApiError extends Error {
  readonly status: number;
  readonly code: string;
  readonly field_errors: Record<string, string> | undefined;
  /** Full error detail object from the server (for extra fields like suspended_until). */
  readonly details: Record<string, unknown> | undefined;
  readonly retry_after: number | undefined;

  constructor(init: {
    status: number;
    code: string;
    message: string;
    field_errors?: Record<string, string> | undefined;
    details?: Record<string, unknown> | undefined;
    retry_after?: number | undefined;
  }) {
    super(init.message);
    this.name = "ApiError";
    this.status = init.status;
    this.code = init.code;
    this.field_errors = init.field_errors;
    this.details = init.details;
    this.retry_after = init.retry_after;
  }
}

export function isApiError(e: unknown): e is ApiError {
  return e instanceof ApiError;
}

const DEFAULT_CODES: Record<number, string> = {
  400: "bad_request",
  401: "unauthorized",
  403: "forbidden",
  404: "not_found",
  409: "conflict",
  422: "validation_error",
  429: "rate_limited",
};

function isRecord(v: unknown): v is Record<string, unknown> {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}

function isValidationItem(v: unknown): v is ValidationErrorItem {
  return isRecord(v) && Array.isArray(v["loc"]) && typeof v["msg"] === "string";
}

export function normalizeError(status: number, body: unknown, headers: Record<string, string>): ApiError {
  const retryHeader = headers["retry-after"];
  const retry_after = retryHeader !== undefined && !Number.isNaN(Number(retryHeader)) ? Number(retryHeader) : undefined;
  const fallbackCode = DEFAULT_CODES[status] ?? (status >= 500 ? "server_error" : "error");
  const detail = isRecord(body) ? body["detail"] : undefined;

  // FastAPI validation format
  if (Array.isArray(detail)) {
    const field_errors: Record<string, string> = {};
    let firstMsg = "";
    for (const item of detail) {
      if (!isValidationItem(item)) continue;
      const path = item.loc.filter((p) => p !== "body" && p !== "query" && p !== "path");
      const field = path.length > 0 ? path.map(String).join(".") : "_general";
      if (field_errors[field] === undefined) field_errors[field] = item.msg;
      if (!firstMsg) firstMsg = item.msg;
    }
    return new ApiError({ status, code: "validation_error", message: firstMsg || "Validation error", field_errors, retry_after });
  }

  if (isRecord(detail)) {
    const fe = detail["field_errors"];
    const field_errors: Record<string, string> | undefined = isRecord(fe)
      ? Object.fromEntries(Object.entries(fe).filter((e): e is [string, string] => typeof e[1] === "string"))
      : undefined;
    return new ApiError({
      status,
      code: typeof detail["code"] === "string" ? detail["code"] : fallbackCode,
      message: typeof detail["message"] === "string" ? detail["message"] : fallbackCode,
      field_errors,
      details: detail,
      retry_after,
    });
  }

  return new ApiError({
    status,
    code: fallbackCode,
    message: typeof detail === "string" ? detail : fallbackCode,
    retry_after,
  });
}

// ---------- Global notices & handlers ----------

export type NoticeKind = "rate_limited" | "server_error" | "network_error";
export interface Notice {
  id: number;
  kind: NoticeKind;
  retry_after?: number;
}
type NoticeListener = (notice: Notice) => void;

const noticeListeners = new Set<NoticeListener>();
let noticeSeq = 0;

export function subscribeNotices(listener: NoticeListener): () => void {
  noticeListeners.add(listener);
  return () => {
    noticeListeners.delete(listener);
  };
}

function emitNotice(kind: NoticeKind, retry_after?: number): void {
  noticeSeq += 1;
  const notice: Notice = retry_after === undefined ? { id: noticeSeq, kind } : { id: noticeSeq, kind, retry_after };
  noticeListeners.forEach((l) => l(notice));
}

let unauthorizedHandler: (() => void) | null = null;
/** Registered by the app shell: clears the user and redirects to log-in, remembering the page. */
export function setUnauthorizedHandler(handler: (() => void) | null): void {
  unauthorizedHandler = handler;
}

let requestLanguage: UiLanguage = "hu";
export function setRequestLanguage(lang: UiLanguage): void {
  requestLanguage = lang;
}

let rateLimitedUntil = 0;

// ---------- Transports ----------

const fetchTransport: Transport = async (req) => {
  const qs = req.query.toString();
  const url = `${config.apiBaseUrl}${req.path}${qs ? `?${qs}` : ""}`;
  const headers = new Headers(req.headers);
  let body: BodyInit | undefined;
  if (req.body instanceof FormData) {
    body = req.body;
  } else if (req.body !== undefined) {
    headers.set("Content-Type", "application/json");
    body = JSON.stringify(req.body);
  }
  const init: RequestInit = { method: req.method, credentials: "include", headers };
  if (body !== undefined) init.body = body;
  const res = await fetch(url, init);
  const outHeaders: Record<string, string> = {};
  res.headers.forEach((value, key) => {
    outHeaders[key.toLowerCase()] = value;
  });
  let parsed: unknown = undefined;
  if (res.status !== 204) {
    const type = res.headers.get("content-type") ?? "";
    parsed = type.includes("application/json") ? await res.json() : await res.text();
  }
  return { status: res.status, headers: outHeaders, body: parsed };
};

const mockTransport: Transport = async (req) => {
  const { mockFetch } = await import("./mock/server");
  return mockFetch(req);
};

const transport: Transport = config.useMocks ? mockTransport : fetchTransport;

// ---------- CSRF ----------

let csrfToken: string | null = null;
let csrfPromise: Promise<string> | null = null;

/** Fetches a fresh CSRF token (on start, after log-in, log-out, registration). Kept in memory only. */
export async function refreshCsrf(): Promise<string> {
  if (!csrfPromise) {
    csrfPromise = (async () => {
      const res = await transport({
        method: "GET",
        path: config.csrfEndpoint,
        query: new URLSearchParams(),
        headers: { Accept: "application/json", "Accept-Language": requestLanguage },
        body: undefined,
      });
      if (res.status >= 400) throw normalizeError(res.status, res.body, res.headers);
      const data = res.body as CsrfResponse;
      csrfToken = data.csrf_token;
      return data.csrf_token;
    })().finally(() => {
      csrfPromise = null;
    });
  }
  return csrfPromise;
}

// ---------- request ----------

export interface RequestOptions {
  query?: QueryParams | undefined;
  body?: unknown;
  form?: FormData | undefined;
  /** Do not redirect to log-in on 401 (e.g. GET /auth/me, POST /auth/login). */
  skipAuthRedirect?: boolean | undefined;
  /** Do not show the general 5xx notice (the page shows its own error, e.g. US-38). */
  suppressGlobalError?: boolean | undefined;
  /** Handle 429 locally without blocking all requests (e.g. per-account log-in lockout). */
  localRateLimit?: boolean | undefined;
}

function buildQuery(query: QueryParams | undefined): URLSearchParams {
  const qs = new URLSearchParams();
  if (!query) return qs;
  for (const [key, value] of Object.entries(query)) {
    if (value === undefined || value === null || value === "") continue;
    qs.set(key, String(value));
  }
  return qs;
}

async function doRequest<T>(method: HttpMethod, path: string, opts: RequestOptions, retried: boolean): Promise<T> {
  const now = Date.now();
  if (rateLimitedUntil > now) {
    const retry_after = Math.ceil((rateLimitedUntil - now) / 1000);
    emitNotice("rate_limited", retry_after);
    throw new ApiError({ status: 429, code: "rate_limited", message: "rate_limited", retry_after });
  }

  const headers: Record<string, string> = { Accept: "application/json", "Accept-Language": requestLanguage };
  if (method !== "GET") {
    const token = csrfToken ?? (await refreshCsrf());
    headers[config.csrfHeaderName] = token;
  }

  let res: TransportResponse;
  try {
    res = await transport({
      method,
      path,
      query: buildQuery(opts.query),
      headers,
      body: opts.form ?? opts.body,
    });
  } catch {
    emitNotice("network_error");
    throw new ApiError({ status: 0, code: "network_error", message: "network_error" });
  }

  if (res.status >= 200 && res.status < 300) {
    return res.body as T;
  }

  const error = normalizeError(res.status, res.body, res.headers);

  if (res.status === 403 && error.code === "csrf_invalid" && !retried) {
    await refreshCsrf();
    return doRequest<T>(method, path, opts, true);
  }
  if (res.status === 401 && !opts.skipAuthRedirect) {
    unauthorizedHandler?.();
  }
  if (res.status === 429 && !opts.localRateLimit) {
    const seconds = error.retry_after ?? 30;
    rateLimitedUntil = Date.now() + seconds * 1000;
    emitNotice("rate_limited", seconds);
  }
  if (res.status >= 500 && !opts.suppressGlobalError) {
    emitNotice("server_error");
  }
  throw error;
}

export function request<T>(method: HttpMethod, path: string, opts: RequestOptions = {}): Promise<T> {
  return doRequest<T>(method, path, opts, false);
}

export const http = {
  get: <T>(path: string, opts?: RequestOptions) => request<T>("GET", path, opts),
  post: <T>(path: string, body?: unknown, opts?: RequestOptions) => request<T>("POST", path, { ...opts, body }),
  put: <T>(path: string, body?: unknown, opts?: RequestOptions) => request<T>("PUT", path, { ...opts, body }),
  patch: <T>(path: string, body?: unknown, opts?: RequestOptions) => request<T>("PATCH", path, { ...opts, body }),
  delete: <T>(path: string, body?: unknown, opts?: RequestOptions) => request<T>("DELETE", path, { ...opts, body }),
};
