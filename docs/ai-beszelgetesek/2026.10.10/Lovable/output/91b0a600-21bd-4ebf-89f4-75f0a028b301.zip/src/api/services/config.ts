import { http } from "../http";
import type { AppSettings } from "../types";

export const configService = {
  get: (): Promise<AppSettings> => http.get<AppSettings>("/config"),
};
