import type { CaseDetail, CaseSummary, ConsultationPreference, LanguageCode, Preferences } from "../../types";
import { LANGUAGE_CODES } from "../../types";
import { audit, type Db, type DbCase } from "../db";
import { classify, extractFields, generateQuestionRound, maskPii, recommend } from "../engine";
import { MockResult, fail, notFound, obj, paginate, requireUser, route, str, tr, validation, type Ctx } from "../router";
import { DEFAULT_SETTINGS } from "../settings";
import { currentTaxonomy } from "./catalog";

export function toCaseDetail(db: Db, c: DbCase): CaseDetail {
  return {
    id: c.id,
    created_at: c.created_at,
    updated_at: c.updated_at,
    status: c.status,
    current_step: c.current_step,
    description: c.description,
    description_submitted_at: c.description_submitted_at,
    documents: c.documents,
    files_deleted_at: c.files_deleted_at,
    question_rounds: c.question_rounds,
    classification: c.classification,
    preferences: c.preferences,
    recommendations: c.recommendations.map((r) => ({
      ...r,
      lawyer_active: db.lawyers.some((l) => l.id === r.lawyer.id && l.active),
    })),
    choice: c.choice,
  };
}

export function caseTitle(description: string): string {
  const words = description.trim().split(/\s+/);
  return words.slice(0, 8).join(" ") + (words.length > 8 ? "…" : "");
}

function toSummary(c: DbCase): CaseSummary {
  return {
    id: c.id,
    created_at: c.created_at,
    updated_at: c.updated_at,
    title: caseTitle(c.description),
    status: c.status,
    current_step: c.current_step,
    category: c.classification?.category ?? null,
    chosen_lawyer_name: c.choice?.contact.name ?? null,
  };
}

/** Owner-only access; other users' cases are indistinguishable from missing ones (404). */
function ownCase(ctx: Ctx): DbCase {
  const u = requireUser(ctx);
  const id = ctx.params["id"] ?? "";
  const c = ctx.db.cases.find((x) => x.id === id);
  if (!c || c.owner_id !== u.id) {
    if (c) audit(ctx.db, u.username, "case_access_denied", id);
    throw notFound(ctx);
  }
  return c;
}

const touch = (c: DbCase) => {
  c.updated_at = new Date().toISOString();
};

function validateDescription(ctx: Ctx, d: string): void {
  const len = d.trim().length;
  const { description_min_length: min, description_max_length: max } = DEFAULT_SETTINGS;
  if (len < min) throw validation([["description", tr(ctx, `Kérjük, írjon legalább ${min} karaktert.`, `Please write at least ${min} characters.`)]]);
  if (len > max) throw validation([["description", tr(ctx, `Legfeljebb ${max} karakter írható.`, `At most ${max} characters are allowed.`)]]);
}

route("GET", "/cases", "user", (ctx) => {
  const u = requireUser(ctx);
  const status = ctx.query.get("status");
  const cat = ctx.query.get("category_id");
  const list = ctx.db.cases
    .filter((c) => c.owner_id === u.id)
    .filter((c) => !status || c.status === status)
    .filter((c) => !cat || c.classification?.category?.id === cat)
    .sort((a, b) => b.created_at.localeCompare(a.created_at))
    .map(toSummary);
  return paginate(list, ctx.query, DEFAULT_SETTINGS.page_size_my_cases);
});

route("POST", "/cases", "user", (ctx) => {
  const u = requireUser(ctx);
  if (!u.consent_given) {
    throw fail(403, "consent_required", tr(ctx, "A szolgáltatás használatához adatkezelési hozzájárulás szükséges.", "Consent to data processing is required to use the service."));
  }
  const description = str(obj(ctx.body), "description");
  validateDescription(ctx, description);
  const now = new Date().toISOString();
  const c: DbCase = {
    id: crypto.randomUUID(),
    owner_id: u.id,
    created_at: now,
    updated_at: now,
    status: "in_progress",
    current_step: "documents",
    description: description.trim(),
    masked_description: maskPii(description.trim()),
    description_submitted_at: now,
    documents: [],
    files_deleted_at: null,
    question_rounds: [],
    classification: null,
    preferences: null,
    recommendations: [],
    choice: null,
    fail_next_analysis: /\[(teszt:hiba|test:fail)\]/i.test(description),
    choice_history: [],
  };
  ctx.db.cases.push(c);
  return new MockResult(201, toCaseDetail(ctx.db, c));
});

route("GET", "/cases/:id", "user", (ctx) => toCaseDetail(ctx.db, ownCase(ctx)));

route("DELETE", "/cases/:id", "user", (ctx) => {
  const c = ownCase(ctx);
  ctx.db.cases = ctx.db.cases.filter((x) => x.id !== c.id);
  audit(ctx.db, ctx.user?.username ?? "?", "case_deleted", c.id);
  return new MockResult(204, undefined);
});

// ---- Documents ----

route("POST", "/cases/:id/documents", "user", (ctx) => {
  const c = ownCase(ctx);
  const form = ctx.body;
  const file = form instanceof FormData ? form.get("file") : null;
  if (!(file instanceof File)) throw validation([["file", tr(ctx, "Válasszon ki egy fájlt.", "Please choose a file.")]]);
  if (!DEFAULT_SETTINGS.allowed_upload_types.includes(file.type)) {
    throw validation([["file", tr(ctx, "Csak PDF, JPG vagy PNG fájl tölthető fel.", "Only PDF, JPG or PNG files can be uploaded.")]]);
  }
  if (file.size > DEFAULT_SETTINGS.max_upload_size_mb * 1024 * 1024) {
    throw validation([["file", tr(ctx, `A fájl legfeljebb ${DEFAULT_SETTINGS.max_upload_size_mb} MB lehet.`, `The file can be at most ${DEFAULT_SETTINGS.max_upload_size_mb} MB.`)]]);
  }
  const doc = {
    id: crypto.randomUUID(),
    filename: file.name,
    content_type: file.type,
    size_bytes: file.size,
    uploaded_at: new Date().toISOString(),
    confirmed: false,
    extracted_fields: extractFields(file.name, ctx.lang),
  };
  c.documents.push(doc);
  touch(c);
  return new MockResult(201, doc);
});

route("PUT", "/cases/:id/documents/:docId/confirm", "user", (ctx) => {
  const c = ownCase(ctx);
  const doc = c.documents.find((d) => d.id === ctx.params["docId"]);
  if (!doc) throw notFound(ctx);
  const fields = obj(ctx.body)["fields"];
  if (!Array.isArray(fields)) throw validation([["fields", "fields must be a list"]]);
  for (const f of fields) {
    const o = obj(f);
    const target = doc.extracted_fields.find((x) => x.key === str(o, "key"));
    if (target) target.confirmed_value = str(o, "value").trim();
  }
  doc.extracted_fields.forEach((f) => {
    if (f.confirmed_value === null) f.confirmed_value = f.value;
  });
  doc.confirmed = true;
  touch(c);
  return doc;
});

route("DELETE", "/cases/:id/documents/:docId", "user", (ctx) => {
  const c = ownCase(ctx);
  c.documents = c.documents.filter((d) => d.id !== ctx.params["docId"]);
  touch(c);
  return new MockResult(204, undefined);
});

// ---- Questions & classification ----

route("POST", "/cases/:id/questions", "user", (ctx) => {
  const c = ownCase(ctx);
  const pending = c.question_rounds.find((r) => r.submitted_at === null);
  if (!pending) {
    if (c.question_rounds.length >= DEFAULT_SETTINGS.max_question_rounds) {
      throw fail(409, "max_rounds_reached", tr(ctx, "Elérte a kérdéskörök maximális számát.", "The maximum number of question rounds was reached."));
    }
    c.question_rounds.push(generateQuestionRound(c.question_rounds.length + 1, DEFAULT_SETTINGS.questions_per_round, ctx.lang, ctx.db.categories));
  }
  c.status = "waiting_for_answers";
  c.current_step = "questions";
  touch(c);
  return toCaseDetail(ctx.db, c);
});

route("POST", "/cases/:id/questions/:round/answers", "user", (ctx) => {
  const c = ownCase(ctx);
  const round = c.question_rounds.find((r) => r.round === Number(ctx.params["round"]));
  if (!round) throw notFound(ctx);
  const answers = obj(ctx.body)["answers"];
  if (!Array.isArray(answers)) throw validation([["answers", "answers must be a list"]]);
  const now = new Date().toISOString();
  const errors: [string, string][] = [];
  for (const q of round.questions) {
    const a = answers.map(obj).find((x) => str(x, "question_id") === q.id);
    const status = a && str(a, "status") === "answered" ? "answered" : "not_answered";
    const value = a && status === "answered" ? str(a, "value").trim() : null;
    if (status === "answered" && !value) {
      errors.push([`answers.${q.id}`, tr(ctx, "Adjon választ, vagy hagyja ki a kérdést.", "Give an answer or skip the question.")]);
      continue;
    }
    if (status === "answered" && q.options.length > 0 && !q.options.some((o) => o.value === value)) {
      errors.push([`answers.${q.id}`, tr(ctx, "Érvénytelen válasz.", "Invalid answer.")]);
      continue;
    }
    q.answer = { status, value, answered_at: now };
  }
  if (errors.length) throw validation(errors);
  round.submitted_at = now;
  c.status = "in_progress";
  c.current_step = "classification";
  touch(c);
  return toCaseDetail(ctx.db, c);
});

route("POST", "/cases/:id/classify", "user", (ctx) => {
  const c = ownCase(ctx);
  if (c.fail_next_analysis) {
    c.fail_next_analysis = false;
    throw fail(503, "analysis_failed", tr(ctx, "Az elemzést most nem sikerült elvégezni.", "The analysis could not be completed right now."));
  }
  const tax = currentTaxonomy(ctx.db);
  const result = classify(
    { description: c.description, documents: c.documents.filter((d) => d.confirmed), rounds: c.question_rounds },
    ctx.db.categories,
    tax.version,
    DEFAULT_SETTINGS.max_question_rounds,
  );
  c.classification = result;
  if (result.result === "classified") {
    c.status = "in_progress";
    c.current_step = "preferences";
  } else if (result.result === "needs_more_info") {
    c.question_rounds.push(generateQuestionRound(c.question_rounds.length + 1, DEFAULT_SETTINGS.questions_per_round, ctx.lang, ctx.db.categories));
    c.status = "waiting_for_answers";
    c.current_step = "questions";
  } else {
    c.status = "unclassified";
    c.current_step = "done";
    audit(ctx.db, "system", "case_unclassified", c.id);
  }
  touch(c);
  return toCaseDetail(ctx.db, c);
});

// ---- Preferences & recommendations ----

route("PUT", "/cases/:id/preferences", "user", (ctx) => {
  const c = ownCase(ctx);
  if (c.classification?.result !== "classified") throw fail(409, "not_classified", tr(ctx, "Az ügy még nincs besorolva.", "The case is not classified yet."));
  const b = obj(ctx.body);
  const errors: [string, string][] = [];
  const languages = Array.isArray(b["languages"]) ? b["languages"].filter((x): x is LanguageCode => typeof x === "string" && (LANGUAGE_CODES as readonly string[]).includes(x)) : [];
  if (languages.length === 0) errors.push(["languages", tr(ctx, "Válasszon legalább egy nyelvet.", "Choose at least one language.")]);
  const format = str(b, "consultation_format");
  if (!["online", "in_person", "either"].includes(format)) errors.push(["consultation_format", tr(ctx, "Válasszon konzultációs formát.", "Choose a consultation format.")]);
  const maxPrice = b["max_price"];
  if (maxPrice !== null && (typeof maxPrice !== "number" || !Number.isFinite(maxPrice) || maxPrice <= 0)) {
    errors.push(["max_price", tr(ctx, "Az ár pozitív szám legyen, vagy hagyja üresen.", "The price must be a positive number, or leave it empty.")]);
  }
  if (errors.length) throw validation(errors);
  const prefs: Preferences = {
    city: str(b, "city").trim(),
    languages,
    consultation_format: format as ConsultationPreference,
    max_price: typeof maxPrice === "number" ? Math.round(maxPrice) : null,
  };
  c.preferences = prefs;
  c.current_step = "recommendations";
  touch(c);
  return toCaseDetail(ctx.db, c);
});

route("POST", "/cases/:id/recommendations", "user", (ctx) => {
  const c = ownCase(ctx);
  const category = c.classification?.category;
  if (!category || !c.preferences) throw fail(409, "preferences_missing", tr(ctx, "Előbb adja meg a preferenciáit.", "Please set your preferences first."));
  c.recommendations = recommend(ctx.db.lawyers, category, c.preferences, ctx.lang);
  c.choice = null;
  c.status = "recommendations_ready";
  c.current_step = "recommendations";
  touch(c);
  return toCaseDetail(ctx.db, c);
});

route("POST", "/cases/:id/choice", "user", (ctx) => {
  const c = ownCase(ctx);
  const rec = c.recommendations.find((r) => r.id === str(obj(ctx.body), "recommendation_id"));
  if (!rec) throw validation([["recommendation_id", tr(ctx, "Ismeretlen ajánlás.", "Unknown recommendation.")]]);
  const l = ctx.db.lawyers.find((x) => x.id === rec.lawyer.id);
  if (!l || !l.active) {
    throw fail(409, "lawyer_inactive", tr(ctx, "Ez az ügyvéd már nem fogad ügyfeleket a platformon keresztül.", "This lawyer no longer accepts clients through the platform."));
  }
  const now = new Date().toISOString();
  c.choice = {
    recommendation_id: rec.id,
    lawyer_id: l.id,
    rank: rec.rank,
    chosen_at: now,
    contact: {
      lawyer_id: l.id,
      name: l.name,
      phone: l.phone,
      email: l.email,
      office_address: l.office_address,
      city: l.city,
      website: l.website,
      booking_url: l.booking_url,
      consultation_formats: l.consultation_formats,
      price_per_hour: l.price_per_hour,
    },
  };
  c.choice_history.push({ recommendation_id: rec.id, lawyer_id: l.id, rank: rec.rank, chosen_at: now });
  c.status = "lawyer_chosen";
  c.current_step = "done";
  touch(c);
  return toCaseDetail(ctx.db, c);
});
