/**
 * Mock "backend logic": rule-based classification (US-09), follow-up question
 * generation (US-02), document field extraction, PII masking (US-41) and
 * deterministic lawyer ranking (US-06/07). A real backend replaces all of this.
 */
import type {
  CaseDocument,
  Category,
  CategoryRef,
  Classification,
  CriterionMatch,
  ExtractedField,
  FollowUpQuestion,
  Lawyer,
  LawyerPublic,
  Preferences,
  QuestionRound,
  Recommendation,
  UiLanguage,
} from "../types";
import { MOCK_SERVER_RULES } from "./settings";

const KEYWORDS: Record<string, string[]> = {
  berlet: ["bérl", "albérlet", "főbérlő", "kaució", "lakbér", "bérbeadó", "rezsi", "landlord", "rent", "tenant", "deposit", "lease"],
  munka: ["munkahely", "munkáltató", "felmond", "fizetés", "munkabér", "túlóra", "elbocsát", "főnök", "employer", "fired", "salary", "overtime", "job"],
  csalad: ["válás", "váli", "gyerek", "gyermek", "tartásdíj", "házasság", "láthatás", "férj", "feleség", "divorce", "child", "custody", "alimony"],
  fogyaszto: ["vásárol", "vettem", "termék", "garancia", "jótállás", "webshop", "visszaküld", "reklamáció", "refund", "warranty", "purchase", "product"],
  orokles: ["örökség", "örökl", "hagyaték", "végrendelet", "elhunyt", "örökös", "inheritance", "will", "estate", "deceased"],
  ingatlan: ["ingatlan", "telek", "adásvétel", "szomszéd", "építés", "telekkönyv", "földhivatal", "lakásvásárl", "property", "neighbour", "real estate"],
  karterites: ["baleset", "kár", "sérül", "biztosító", "kártérítés", "ütközés", "accident", "injury", "damage", "insurance"],
  adossag: ["tartozás", "adósság", "végrehaj", "hitel", "behajt", "inkasszó", "törleszt", "debt", "loan", "bailiff", "collection"],
};

export function toRef(c: Category): CategoryRef {
  return { id: c.id, code: c.code, name: c.name, plain_name: c.plain_name };
}

// ---------- PII masking ----------

export function maskPii(text: string): string {
  let n = 0;
  const names = new Map<string, string>();
  return text
    .replace(/[\w.+-]+@[\w-]+\.[\w.-]+/g, "[EMAIL]")
    .replace(/(\+36|06)[\s-]?\d{1,2}[\s-]?\d{3}[\s-]?\d{3,4}/g, "[PHONE]")
    .replace(/\b\d{8,}\b|\b\d{4}[\s-]\d{4}[\s-]\d{4,8}\b/g, "[ID_NUMBER]")
    .replace(/\b(?:Dr\.\s)?[A-ZÁÉÍÓÖŐÚÜŰ][a-záéíóöőúüű]+\s[A-ZÁÉÍÓÖŐÚÜŰ][a-záéíóöőúüű]+\b/g, (match) => {
      const existing = names.get(match);
      if (existing) return existing;
      n += 1;
      const tag = `[NAME_${n}]`;
      names.set(match, tag);
      return tag;
    });
}

// ---------- Questions ----------

interface QuestionTemplate {
  key: string;
  type: FollowUpQuestion["type"];
  text: Record<UiLanguage, string>;
  options?: Record<UiLanguage, { value: string; label: string }[]>;
}

const ROUND_TEMPLATES: QuestionTemplate[][] = [
  [
    { key: "area", type: "multiple_choice", text: { hu: "Melyik témához áll a legközelebb a problémája?", en: "Which topic is your problem closest to?" } },
    { key: "start_date", type: "date", text: { hu: "Mikor kezdődött a probléma?", en: "When did the problem start?" } },
    { key: "other_party", type: "short_text", text: { hu: "Ki a másik fél? (pl. bérbeadó, munkáltató, cég)", en: "Who is the other party? (e.g. landlord, employer, company)" } },
    { key: "money", type: "yes_no", text: { hu: "Érint a probléma pénzt vagy tartozást?", en: "Does the problem involve money or a debt?" } },
    { key: "location", type: "short_text", text: { hu: "Melyik városban vagy megyében történt?", en: "In which city or county did it happen?" } },
  ],
  [
    { key: "amount", type: "short_text", text: { hu: "Körülbelül mekkora összegről van szó?", en: "Roughly what amount of money is involved?" } },
    { key: "written", type: "yes_no", text: { hu: "Van írásos szerződés vagy más dokumentum az ügyben?", en: "Is there a written contract or other document?" } },
    { key: "contacted", type: "yes_no", text: { hu: "Felvette már a kapcsolatot a másik féllel?", en: "Have you already contacted the other party?" } },
    { key: "deadline", type: "date", text: { hu: "Van közelgő határidő (pl. kiköltözés, tárgyalás)?", en: "Is there an upcoming deadline (e.g. moving out, a hearing)?" } },
    {
      key: "goal",
      type: "multiple_choice",
      text: { hu: "Mit szeretne elérni?", en: "What would you like to achieve?" },
      options: {
        hu: [
          { value: "money_back", label: "Pénz visszaszerzése" },
          { value: "agreement", label: "Megegyezés a másik féllel" },
          { value: "advice", label: "Tanácsot a jogaimról" },
          { value: "court", label: "Bírósági eljárás indítása" },
        ],
        en: [
          { value: "money_back", label: "Get money back" },
          { value: "agreement", label: "Reach an agreement" },
          { value: "advice", label: "Advice about my rights" },
          { value: "court", label: "Start court proceedings" },
        ],
      },
    },
  ],
];

export function generateQuestionRound(round: number, perRound: number, lang: UiLanguage, categories: Category[]): QuestionRound {
  const templates = ROUND_TEMPLATES[Math.min(round - 1, ROUND_TEMPLATES.length - 1)] ?? [];
  const questions: FollowUpQuestion[] = templates.slice(0, perRound).map((t) => {
    let options: { value: string; label: string }[] = [];
    if (t.key === "area") {
      options = [
        ...categories.filter((c) => c.active).map((c) => ({ value: `category:${c.code}`, label: c.plain_name })),
        { value: "unknown", label: lang === "hu" ? "Egyik sem / nem tudom" : "None of these / I don't know" },
      ];
    } else if (t.options) {
      options = t.options[lang];
    } else if (t.type === "yes_no") {
      options = lang === "hu"
        ? [{ value: "yes", label: "Igen" }, { value: "no", label: "Nem" }]
        : [{ value: "yes", label: "Yes" }, { value: "no", label: "No" }];
    }
    return { id: crypto.randomUUID(), round, type: t.type, text: t.text[lang], options, answer: null };
  });
  return { round, questions, submitted_at: null };
}

// ---------- Document extraction ----------

export function extractFields(filename: string, lang: UiLanguage): ExtractedField[] {
  const f = filename.toLowerCase();
  const docType = f.includes("berlet") || f.includes("lease")
    ? lang === "hu" ? "Bérleti szerződés" : "Tenancy agreement"
    : f.includes("munka") || f.includes("employ")
      ? lang === "hu" ? "Munkaszerződés" : "Employment contract"
      : f.includes("szamla") || f.includes("invoice")
        ? lang === "hu" ? "Számla" : "Invoice"
        : lang === "hu" ? "Egyéb dokumentum" : "Other document";
  const date = new Date(Date.now() - 1000 * 60 * 60 * 24 * 120).toISOString().slice(0, 10);
  return [
    { key: "document_type", value: docType, confirmed_value: null },
    { key: "document_date", value: date, confirmed_value: null },
    { key: "other_party", value: "Minta Ingatlan Kft.", confirmed_value: null },
    { key: "amount", value: "250 000 Ft", confirmed_value: null },
    { key: "location", value: "Budapest", confirmed_value: null },
  ];
}

// ---------- Classification ----------

export interface ClassificationInput {
  description: string;
  documents: CaseDocument[];
  rounds: QuestionRound[];
}

export function classify(
  input: ClassificationInput,
  categories: Category[],
  taxonomyVersion: number,
  maxRounds: number,
): Classification {
  const active = categories.filter((c) => c.active);
  const texts: string[] = [input.description];
  let answered = 0;
  const bonus: Record<string, number> = {};
  for (const d of input.documents) {
    for (const f of d.extracted_fields) texts.push(f.confirmed_value ?? f.value);
  }
  for (const r of input.rounds) {
    for (const q of r.questions) {
      if (q.answer?.status === "answered" && q.answer.value) {
        answered += 1;
        if (q.answer.value.startsWith("category:")) {
          const code = q.answer.value.slice("category:".length);
          bonus[code] = (bonus[code] ?? 0) + 2;
        } else {
          texts.push(q.answer.value);
        }
      }
    }
  }
  const haystack = texts.join(" ").toLowerCase();
  let best: Category | null = null;
  let bestHits = 0;
  for (const c of active) {
    const words = KEYWORDS[c.code] ?? c.example_problems.flatMap((e) => e.toLowerCase().split(/\s+/).filter((w) => w.length > 5));
    let hits = bonus[c.code] ?? 0;
    for (const w of words) if (haystack.includes(w)) hits += 1;
    if (hits > bestHits) {
      best = c;
      bestHits = hits;
    }
  }
  const roundsDone = input.rounds.filter((r) => r.submitted_at !== null).length;
  const now = new Date().toISOString();
  const base = { method: "rule_based" as const, taxonomy_version: taxonomyVersion, classified_at: now };
  if (!best) {
    return roundsDone < maxRounds
      ? { ...base, result: "needs_more_info", category: null, confidence: null }
      : { ...base, result: "not_supported", category: null, confidence: 0.2 };
  }
  const confidence = Math.min(0.96, Math.round((0.45 + 0.13 * bestHits + 0.03 * answered) * 100) / 100);
  if (confidence >= MOCK_SERVER_RULES.classification_threshold) {
    return { ...base, result: "classified", category: toRef(best), confidence };
  }
  return roundsDone < maxRounds
    ? { ...base, result: "needs_more_info", category: null, confidence }
    : { ...base, result: "not_supported", category: null, confidence };
}

// ---------- Recommendation ----------

export function toPublic(l: Lawyer): LawyerPublic {
  return {
    id: l.id,
    name: l.name,
    city: l.city,
    category_ids: [...l.category_ids],
    languages: [...l.languages],
    consultation_formats: [...l.consultation_formats],
    price_per_hour: l.price_per_hour,
  };
}

function summarise(l: Lawyer, category: CategoryRef, criteria: CriterionMatch[], lang: UiLanguage): string {
  const met = criteria.filter((c) => c.matched).length;
  return lang === "hu"
    ? `${l.name} szakterülete a(z) ${category.name.toLowerCase()}, és az Ön ${criteria.length} szempontjából ${met}-nak/nek megfelel.`
    : `${l.name} specialises in ${category.plain_name.toLowerCase()} and meets ${met} of your ${criteria.length} criteria.`;
}

export function recommend(
  lawyers: Lawyer[],
  category: CategoryRef,
  prefs: Preferences,
  lang: UiLanguage,
): Recommendation[] {
  const w = MOCK_SERVER_RULES.weights;
  const city = prefs.city.trim().toLowerCase();
  const scored = lawyers
    .filter((l) => l.active && l.category_ids.includes(category.id))
    .map((l) => {
      const criteria: CriterionMatch[] = [
        { criterion: "specialty", matched: true },
        { criterion: "location", matched: city !== "" && l.city.toLowerCase() === city },
        { criterion: "language", matched: prefs.languages.length === 0 || prefs.languages.some((x) => l.languages.includes(x)) },
        {
          criterion: "format",
          matched: prefs.consultation_format === "either" || l.consultation_formats.includes(prefs.consultation_format),
        },
        { criterion: "fee", matched: prefs.max_price === null || l.price_per_hour <= prefs.max_price },
      ];
      const m = (k: CriterionMatch["criterion"]) => (criteria.find((c) => c.criterion === k)?.matched ? 1 : 0);
      const score = m("location") * w.location + m("language") * w.language + m("format") * w.format + m("fee") * w.fee;
      return { l, criteria, score };
    })
    // deterministic: score desc, then price asc, then name, then id
    .sort((a, b) => b.score - a.score || a.l.price_per_hour - b.l.price_per_hour || a.l.name.localeCompare(b.l.name, "hu") || a.l.id.localeCompare(b.l.id));
  const now = new Date().toISOString();
  return scored.slice(0, 3).map((s, i) => ({
    id: crypto.randomUUID(),
    rank: i + 1,
    score: s.score,
    lawyer: toPublic(s.l),
    criteria: s.criteria,
    summary: summarise(s.l, category, s.criteria, lang),
    lawyer_active: true,
    created_at: now,
  }));
}
