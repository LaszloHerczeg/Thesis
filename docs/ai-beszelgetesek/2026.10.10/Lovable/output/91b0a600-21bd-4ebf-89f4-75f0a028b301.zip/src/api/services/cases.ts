import { http } from "../http";
import type {
  AnswersRequest,
  CaseDetail,
  CaseDocument,
  CaseSummary,
  CreateCaseRequest,
  DocumentConfirmRequest,
  MyCasesQuery,
  Page,
  Preferences,
} from "../types";

const base = (caseId: string) => `/cases/${encodeURIComponent(caseId)}`;
/** Analysis steps show their own US-38 error, so no global 5xx notice. */
const analysis = { suppressGlobalError: true };

export const casesService = {
  list: (query: MyCasesQuery = {}): Promise<Page<CaseSummary>> => http.get<Page<CaseSummary>>("/cases", { query: { ...query } }),
  get: (caseId: string): Promise<CaseDetail> => http.get<CaseDetail>(base(caseId)),
  remove: (caseId: string): Promise<void> => http.delete<void>(base(caseId)),

  // Screening
  create: (body: CreateCaseRequest): Promise<CaseDetail> => http.post<CaseDetail>("/cases", body),

  // Documents
  uploadDocument(caseId: string, file: File): Promise<CaseDocument> {
    const form = new FormData();
    form.append("file", file);
    return http.post<CaseDocument>(`${base(caseId)}/documents`, undefined, { form, ...analysis });
  },
  confirmDocument: (caseId: string, documentId: string, body: DocumentConfirmRequest): Promise<CaseDocument> =>
    http.put<CaseDocument>(`${base(caseId)}/documents/${encodeURIComponent(documentId)}/confirm`, body),
  deleteDocument: (caseId: string, documentId: string): Promise<void> =>
    http.delete<void>(`${base(caseId)}/documents/${encodeURIComponent(documentId)}`),

  // Follow-up questions
  requestQuestions: (caseId: string): Promise<CaseDetail> => http.post<CaseDetail>(`${base(caseId)}/questions`, undefined, analysis),
  submitAnswers: (caseId: string, round: number, body: AnswersRequest): Promise<CaseDetail> =>
    http.post<CaseDetail>(`${base(caseId)}/questions/${round}/answers`, body),

  // Classification
  classify: (caseId: string): Promise<CaseDetail> => http.post<CaseDetail>(`${base(caseId)}/classify`, undefined, analysis),

  // Preferences & recommendations
  savePreferences: (caseId: string, body: Preferences): Promise<CaseDetail> => http.put<CaseDetail>(`${base(caseId)}/preferences`, body),
  recommend: (caseId: string): Promise<CaseDetail> => http.post<CaseDetail>(`${base(caseId)}/recommendations`, undefined, analysis),

  // Lawyer choice
  chooseLawyer: (caseId: string, recommendationId: string): Promise<CaseDetail> =>
    http.post<CaseDetail>(`${base(caseId)}/choice`, { recommendation_id: recommendationId }),
};
