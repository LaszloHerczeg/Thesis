import type {
  AdminCaseDetail,
  AdminCaseRow,
  Category,
  ConsultationFormat,
  LanguageCode,
  Lawyer,
} from "../../types";
import { CONSULTATION_FORMATS, LANGUAGE_CODES } from "../../types";
import { audit, type Db, type DbCase } from "../db";
import { maskPii } from "../engine";
import { MockResult, fail, notFound, obj, paginate, requireUser, route, str, tr, validation, type Ctx } from "../router";
import { DEFAULT_SETTINGS } from "../settings";
import { currentTaxonomy } from "./catalog";

// ---------- Dashboard ----------

route("GET", "/admin/dashboard", "admin", (ctx) => {
  const db = ctx.db;
  const weekAgo = Date.now() - 7 * 24 * 3600_000;
  return {
    active_lawyers: db.lawyers.filter((l) => l.active).length,
    inactive_lawyers: db.lawyers.filter((l) => !l.active).length,
    active_categories: db.categories.filter((c) => c.active).length,
    taxonomy_version: currentTaxonomy(db).version,
    total_cases: db.cases.length,
    unclassified_cases: db.cases.filter((c) => c.status === "unclassified").length,
    cases_last_7_days: db.cases.filter((c) => new Date(c.created_at).getTime() >= weekAgo).length,
    latest_accuracy: db.evaluations[0]?.overall_accuracy ?? null,
  };
});

// ---------- Lawyers ----------

function parseLawyer(ctx: Ctx, body: unknown) {
  const b = obj(body);
  const e: [string, string][] = [];
  const req = (f: string) => e.push([f, tr(ctx, "Kötelező mező.", "This field is required.")]);
  const name = str(b, "name").trim();
  const phone = str(b, "phone").trim();
  const email = str(b, "email").trim().toLowerCase();
  const website = str(b, "website").trim();
  const booking = str(b, "booking_url").trim();
  const address = str(b, "office_address").trim();
  const city = str(b, "city").trim();
  const cats = Array.isArray(b["category_ids"]) ? b["category_ids"].filter((x): x is string => typeof x === "string") : [];
  const langs = Array.isArray(b["languages"]) ? b["languages"].filter((x): x is string => typeof x === "string") : [];
  const formats = Array.isArray(b["consultation_formats"]) ? b["consultation_formats"].filter((x): x is string => typeof x === "string") : [];
  const price = b["price_per_hour"];

  if (!name) req("name");
  else if (name.length < 3 || name.length > 100) e.push(["name", tr(ctx, "A név 3–100 karakter legyen.", "Name must be 3–100 characters.")]);
  if (!phone) req("phone");
  else if (!/^\+?[0-9 ()/-]{7,20}$/.test(phone)) e.push(["phone", tr(ctx, "Érvénytelen telefonszám (pl. +36 1 234 5678).", "Invalid phone number (e.g. +36 1 234 5678).")]);
  if (!email) req("email");
  else if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) e.push(["email", tr(ctx, "Érvénytelen e-mail-cím.", "Invalid email address.")]);
  const urlOk = (u: string) => /^https?:\/\/[^\s.]+\.[^\s]+$/.test(u);
  if (website && !urlOk(website)) e.push(["website", tr(ctx, "A webcím http:// vagy https:// kezdetű legyen.", "The URL must start with http:// or https://.")]);
  if (booking && !urlOk(booking)) e.push(["booking_url", tr(ctx, "A foglalási link http:// vagy https:// kezdetű legyen.", "The booking link must start with http:// or https://.")]);
  if (!address) req("office_address");
  if (!city) req("city");
  if (cats.length === 0) e.push(["category_ids", tr(ctx, "Válasszon legalább egy szakterületet.", "Choose at least one area of expertise.")]);
  else if (!cats.every((id) => ctx.db.categories.some((c) => c.id === id && c.active))) e.push(["category_ids", tr(ctx, "Ismeretlen vagy inaktív kategória.", "Unknown or inactive category.")]);
  if (langs.length === 0) e.push(["languages", tr(ctx, "Válasszon legalább egy nyelvet.", "Choose at least one language.")]);
  else if (!langs.every((l) => (LANGUAGE_CODES as readonly string[]).includes(l))) e.push(["languages", tr(ctx, "Ismeretlen nyelv.", "Unknown language.")]);
  if (formats.length === 0) e.push(["consultation_formats", tr(ctx, "Válasszon legalább egy konzultációs formát.", "Choose at least one consultation format.")]);
  else if (!formats.every((f) => (CONSULTATION_FORMATS as readonly string[]).includes(f))) e.push(["consultation_formats", "Unknown format."]);
  if (typeof price !== "number" || !Number.isInteger(price) || price <= 0 || price > 1_000_000) {
    e.push(["price_per_hour", tr(ctx, "Az óradíj 1 és 1 000 000 Ft közötti egész szám legyen.", "The hourly fee must be a whole number between 1 and 1,000,000 HUF.")]);
  }
  if (e.length) throw validation(e);
  return {
    name,
    phone,
    email,
    website: website || null,
    booking_url: booking || null,
    office_address: address,
    city,
    category_ids: cats,
    languages: langs as LanguageCode[],
    consultation_formats: formats as ConsultationFormat[],
    price_per_hour: price as number,
    active: b["active"] !== false,
  };
}

route("GET", "/admin/lawyers", "admin", (ctx) => {
  const q = ctx.query;
  const text = q.get("q")?.trim().toLowerCase();
  const list = ctx.db.lawyers
    .filter((l) => !text || [l.name, l.email, l.phone, l.office_address].some((v) => v.toLowerCase().includes(text)))
    .filter((l) => !q.get("category_id") || l.category_ids.includes(q.get("category_id") ?? ""))
    .filter((l) => !q.get("city") || l.city.toLowerCase() === (q.get("city") ?? "").toLowerCase())
    .filter((l) => !q.get("language") || l.languages.includes((q.get("language") ?? "") as LanguageCode))
    .filter((l) => !q.get("format") || l.consultation_formats.includes((q.get("format") ?? "") as ConsultationFormat))
    .filter((l) => !q.get("active") || String(l.active) === q.get("active"))
    .sort((a, b) => a.name.localeCompare(b.name, "hu"));
  return paginate(list, q, DEFAULT_SETTINGS.page_size_admin_lawyers);
});

route("GET", "/admin/lawyers/:id", "admin", (ctx) => {
  const l = ctx.db.lawyers.find((x) => x.id === ctx.params["id"]);
  if (!l) throw notFound(ctx);
  return l;
});

route("POST", "/admin/lawyers", "admin", (ctx) => {
  const data = parseLawyer(ctx, ctx.body);
  const now = new Date().toISOString();
  const l: Lawyer = { ...data, id: crypto.randomUUID(), created_at: now, updated_at: now };
  ctx.db.lawyers.push(l);
  audit(ctx.db, requireUser(ctx).username, "lawyer_created", `${l.id} after=${JSON.stringify(data)}`);
  return new MockResult(201, l);
});

route("PUT", "/admin/lawyers/:id", "admin", (ctx) => {
  const l = ctx.db.lawyers.find((x) => x.id === ctx.params["id"]);
  if (!l) throw notFound(ctx);
  const data = parseLawyer(ctx, ctx.body);
  const before = JSON.stringify(l);
  Object.assign(l, data, { updated_at: new Date().toISOString() });
  audit(ctx.db, requireUser(ctx).username, "lawyer_updated", `${l.id} before=${before} after=${JSON.stringify(l)}`);
  return l;
});

// ---------- Categories ----------

function bumpTaxonomy(db: Db, by: string, summary: string): void {
  const v = currentTaxonomy(db).version + 1;
  db.taxonomy_versions.push({ id: crypto.randomUUID(), version: v, created_at: new Date().toISOString(), created_by: by, change_summary: summary });
}

function parseCategory(ctx: Ctx, body: unknown, exceptId?: string) {
  const b = obj(body);
  const e: [string, string][] = [];
  const code = str(b, "code").trim();
  const name = str(b, "name").trim();
  const plain = str(b, "plain_name").trim();
  const description = str(b, "description").trim();
  const examples = Array.isArray(b["example_problems"]) ? b["example_problems"].filter((x): x is string => typeof x === "string").map((x) => x.trim()).filter(Boolean) : [];
  if (!/^[a-z0-9_]{2,40}$/.test(code)) e.push(["code", tr(ctx, "Az azonosító 2–40 karakter: kisbetű, szám, aláhúzás.", "The identifier must be 2–40 characters: lower-case letters, numbers, underscores.")]);
  else if (ctx.db.categories.some((c) => c.code === code && c.id !== exceptId)) e.push(["code", tr(ctx, "Ez az azonosító már létezik.", "This identifier already exists.")]);
  if (name.length < 3) e.push(["name", tr(ctx, "Adja meg a jogi megnevezést (legalább 3 karakter).", "Enter the legal name (at least 3 characters).")]);
  if (plain.length < 3) e.push(["plain_name", tr(ctx, "Adja meg a közérthető nevet (legalább 3 karakter).", "Enter the plain-language name (at least 3 characters).")]);
  if (description.length < 10) e.push(["description", tr(ctx, "A leírás legalább 10 karakter legyen.", "The description must be at least 10 characters.")]);
  if (examples.length === 0) e.push(["example_problems", tr(ctx, "Adjon meg legalább egy példaproblémát.", "Add at least one example problem.")]);
  if (e.length) throw validation(e);
  return { code, name, plain_name: plain, description, example_problems: examples, active: b["active"] !== false };
}

function adminCategoryList(db: Db) {
  return {
    taxonomy_version: currentTaxonomy(db),
    items: db.categories.map((c) => ({
      ...c,
      active_lawyer_count: db.lawyers.filter((l) => l.active && l.category_ids.includes(c.id)).length,
    })),
  };
}

route("GET", "/admin/categories", "admin", (ctx) => adminCategoryList(ctx.db));
route("GET", "/admin/categories/versions", "admin", (ctx) => [...ctx.db.taxonomy_versions].reverse());

route("POST", "/admin/categories", "admin", (ctx) => {
  const data = parseCategory(ctx, ctx.body);
  const now = new Date().toISOString();
  const c: Category = { ...data, id: crypto.randomUUID(), created_at: now, updated_at: now };
  ctx.db.categories.push(c);
  const by = requireUser(ctx).username;
  bumpTaxonomy(ctx.db, by, `Új kategória: ${c.name}`);
  audit(ctx.db, by, "category_created", c.id);
  return new MockResult(201, { ...c, active_lawyer_count: 0 });
});

route("PUT", "/admin/categories/:id", "admin", (ctx) => {
  const c = ctx.db.categories.find((x) => x.id === ctx.params["id"]);
  if (!c) throw notFound(ctx);
  const data = parseCategory(ctx, ctx.body, c.id);
  const users = ctx.db.lawyers.filter((l) => l.active && l.category_ids.includes(c.id));
  if (c.active && !data.active && users.length > 0) {
    throw fail(409, "category_in_use", tr(ctx, "A kategória aktív ügyvédekhez van rendelve.", "The category is assigned to active lawyers."), {
      lawyers: users.map((l) => ({ id: l.id, name: l.name })),
    });
  }
  const before = JSON.stringify(c);
  Object.assign(c, data, { updated_at: new Date().toISOString() });
  const by = requireUser(ctx).username;
  bumpTaxonomy(ctx.db, by, `Kategória módosítva: ${c.name}`);
  audit(ctx.db, by, "category_updated", `${c.id} before=${before}`);
  return { ...c, active_lawyer_count: users.length };
});

route("DELETE", "/admin/categories/:id", "admin", (ctx) => {
  const c = ctx.db.categories.find((x) => x.id === ctx.params["id"]);
  if (!c) throw notFound(ctx);
  const users = ctx.db.lawyers.filter((l) => l.active && l.category_ids.includes(c.id));
  if (users.length > 0) {
    throw fail(409, "category_in_use", tr(ctx, "A kategória nem törölhető, amíg aktív ügyvédekhez van rendelve.", "The category cannot be removed while it is assigned to active lawyers."), {
      lawyers: users.map((l) => ({ id: l.id, name: l.name })),
    });
  }
  ctx.db.categories = ctx.db.categories.filter((x) => x.id !== c.id);
  ctx.db.lawyers.forEach((l) => {
    l.category_ids = l.category_ids.filter((id) => id !== c.id);
  });
  const by = requireUser(ctx).username;
  bumpTaxonomy(ctx.db, by, `Kategória törölve: ${c.name}`);
  audit(ctx.db, by, "category_deleted", c.id);
  return new MockResult(204, undefined);
});

// ---------- Cases ----------

function username(db: Db, c: DbCase): string {
  return db.users.find((u) => u.id === c.owner_id)?.username ?? "—";
}

function toRow(db: Db, c: DbCase): AdminCaseRow {
  return {
    id: c.id,
    created_at: c.created_at,
    updated_at: c.updated_at,
    username: username(db, c),
    category: c.classification?.category ?? null,
    status: c.status,
    confidence: c.classification?.confidence ?? null,
    chosen_lawyer_name: c.choice?.contact.name ?? null,
    has_documents: c.documents.length > 0,
  };
}

route("GET", "/admin/cases", "admin", (ctx) => {
  const q = ctx.query;
  const db = ctx.db;
  const text = q.get("q")?.trim().toLowerCase();
  const dateFrom = q.get("date_from");
  const dateTo = q.get("date_to");
  const confMax = q.get("confidence_max");
  const hasDocs = q.get("has_documents");
  let rows = db.cases
    .filter((c) => {
      if (!text) return true;
      const u = db.users.find((x) => x.id === c.owner_id);
      return !!u && (u.username.toLowerCase().includes(text) || u.email.toLowerCase().includes(text));
    })
    .filter((c) => !q.get("category_id") || c.classification?.category?.id === q.get("category_id"))
    .filter((c) => !q.get("status") || c.status === q.get("status"))
    .filter((c) => !dateFrom || c.created_at.slice(0, 10) >= dateFrom)
    .filter((c) => !dateTo || c.created_at.slice(0, 10) <= dateTo)
    .filter((c) => !confMax || (c.classification?.confidence !== null && c.classification?.confidence !== undefined && c.classification.confidence <= Number(confMax)))
    .filter((c) => !q.get("lawyer_id") || c.choice?.lawyer_id === q.get("lawyer_id"))
    .filter((c) => !hasDocs || String(c.documents.length > 0) === hasDocs)
    .map((c) => toRow(db, c));

  const sort = q.get("sort") ?? "created_at";
  const dir = q.get("order") === "asc" ? 1 : -1;
  const key = (r: AdminCaseRow): string => {
    switch (sort) {
      case "case_number": return r.id;
      case "username": return r.username.toLowerCase();
      case "category": return r.category?.name ?? "";
      case "status": return r.status;
      case "chosen_lawyer": return r.chosen_lawyer_name ?? "";
      case "updated_at": return r.updated_at;
      default: return r.created_at;
    }
  };
  rows = rows.sort((a, b) => key(a).localeCompare(key(b), "hu") * dir || a.id.localeCompare(b.id));
  return paginate(rows, q, DEFAULT_SETTINGS.page_size_admin_cases);
});

route("GET", "/admin/cases/:id", "admin", (ctx) => {
  const db = ctx.db;
  const c = db.cases.find((x) => x.id === ctx.params["id"]);
  if (!c) throw notFound(ctx);
  audit(db, requireUser(ctx).username, "admin_case_opened", c.id);
  const detail: AdminCaseDetail = {
    id: c.id,
    created_at: c.created_at,
    updated_at: c.updated_at,
    username: username(db, c),
    status: c.status,
    current_step: c.current_step,
    masked_description: c.masked_description,
    documents: c.documents.map((d) => ({
      id: d.id,
      content_type: d.content_type,
      size_bytes: d.size_bytes,
      uploaded_at: d.uploaded_at,
      extracted_fields: d.extracted_fields.map((f) => ({ key: f.key, value: maskPii(f.value), confirmed_value: f.confirmed_value === null ? null : maskPii(f.confirmed_value) })),
    })),
    files_deleted_at: c.files_deleted_at,
    question_rounds: c.question_rounds.map((r) => ({
      ...r,
      questions: r.questions.map((qq) => ({
        ...qq,
        answer: qq.answer ? { ...qq.answer, value: qq.answer.value === null || qq.options.length > 0 ? qq.answer.value : maskPii(qq.answer.value) } : null,
      })),
    })),
    classification: c.classification,
    preferences: c.preferences,
    recommendations: c.recommendations.map((r) => ({ ...r, lawyer_active: db.lawyers.some((l) => l.id === r.lawyer.id && l.active) })),
    chosen_lawyer: c.choice ? { lawyer_id: c.choice.lawyer_id, name: c.choice.contact.name, rank: c.choice.rank, chosen_at: c.choice.chosen_at } : null,
  };
  return detail;
});
