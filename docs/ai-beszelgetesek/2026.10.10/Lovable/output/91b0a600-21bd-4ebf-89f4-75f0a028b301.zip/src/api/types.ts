/**
 * All request / response types of the backend API.
 * Field names are snake_case exactly as in the backend JSON; dates are ISO 8601
 * strings; ids are opaque UUID v4 strings.
 */

export type UUID = string;
export type ISODateTime = string;
/** YYYY-MM-DD */
export type ISODate = string;

// ---------- Enums ----------

export type Role = "client" | "admin";
export type AccountStatus = "active" | "suspended" | "suspended_auto" | "banned";
export type CaseStatus =
  | "in_progress"
  | "waiting_for_answers"
  | "recommendations_ready"
  | "lawyer_chosen"
  | "unclassified";
export type ClassificationResult = "classified" | "needs_more_info" | "not_supported";
export type ClassificationMethod = "rule_based" | "llm";
export type ConsultationFormat = "online" | "in_person";
export type ConsultationPreference = "online" | "in_person" | "either";
export type QuestionType = "multiple_choice" | "yes_no" | "date" | "short_text";
export type AnswerStatus = "answered" | "not_answered";
export type MatchCriterion = "specialty" | "location" | "language" | "format" | "fee";
export type UiLanguage = "hu" | "en";
/** Fixed list of languages a lawyer can speak / a client can prefer (ISO 639-1). */
export type LanguageCode = "hu" | "en" | "de" | "fr" | "es" | "it" | "ro" | "sk" | "uk" | "ru";
export const LANGUAGE_CODES: readonly LanguageCode[] = ["hu", "en", "de", "fr", "es", "it", "ro", "sk", "uk", "ru"];
export const CONSULTATION_FORMATS: readonly ConsultationFormat[] = ["online", "in_person"];
export const CASE_STATUSES: readonly CaseStatus[] = [
  "in_progress",
  "waiting_for_answers",
  "recommendations_ready",
  "lawyer_chosen",
  "unclassified",
];

/** Where an unfinished case continues. "done" = nothing left to do. */
export type WizardStep = "documents" | "questions" | "classification" | "preferences" | "recommendations" | "done";

// ---------- Shared ----------

export interface Page<T> {
  items: T[];
  total: number;
  page: number;
  page_size: number;
}

/** Error body for non-422 errors: { "detail": ErrorDetail } */
export interface ErrorDetail {
  code: string;
  message: string;
  field_errors?: Record<string, string>;
  [extra: string]: unknown;
}

/** FastAPI validation error body (422): { "detail": ValidationErrorItem[] } */
export interface ValidationErrorItem {
  loc: (string | number)[];
  msg: string;
  type: string;
}

// ---------- Config ----------

export interface AppSettings {
  description_min_length: number;
  description_max_length: number;
  questions_per_round: number;
  max_question_rounds: number;
  page_size_my_cases: number;
  page_size_admin_cases: number;
  page_size_admin_lawyers: number;
  page_size_lawyer_directory: number;
  password_min_length: number;
  password_max_length: number;
  inactivity_timeout_minutes: number;
  max_upload_size_mb: number;
  allowed_upload_types: string[];
  file_retention_days: number;
  account_inactivity_deletion_days: number;
}

// ---------- Auth & account ----------

export interface CsrfResponse {
  csrf_token: string;
}

export interface User {
  id: UUID;
  username: string;
  email: string;
  role: Role;
  status: AccountStatus;
  consent_given: boolean;
  consent_given_at: ISODateTime | null;
  created_at: ISODateTime;
}

export interface LoginRequest {
  /** Username or email address */
  login: string;
  password: string;
}

export interface RegisterRequest {
  username: string;
  email: string;
  password: string;
  password_confirm: string;
  consent: boolean;
}

/** Extra fields of the 403 error returned when a suspended / banned user logs in. */
export interface AccountStatusErrorDetail extends ErrorDetail {
  code: "account_suspended" | "account_suspended_auto" | "account_banned";
  status: Exclude<AccountStatus, "active">;
  suspended_until: ISODateTime | null;
}

export interface PasswordResetRequest {
  email: string;
}

export interface ProfileUpdateRequest {
  username?: string;
  email?: string;
  /** Required when the email address changes. */
  current_password?: string;
}

export interface PasswordChangeRequest {
  current_password: string;
  new_password: string;
  new_password_confirm: string;
}

export interface ConsentRequest {
  given: boolean;
}

export interface AccountDeleteRequest {
  password: string;
}

export interface DataExport {
  exported_at: ISODateTime;
  user: User;
  cases: CaseDetail[];
}

// ---------- Categories ----------

export interface CategoryRef {
  id: UUID;
  code: string;
  /** Legal term, e.g. "Lakásbérleti jog" */
  name: string;
  /** Plain-language client-facing name */
  plain_name: string;
}

export interface Category extends CategoryRef {
  description: string;
  example_problems: string[];
  active: boolean;
  created_at: ISODateTime;
  updated_at: ISODateTime;
}

export interface AdminCategory extends Category {
  active_lawyer_count: number;
}

export interface CategoryInput {
  code: string;
  name: string;
  plain_name: string;
  description: string;
  example_problems: string[];
  active: boolean;
}

export interface TaxonomyVersion {
  id: UUID;
  version: number;
  created_at: ISODateTime;
  created_by: string;
  change_summary: string;
}

export interface CategoryList {
  taxonomy_version: TaxonomyVersion;
  items: Category[];
}

export interface AdminCategoryList {
  taxonomy_version: TaxonomyVersion;
  items: AdminCategory[];
}

export interface LawyerRefDto {
  id: UUID;
  name: string;
}

/** 409 detail when deleting a category still used by active lawyers. */
export interface CategoryInUseDetail extends ErrorDetail {
  code: "category_in_use";
  lawyers: LawyerRefDto[];
}

// ---------- Lawyers ----------

export interface LawyerPublic {
  id: UUID;
  name: string;
  city: string;
  category_ids: UUID[];
  languages: LanguageCode[];
  consultation_formats: ConsultationFormat[];
  price_per_hour: number;
}

export interface Lawyer extends LawyerPublic {
  phone: string;
  email: string;
  website: string | null;
  booking_url: string | null;
  office_address: string;
  active: boolean;
  created_at: ISODateTime;
  updated_at: ISODateTime;
}

export interface LawyerInput {
  name: string;
  phone: string;
  email: string;
  website: string | null;
  booking_url: string | null;
  office_address: string;
  city: string;
  category_ids: UUID[];
  languages: LanguageCode[];
  consultation_formats: ConsultationFormat[];
  price_per_hour: number;
  active: boolean;
}

export interface LawyerQuery {
  q?: string;
  category_id?: UUID;
  city?: string;
  language?: LanguageCode;
  format?: ConsultationFormat;
  active?: boolean;
  page?: number;
  page_size?: number;
}

export interface LawyerDirectoryQuery {
  category_id?: UUID;
  city?: string;
  page?: number;
  page_size?: number;
}

// ---------- Cases ----------

export interface CaseSummary {
  id: UUID;
  created_at: ISODateTime;
  updated_at: ISODateTime;
  title: string;
  status: CaseStatus;
  current_step: WizardStep;
  category: CategoryRef | null;
  chosen_lawyer_name: string | null;
}

export interface MyCasesQuery {
  status?: CaseStatus;
  category_id?: UUID;
  page?: number;
  page_size?: number;
}

export interface ExtractedField {
  key: string;
  value: string;
  /** Value confirmed or corrected by the client; null until confirmed. */
  confirmed_value: string | null;
}

export interface CaseDocument {
  id: UUID;
  filename: string;
  content_type: string;
  size_bytes: number;
  uploaded_at: ISODateTime;
  confirmed: boolean;
  extracted_fields: ExtractedField[];
}

export interface DocumentConfirmRequest {
  fields: { key: string; value: string }[];
}

export interface QuestionOption {
  value: string;
  label: string;
}

export interface FollowUpAnswer {
  status: AnswerStatus;
  value: string | null;
  answered_at: ISODateTime;
}

export interface FollowUpQuestion {
  id: UUID;
  round: number;
  type: QuestionType;
  text: string;
  options: QuestionOption[];
  answer: FollowUpAnswer | null;
}

export interface QuestionRound {
  round: number;
  questions: FollowUpQuestion[];
  submitted_at: ISODateTime | null;
}

export interface AnswerSubmission {
  question_id: UUID;
  /** A skipped question is sent as "not_answered" with value null. */
  status: AnswerStatus;
  value: string | null;
}

export interface AnswersRequest {
  answers: AnswerSubmission[];
}

export interface Classification {
  result: ClassificationResult;
  category: CategoryRef | null;
  /** 0..1 */
  confidence: number | null;
  method: ClassificationMethod;
  taxonomy_version: number;
  classified_at: ISODateTime;
}

export interface Preferences {
  city: string;
  languages: LanguageCode[];
  consultation_format: ConsultationPreference;
  /** HUF per hour, null = no limit */
  max_price: number | null;
}

export interface CriterionMatch {
  criterion: MatchCriterion;
  matched: boolean;
}

export interface Recommendation {
  id: UUID;
  rank: number;
  score: number;
  lawyer: LawyerPublic;
  criteria: CriterionMatch[];
  /** One-sentence plain-language summary in the request language. */
  summary: string;
  /** False when the lawyer was deactivated after the recommendation was made. */
  lawyer_active: boolean;
  created_at: ISODateTime;
}

export interface LawyerContact {
  lawyer_id: UUID;
  name: string;
  phone: string;
  email: string;
  office_address: string;
  city: string;
  website: string | null;
  booking_url: string | null;
  consultation_formats: ConsultationFormat[];
  price_per_hour: number;
}

export interface LawyerChoice {
  recommendation_id: UUID;
  lawyer_id: UUID;
  rank: number;
  chosen_at: ISODateTime;
  contact: LawyerContact;
}

export interface ChoiceRequest {
  recommendation_id: UUID;
}

export interface CaseDetail {
  id: UUID;
  created_at: ISODateTime;
  updated_at: ISODateTime;
  status: CaseStatus;
  current_step: WizardStep;
  description: string;
  description_submitted_at: ISODateTime;
  documents: CaseDocument[];
  files_deleted_at: ISODateTime | null;
  question_rounds: QuestionRound[];
  classification: Classification | null;
  preferences: Preferences | null;
  recommendations: Recommendation[];
  choice: LawyerChoice | null;
}

export interface CreateCaseRequest {
  description: string;
}

// ---------- Admin ----------

export interface AdminDashboard {
  active_lawyers: number;
  inactive_lawyers: number;
  active_categories: number;
  taxonomy_version: number;
  total_cases: number;
  unclassified_cases: number;
  cases_last_7_days: number;
  latest_accuracy: number | null;
}

export type AdminCaseSort =
  | "created_at"
  | "case_number"
  | "username"
  | "category"
  | "status"
  | "chosen_lawyer"
  | "updated_at";
export type SortOrder = "asc" | "desc";

export interface AdminCaseQuery {
  q?: string;
  category_id?: UUID;
  status?: CaseStatus;
  date_from?: ISODate;
  date_to?: ISODate;
  /** Only cases with confidence ≤ this value (0..1) */
  confidence_max?: number;
  lawyer_id?: UUID;
  has_documents?: boolean;
  sort?: AdminCaseSort;
  order?: SortOrder;
  page?: number;
  page_size?: number;
}

export interface AdminCaseRow {
  id: UUID;
  created_at: ISODateTime;
  updated_at: ISODateTime;
  username: string;
  category: CategoryRef | null;
  status: CaseStatus;
  confidence: number | null;
  chosen_lawyer_name: string | null;
  has_documents: boolean;
}

export interface AdminDocumentMeta {
  id: UUID;
  content_type: string;
  size_bytes: number;
  uploaded_at: ISODateTime;
  /** Masked confirmed fields; original files are never exposed to admins. */
  extracted_fields: ExtractedField[];
}

export interface AdminCaseDetail {
  id: UUID;
  created_at: ISODateTime;
  updated_at: ISODateTime;
  username: string;
  status: CaseStatus;
  current_step: WizardStep;
  /** PII-masked description */
  masked_description: string;
  documents: AdminDocumentMeta[];
  files_deleted_at: ISODateTime | null;
  /** Questions with PII-masked answers */
  question_rounds: QuestionRound[];
  classification: Classification | null;
  preferences: Preferences | null;
  recommendations: Recommendation[];
  chosen_lawyer: { lawyer_id: UUID; name: string; rank: number; chosen_at: ISODateTime } | null;
}

// ---------- Metrics ----------

export interface EvaluationRun {
  id: UUID;
  created_at: ISODateTime;
  model_version: string;
  taxonomy_version: number;
  test_set_size: number;
  overall_accuracy: number;
  low_confidence_fallback_rate: number;
}

export interface CategoryAccuracy {
  category: CategoryRef;
  support: number;
  correct: number;
  accuracy: number;
}

export interface ConfusionMatrix {
  /** Row/column labels. The extra id "unclassified" stands for the fallback. */
  labels: { id: string; name: string }[];
  /** matrix[expected][predicted] */
  matrix: number[][];
}

export interface EvaluationRunDetail extends EvaluationRun {
  per_category: CategoryAccuracy[];
  confusion_matrix: ConfusionMatrix;
}
