/** Realistic Hungarian seed data for the mock server. */
import type { CaseStatus, Category, Lawyer, Preferences, QuestionRound, WizardStep } from "../types";
import type { Db, DbCase, DbUser } from "./db";
import { extractFields, generateQuestionRound, maskPii, recommend, toRef } from "./engine";
import { runEvaluation } from "./evaluation";
import { DEFAULT_SETTINGS } from "./settings";

const uuid = () => crypto.randomUUID();
const daysAgo = (d: number, h = 0) => new Date(Date.now() - (d * 24 + h) * 3600_000).toISOString();
const daysAhead = (d: number) => new Date(Date.now() + d * 24 * 3600_000).toISOString();

const CATEGORY_DATA: Omit<Category, "id" | "created_at" | "updated_at" | "active">[] = [
  {
    code: "berlet",
    name: "Lakásbérleti jog",
    plain_name: "Albérlet és lakásbérlés",
    description: "Bérleti szerződés, lakbéremelés, kaució visszafizetése, kilakoltatás és a bérlő–bérbeadó viták.",
    example_problems: [
      "A főbérlőm nem adja vissza a kauciót, pedig a lakást rendben hagytam ott.",
      "A bérbeadó egyik napról a másikra emelni akarja a lakbért és kiköltözéssel fenyeget.",
      "Beázik az albérletem, de a tulajdonos nem javíttatja meg.",
    ],
  },
  {
    code: "munka",
    name: "Munkajog",
    plain_name: "Munkahelyi problémák",
    description: "Felmondás, ki nem fizetett munkabér vagy túlóra, munkaszerződés, munkahelyi zaklatás.",
    example_problems: [
      "A munkáltatóm két hónapja nem fizeti ki a túlórámat.",
      "Indoklás nélkül felmondtak, miután szóvá tettem egy problémát.",
      "A főnököm folyamatosan megaláz a kollégák előtt a munkahelyen.",
    ],
  },
  {
    code: "csalad",
    name: "Családjog",
    plain_name: "Válás, gyermek, tartásdíj",
    description: "Válás, gyermekelhelyezés, kapcsolattartás, gyermektartásdíj és házassági vagyonjog.",
    example_problems: [
      "Válni szeretnék, és nem tudjuk megegyezni, kinél maradjon a gyerek.",
      "A volt férjem hónapok óta nem fizeti a gyermektartásdíjat.",
      "A volt feleségem nem engedi a megbeszélt láthatást.",
    ],
  },
  {
    code: "fogyaszto",
    name: "Fogyasztóvédelmi jog",
    plain_name: "Vásárlási panaszok",
    description: "Hibás termék, garancia és jótállás, webshopos vásárlás, elállás és visszatérítés.",
    example_problems: [
      "Egy webshopban vettem egy mosógépet, ami egy hét után elromlott, és nem cserélik ki.",
      "A garancia ellenére sem javítják meg a telefonomat.",
      "Visszaküldtem a terméket, de a pénzemet nem kaptam vissza.",
    ],
  },
  {
    code: "orokles",
    name: "Öröklési jog",
    plain_name: "Hagyaték és végrendelet",
    description: "Hagyatéki eljárás, végrendelet, kötelesrész, örökösök közötti viták.",
    example_problems: [
      "Édesapám elhunyt, és a testvérem vitatja a végrendeletet.",
      "Nem tudom, hogyan zajlik a hagyatéki eljárás nagymamám után.",
      "Kimaradtam az örökségből, pedig szerintem kötelesrész jár nekem.",
    ],
  },
  {
    code: "ingatlan",
    name: "Ingatlanjog",
    plain_name: "Ház, telek, adásvétel",
    description: "Ingatlan adásvétel, telekhatár- és szomszédjogi viták, földhivatali bejegyzések.",
    example_problems: [
      "A szomszéd az én telkemre építette a kerítését.",
      "Az ingatlan adásvétele után derült ki, hogy a ház tetője rossz állapotú.",
      "A földhivatal nem jegyzi be a tulajdonjogomat a telekkönyvbe.",
    ],
  },
  {
    code: "karterites",
    name: "Kártérítési jog",
    plain_name: "Baleset és kártérítés",
    description: "Közlekedési és munkahelyi baleset, személyi sérülés, biztosítói viták, kártérítés.",
    example_problems: [
      "Közlekedési balesetben megsérültem, de a biztosító keveset fizetne.",
      "A szomszéd lakásából beázott a mennyezetem, és nem akarja megtéríteni a kárt.",
      "Elestem egy bolt csúszós padlóján és eltört a csuklóm.",
    ],
  },
  {
    code: "adossag",
    name: "Végrehajtási és adósságrendezési jog",
    plain_name: "Tartozás és végrehajtás",
    description: "Tartozások, hitelek, behajtó cégek, végrehajtási eljárás és adósságrendezés.",
    example_problems: [
      "Egy behajtó cég olyan tartozást követel tőlem, amiről nem tudok.",
      "Végrehajtó jelent meg a lakásomon egy régi hitel miatt.",
      "Nem tudom törleszteni a hitelemet, és félek a végrehajtástól.",
    ],
  },
];

type LawyerSeed = [name: string, city: string, codes: string[], langs: Lawyer["languages"], formats: Lawyer["consultation_formats"], price: number, address: string, phone: string, active: boolean, web: string | null];

const LAWYER_DATA: LawyerSeed[] = [
  ["Dr. Kovács Eszter", "Budapest", ["berlet", "ingatlan"], ["hu", "en"], ["online", "in_person"], 22000, "1052 Budapest, Petőfi Sándor utca 11.", "+36 1 234 5678", true, "https://kovacs-ugyved.example.hu"],
  ["Dr. Szabó Gábor", "Budapest", ["munka"], ["hu", "de"], ["in_person"], 28000, "1066 Budapest, Teréz körút 24.", "+36 1 345 6789", true, null],
  ["Dr. Tóth Katalin", "Debrecen", ["csalad", "orokles"], ["hu"], ["online", "in_person"], 18000, "4024 Debrecen, Piac utca 31.", "+36 52 412 345", true, null],
  ["Dr. Horváth László", "Szeged", ["fogyaszto", "adossag"], ["hu", "en"], ["online"], 15000, "6720 Szeged, Kárász utca 8.", "+36 62 555 123", true, "https://horvath-jog.example.hu"],
  ["Dr. Varga Judit", "Budapest", ["csalad"], ["hu", "en", "fr"], ["online", "in_person"], 35000, "1024 Budapest, Margit körút 50.", "+36 1 456 7890", true, "https://vargajudit.example.hu"],
  ["Dr. Kiss Balázs", "Pécs", ["karterites", "fogyaszto"], ["hu"], ["in_person"], 20000, "7621 Pécs, Király utca 15.", "+36 72 333 444", true, null],
  ["Dr. Molnár Réka", "Győr", ["munka", "karterites"], ["hu", "de", "en"], ["online", "in_person"], 24000, "9021 Győr, Baross Gábor út 19.", "+36 96 512 300", true, "https://molnarreka.example.hu"],
  ["Dr. Németh Zoltán", "Miskolc", ["adossag", "berlet"], ["hu", "sk"], ["online", "in_person"], 16000, "3525 Miskolc, Széchenyi István út 40.", "+36 46 411 222", true, null],
  ["Dr. Farkas Andrea", "Budapest", ["orokles", "ingatlan"], ["hu", "en"], ["in_person"], 40000, "1013 Budapest, Attila út 7.", "+36 1 567 8901", true, null],
  ["Dr. Balogh Tamás", "Debrecen", ["munka", "berlet"], ["hu", "ro"], ["online"], 19000, "4025 Debrecen, Hatvan utca 2.", "+36 52 600 700", true, null],
  ["Dr. Papp Krisztina", "Budapest", ["berlet", "fogyaszto"], ["hu", "en", "es"], ["online"], 21000, "1137 Budapest, Pozsonyi út 12.", "+36 1 678 9012", true, "https://papp-iroda.example.hu"],
  ["Dr. Lakatos Ádám", "Szeged", ["ingatlan", "orokles", "karterites"], ["hu", "en", "uk"], ["online", "in_person"], 26000, "6722 Szeged, Tisza Lajos körút 60.", "+36 62 777 888", true, null],
];

function user(username: string, email: string, password: string, role: DbUser["role"], extra: Partial<DbUser> = {}): DbUser {
  return {
    id: uuid(),
    username,
    email,
    password_hash: `mock$${password}`,
    role,
    status: "active",
    suspended_until: null,
    consent_given: true,
    consent_given_at: daysAgo(60),
    created_at: daysAgo(60),
    failed_logins: 0,
    locked_until: null,
    ...extra,
  };
}

function answerRound(round: QuestionRound, at: string, values: (string | null)[]): QuestionRound {
  return {
    ...round,
    submitted_at: at,
    questions: round.questions.map((q, i) => {
      const v = values[i] ?? null;
      return { ...q, answer: { status: v === null ? "not_answered" : "answered", value: v, answered_at: at } };
    }),
  };
}

export function seedDatabase(): Db {
  const created = daysAgo(120);
  const categories: Category[] = CATEGORY_DATA.map((c) => ({ ...c, id: uuid(), active: true, created_at: created, updated_at: created }));
  const byCode = (code: string): Category => {
    const c = categories.find((x) => x.code === code);
    if (!c) throw new Error(`unknown category ${code}`);
    return c;
  };
  const lawyers: Lawyer[] = LAWYER_DATA.map(([name, city, codes, languages, formats, price, address, phone, active, web]) => {
    const slug = name.replace("Dr. ", "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\s+/g, ".");
    return {
      id: uuid(),
      name,
      city,
      category_ids: codes.map((c) => byCode(c).id),
      languages,
      consultation_formats: formats,
      price_per_hour: price,
      phone,
      email: `${slug}@ugyvediiroda.example.hu`,
      website: web,
      booking_url: null,
      office_address: address,
      active,
      created_at: created,
      updated_at: created,
    };
  });

  const anna = user("kovacs_anna", "anna.kovacs@example.hu", "Tavaszi-szel-2026", "client");
  const admin = user("admin_peter", "peter.admin@example.hu", "Biztonsagos-Admin-2026", "admin");
  const bela = user("nagy_bela", "bela.nagy@example.hu", "Teszt-jelszo-2026", "client");
  const users: DbUser[] = [
    anna,
    admin,
    bela,
    user("felfuggesztett_feri", "feri@example.hu", "Teszt-jelszo-2026", "client", { status: "suspended", suspended_until: daysAhead(10) }),
    user("auto_zsuzsa", "zsuzsa@example.hu", "Teszt-jelszo-2026", "client", { status: "suspended_auto" }),
    user("kitiltott_karoly", "karoly@example.hu", "Teszt-jelszo-2026", "client", { status: "banned" }),
  ];
  const extraClients = ["szilvia_t", "gergo88", "horvath_marta", "lajos_b", "eva_kertesz", "toth_dani"].map((u, i) =>
    user(u, `${u}@example.hu`, "Teszt-jelszo-2026", "client", { created_at: daysAgo(100 - i * 5) }),
  );
  users.push(...extraClients);

  const taxonomyVersion = 3;
  const taxonomy_versions = [
    { id: uuid(), version: 1, created_at: daysAgo(150), created_by: "admin_peter", change_summary: "Kezdeti kategórialista (6 kategória)" },
    { id: uuid(), version: 2, created_at: daysAgo(135), created_by: "admin_peter", change_summary: "Új kategória: Kártérítési jog" },
    { id: uuid(), version: 3, created_at: daysAgo(120), created_by: "admin_peter", change_summary: "Új kategória: Végrehajtási és adósságrendezési jog" },
  ];
  const maxRounds = DEFAULT_SETTINGS.max_question_rounds;
  const perRound = DEFAULT_SETTINGS.questions_per_round;

  const baseCase = (owner: DbUser, description: string, createdAt: string, status: CaseStatus, step: WizardStep): DbCase => ({
    id: uuid(),
    owner_id: owner.id,
    created_at: createdAt,
    updated_at: createdAt,
    status,
    current_step: step,
    description,
    masked_description: maskPii(description),
    description_submitted_at: createdAt,
    documents: [],
    files_deleted_at: null,
    question_rounds: [],
    classification: null,
    preferences: null,
    recommendations: [],
    choice: null,
    fail_next_analysis: false,
    choice_history: [],
  });

  const cases: DbCase[] = [];
  const classified = (code: string, confidence: number, at: string) => ({
    result: "classified" as const,
    category: toRef(byCode(code)),
    confidence,
    method: "rule_based" as const,
    taxonomy_version: taxonomyVersion,
    classified_at: at,
  });
  const choose = (c: DbCase, rank: number, at: string) => {
    const rec = c.recommendations[rank - 1];
    if (!rec) return;
    const l = lawyers.find((x) => x.id === rec.lawyer.id);
    if (!l) return;
    c.choice = {
      recommendation_id: rec.id,
      lawyer_id: l.id,
      rank,
      chosen_at: at,
      contact: {
        lawyer_id: l.id,
        name: l.name,
        phone: l.phone,
        email: l.email,
        office_address: l.office_address,
        city: l.city,
        website: l.website,
        booking_url: l.booking_url,
        consultation_formats: l.consultation_formats,
        price_per_hour: l.price_per_hour,
      },
    };
    c.choice_history.push({ recommendation_id: rec.id, lawyer_id: l.id, rank, chosen_at: at });
    c.status = "lawyer_chosen";
    c.current_step = "done";
  };

  // --- Anna's cases: one per status ---
  cases.push(
    baseCase(anna, "A főbérlőm nem akarja visszaadni a kauciót, pedig a lakást rendben hagytam ott. Már háromszor kértem írásban, de nem válaszol.", daysAgo(1, 3), "in_progress", "documents"),
  );

  const c2 = baseCase(anna, "Problémám van az egyik rokonommal egy közösen használt nyaraló miatt, nem értünk egyet abban, ki mit fizessen.", daysAgo(3), "waiting_for_answers", "questions");
  c2.question_rounds = [generateQuestionRound(1, perRound, "hu", categories)];
  cases.push(c2);

  const c3 = baseCase(anna, "Albérletben lakom Budapesten, a bérbeadó egyik napról a másikra 40%-kal emelni akarja a lakbért, és kiköltözéssel fenyeget.", daysAgo(6), "recommendations_ready", "recommendations");
  c3.question_rounds = [answerRound(generateQuestionRound(1, perRound, "hu", categories), daysAgo(6), ["category:berlet", daysAgo(20).slice(0, 10), "bérbeadó", "yes", "Budapest"])];
  c3.classification = classified("berlet", 0.88, daysAgo(6));
  c3.preferences = { city: "Budapest", languages: ["hu"], consultation_format: "either", max_price: 25000 };
  c3.recommendations = recommend(lawyers, c3.classification.category ?? toRef(byCode("berlet")), c3.preferences, "hu");
  cases.push(c3);

  const c4 = baseCase(anna, "A munkáltatóm két hónapja nem fizeti ki a túlórákat, és most felmondással fenyeget, ha még egyszer szólok miatta.", daysAgo(45), "lawyer_chosen", "done");
  c4.documents = [
    {
      id: uuid(),
      filename: "munkaszerzodes.pdf",
      content_type: "application/pdf",
      size_bytes: 482_133,
      uploaded_at: daysAgo(45),
      confirmed: true,
      extracted_fields: extractFields("munkaszerzodes.pdf", "hu").map((f) => ({ ...f, confirmed_value: f.key === "other_party" ? "Gyártó Zrt." : f.value })),
    },
  ];
  c4.files_deleted_at = daysAgo(15);
  c4.question_rounds = [answerRound(generateQuestionRound(1, perRound, "hu", categories), daysAgo(45), ["category:munka", null, "munkáltató", "yes", "Győr"])];
  c4.classification = classified("munka", 0.91, daysAgo(45));
  c4.preferences = { city: "Győr", languages: ["hu", "de"], consultation_format: "online", max_price: null };
  c4.recommendations = recommend(lawyers, c4.classification.category ?? toRef(byCode("munka")), c4.preferences, "hu");
  choose(c4, 1, daysAgo(44));
  cases.push(c4);

  const c5 = baseCase(anna, "Szeretném tudni, hogy egy külföldi weboldalon talált fotót felhasználhatok-e a saját blogomon.", daysAgo(20), "unclassified", "done");
  c5.question_rounds = [
    answerRound(generateQuestionRound(1, perRound, "hu", categories), daysAgo(20), ["unknown", null, null, "no", null]),
    answerRound(generateQuestionRound(2, perRound, "hu", categories), daysAgo(20), [null, "no", "no", null, "advice"]),
  ];
  c5.classification = { result: "not_supported", category: null, confidence: 0.3, method: "rule_based", taxonomy_version: taxonomyVersion, classified_at: daysAgo(20) };
  cases.push(c5);

  // Béla's case (used to test that other users' cases return 404)
  const b1 = baseCase(bela, "Válni szeretnék, és nem tudunk megegyezni, kinél maradjon a gyerek és mennyi legyen a tartásdíj.", daysAgo(12), "lawyer_chosen", "done");
  b1.classification = classified("csalad", 0.93, daysAgo(12));
  b1.preferences = { city: "Budapest", languages: ["hu"], consultation_format: "in_person", max_price: null };
  b1.recommendations = recommend(lawyers, b1.classification.category ?? toRef(byCode("csalad")), b1.preferences, "hu");
  choose(b1, 2, daysAgo(11));
  cases.push(b1);

  // Generated cases for admin list pagination
  const statuses: CaseStatus[] = ["lawyer_chosen", "recommendations_ready", "unclassified", "in_progress", "waiting_for_answers"];
  const cities = ["Budapest", "Debrecen", "Szeged", "Pécs", "Győr", "Miskolc"];
  for (let i = 0; i < 56; i++) {
    const owner = extraClients[i % extraClients.length] ?? bela;
    const cat = categories[i % categories.length] ?? byCode("berlet");
    const status = statuses[i % statuses.length] ?? "in_progress";
    const at = daysAgo(2 + ((i * 7) % 88), i % 24);
    const description = `${cat.example_problems[i % cat.example_problems.length] ?? cat.description} Kérem, segítsenek, mit tehetek.`;
    const step: WizardStep = status === "in_progress" ? "documents" : status === "waiting_for_answers" ? "questions" : status === "recommendations_ready" ? "recommendations" : "done";
    const c = baseCase(owner, description, at, status, step);
    if (i % 3 === 0) {
      c.documents = [
        {
          id: uuid(),
          filename: `dokumentum_${i + 1}.pdf`,
          content_type: "application/pdf",
          size_bytes: 120_000 + i * 1000,
          uploaded_at: at,
          confirmed: true,
          extracted_fields: extractFields(`dokumentum_${i + 1}.pdf`, "hu").map((f) => ({ ...f, confirmed_value: f.value })),
        },
      ];
    }
    if (status === "waiting_for_answers") c.question_rounds = [generateQuestionRound(1, perRound, "hu", categories)];
    if (status === "unclassified") {
      c.classification = { result: "not_supported", category: null, confidence: 0.25 + (i % 4) * 0.1, method: "rule_based", taxonomy_version: taxonomyVersion, classified_at: at };
    }
    if (status === "lawyer_chosen" || status === "recommendations_ready") {
      c.classification = classified(cat.code, Math.round((0.7 + ((i * 13) % 26) / 100) * 100) / 100, at);
      const prefs: Preferences = { city: cities[i % cities.length] ?? "Budapest", languages: ["hu"], consultation_format: "either", max_price: null };
      c.preferences = prefs;
      c.recommendations = recommend(lawyers, toRef(cat), prefs, "hu");
      if (status === "lawyer_chosen") choose(c, (i % 2) + 1, at);
      if (c.recommendations.length === 0) c.status = "unclassified";
    }
    c.updated_at = at;
    cases.push(c);
  }

  // Deactivate one lawyer AFTER recommendations were made (US-08 test path)
  const balogh = lawyers.find((l) => l.name === "Dr. Balogh Tamás");
  if (balogh) balogh.active = false;

  const evaluations = [
    runEvaluation(categories, 2, maxRounds, "rules-v1.0", daysAgo(60), 9),
    runEvaluation(categories, 3, maxRounds, "rules-v1.1 + llm-fallback-2026-03", daysAgo(25), 4),
    runEvaluation(categories, 3, maxRounds, "rules-v1.2 + llm-fallback-2026-06", daysAgo(4), 0),
  ].reverse();

  return {
    users,
    sessions: [],
    cookie_session_id: null,
    csrf_token: null,
    categories,
    taxonomy_versions,
    lawyers,
    cases,
    evaluations,
    banned_emails: ["karoly@example.hu", "spam@example.com", "tiltott@example.hu"],
    audit_log: [],
  };
}
