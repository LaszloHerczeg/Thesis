/**
 * In-memory mock database, persisted to sessionStorage so a refresh keeps state.
 * This is the ONLY data the frontend keeps in browser storage.
 */
import { config } from "@/config";
import type {
  AccountStatus,
  CaseDetail,
  Category,
  EvaluationRunDetail,
  Lawyer,
  Role,
  TaxonomyVersion,
  UUID,
} from "../types";
import { seedDatabase } from "./seed";

export interface DbUser {
  id: UUID;
  username: string;
  email: string;
  /** Mock "hash" – a real backend stores Argon2id/bcrypt hashes. */
  password_hash: string;
  role: Role;
  status: AccountStatus;
  suspended_until: string | null;
  consent_given: boolean;
  consent_given_at: string | null;
  created_at: string;
  failed_logins: number;
  locked_until: string | null;
}

export interface DbSession {
  id: UUID;
  user_id: UUID;
  created_at: string;
  last_seen_at: string;
}

export interface DbChoiceEvent {
  recommendation_id: UUID;
  lawyer_id: UUID;
  rank: number;
  chosen_at: string;
}

export interface DbCase extends CaseDetail {
  owner_id: UUID;
  /** Masked copy of the description (US-41) */
  masked_description: string;
  /** Test hook: the first classification attempt fails with 503 (US-38). */
  fail_next_analysis: boolean;
  choice_history: DbChoiceEvent[];
}

export interface DbAuditEntry {
  id: UUID;
  at: string;
  actor: string;
  action: string;
  target: string;
}

export interface Db {
  users: DbUser[];
  sessions: DbSession[];
  /** Simulates the HttpOnly session cookie of the browser. */
  cookie_session_id: UUID | null;
  csrf_token: string | null;
  categories: Category[];
  taxonomy_versions: TaxonomyVersion[];
  lawyers: Lawyer[];
  cases: DbCase[];
  evaluations: EvaluationRunDetail[];
  /** Normalised banned emails (and hashes of deleted banned accounts in a real backend). */
  banned_emails: string[];
  audit_log: DbAuditEntry[];
}

let cache: Db | null = null;

export function loadDb(): Db {
  if (cache) return cache;
  if (typeof window !== "undefined") {
    const raw = window.sessionStorage.getItem(config.mockStorageKey);
    if (raw) {
      try {
        cache = JSON.parse(raw) as Db;
        return cache;
      } catch {
        // fall through to re-seed
      }
    }
  }
  cache = seedDatabase();
  saveDb(cache);
  return cache;
}

export function saveDb(db: Db): void {
  cache = db;
  if (typeof window !== "undefined") {
    window.sessionStorage.setItem(config.mockStorageKey, JSON.stringify(db));
  }
}

export function resetDb(): void {
  cache = null;
  if (typeof window !== "undefined") window.sessionStorage.removeItem(config.mockStorageKey);
}

export function audit(db: Db, actor: string, action: string, target: string): void {
  db.audit_log.unshift({ id: crypto.randomUUID(), at: new Date().toISOString(), actor, action, target });
  if (db.audit_log.length > 500) db.audit_log.length = 500;
}
