import { http } from "../http";
import type { AccountDeleteRequest, DataExport, PasswordChangeRequest, ProfileUpdateRequest, User } from "../types";

export const accountService = {
  updateProfile: (body: ProfileUpdateRequest): Promise<User> => http.patch<User>("/account/profile", body),
  changePassword: (body: PasswordChangeRequest): Promise<void> => http.post<void>("/account/password", body),
  setConsent: (given: boolean): Promise<User> => http.post<User>("/account/consent", { given }),
  exportData: (): Promise<DataExport> => http.get<DataExport>("/account/export"),
  deleteAccount: (body: AccountDeleteRequest): Promise<void> => http.delete<void>("/account", body),
};
