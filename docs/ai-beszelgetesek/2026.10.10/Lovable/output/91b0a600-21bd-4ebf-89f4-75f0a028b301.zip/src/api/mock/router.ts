/** Tiny router + helpers used by the mock endpoint handlers. */
import type { UiLanguage, User, ValidationErrorItem } from "../types";
import type { Db, DbSession, DbUser } from "./db";

export type Auth = "public" | "user" | "admin";
export type Method = "GET" | "POST" | "PUT" | "PATCH" | "DELETE";

export interface Ctx {
  db: Db;
  params: Record<string, string>;
  query: URLSearchParams;
  body: unknown;
  lang: UiLanguage;
  user: DbUser | null;
  session: DbSession | null;
}

export class HttpError {
  constructor(
    readonly status: number,
    readonly detail: unknown,
    readonly headers: Record<string, string> = {},
  ) {}
}

export class MockResult {
  constructor(
    readonly status: number,
    readonly body: unknown,
    readonly headers: Record<string, string> = {},
  ) {}
}

export type Handler = (ctx: Ctx) => unknown;

interface RouteDef {
  method: Method;
  regex: RegExp;
  keys: string[];
  auth: Auth;
  handler: Handler;
}

export const routes: RouteDef[] = [];

export function route(method: Method, pattern: string, auth: Auth, handler: Handler): void {
  const keys: string[] = [];
  const regex = new RegExp(
    `^${pattern.replace(/:([a-zA-Z_]+)/g, (_m, key: string) => {
      keys.push(key);
      return "([^/]+)";
    })}$`,
  );
  routes.push({ method, regex, keys, auth, handler });
}

export function matchRoute(method: string, path: string): { def: RouteDef; params: Record<string, string> } | null {
  for (const def of routes) {
    if (def.method !== method) continue;
    const m = def.regex.exec(path);
    if (!m) continue;
    const params: Record<string, string> = {};
    def.keys.forEach((k, i) => {
      params[k] = decodeURIComponent(m[i + 1] ?? "");
    });
    return { def, params };
  }
  return null;
}

export const tr = (ctx: Ctx, hu: string, en: string): string => (ctx.lang === "hu" ? hu : en);

export function fail(status: number, code: string, message: string, extra: Record<string, unknown> = {}, headers: Record<string, string> = {}): HttpError {
  return new HttpError(status, { code, message, ...extra }, headers);
}

export function notFound(ctx: Ctx): HttpError {
  return fail(404, "not_found", tr(ctx, "Nem található.", "Not found."));
}

/** FastAPI-style 422 */
export function validation(errors: [field: string, msg: string][]): HttpError {
  const detail: ValidationErrorItem[] = errors.map(([field, msg]) => ({ loc: ["body", ...field.split(".")], msg, type: "value_error" }));
  return new HttpError(422, detail);
}

export function obj(body: unknown): Record<string, unknown> {
  return typeof body === "object" && body !== null && !Array.isArray(body) ? (body as Record<string, unknown>) : {};
}

export function str(o: Record<string, unknown>, key: string): string {
  const v = o[key];
  return typeof v === "string" ? v : "";
}

export function requireUser(ctx: Ctx): DbUser {
  if (!ctx.user) throw fail(401, "unauthorized", tr(ctx, "Bejelentkezés szükséges.", "Authentication required."));
  return ctx.user;
}

export function toUserDto(u: DbUser): User {
  return {
    id: u.id,
    username: u.username,
    email: u.email,
    role: u.role,
    status: u.status,
    consent_given: u.consent_given,
    consent_given_at: u.consent_given_at,
    created_at: u.created_at,
  };
}

export function paginate<T>(items: T[], query: URLSearchParams, defaultSize: number): { items: T[]; total: number; page: number; page_size: number } {
  const page = Math.max(1, Number(query.get("page") ?? "1") || 1);
  const page_size = Math.min(200, Math.max(1, Number(query.get("page_size") ?? String(defaultSize)) || defaultSize));
  return { items: items.slice((page - 1) * page_size, page * page_size), total: items.length, page, page_size };
}
