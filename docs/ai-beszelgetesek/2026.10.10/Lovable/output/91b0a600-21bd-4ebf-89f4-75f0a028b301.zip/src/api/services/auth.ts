import { http, refreshCsrf } from "../http";
import type { LoginRequest, PasswordResetRequest, RegisterRequest, User } from "../types";

export const authService = {
  /** Fetches a fresh in-memory CSRF token. */
  csrf: (): Promise<string> => refreshCsrf(),

  /** Current user, or null when not logged in (no log-in redirect). */
  async me(): Promise<User | null> {
    try {
      return await http.get<User>("/auth/me", { skipAuthRedirect: true });
    } catch (e) {
      if (e instanceof Error && "status" in e && (e as { status: number }).status === 401) return null;
      throw e;
    }
  },

  async login(body: LoginRequest): Promise<User> {
    const user = await http.post<User>("/auth/login", body, { skipAuthRedirect: true, localRateLimit: true });
    await refreshCsrf();
    return user;
  },

  async register(body: RegisterRequest): Promise<User> {
    const user = await http.post<User>("/auth/register", body);
    await refreshCsrf();
    return user;
  },

  async logout(): Promise<void> {
    await http.post<void>("/auth/logout", undefined, { skipAuthRedirect: true });
    await refreshCsrf();
  },

  requestPasswordReset: (body: PasswordResetRequest): Promise<{ message: string }> =>
    http.post<{ message: string }>("/auth/password-reset", body),
};
