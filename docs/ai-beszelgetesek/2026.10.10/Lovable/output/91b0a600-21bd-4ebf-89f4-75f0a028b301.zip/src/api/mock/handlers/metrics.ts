import { runEvaluation } from "../evaluation";
import { MockResult, notFound, route } from "../router";
import { DEFAULT_SETTINGS } from "../settings";
import { currentTaxonomy } from "./catalog";

route("GET", "/admin/metrics/evaluations", "admin", (ctx) =>
  ctx.db.evaluations.map(({ per_category: _p, confusion_matrix: _c, ...run }) => run),
);

route("GET", "/admin/metrics/evaluations/:id", "admin", (ctx) => {
  const run = ctx.db.evaluations.find((e) => e.id === ctx.params["id"]);
  if (!run) throw notFound(ctx);
  return run;
});

route("POST", "/admin/metrics/evaluations", "admin", (ctx) => {
  const run = runEvaluation(
    ctx.db.categories,
    currentTaxonomy(ctx.db).version,
    DEFAULT_SETTINGS.max_question_rounds,
    "rules-v1.2 + llm-fallback-2026-06",
    new Date().toISOString(),
  );
  ctx.db.evaluations.unshift(run);
  return new MockResult(201, run);
});
