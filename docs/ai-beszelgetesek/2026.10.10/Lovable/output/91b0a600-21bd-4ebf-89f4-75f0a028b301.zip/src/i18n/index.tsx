import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { setRequestLanguage } from "@/api";
import type { UiLanguage } from "@/api/types";
import { hu } from "./hu";
import { en } from "./en";

type Widen<T> = { [K in keyof T]: T[K] extends string ? string : Widen<T[K]> };
export type Dict = Widen<typeof hu>;

type Leaves<T, P extends string = ""> = {
  [K in keyof T & (string | number)]: T[K] extends string ? `${P}${K}` : Leaves<T[K], `${P}${K}.`>;
}[keyof T & (string | number)];
export type TKey = Leaves<typeof hu>;
export type TVars = Record<string, string | number>;

const DICTS: Record<UiLanguage, Dict> = { hu, en };
const LANG_KEY = "lpslm-ui-language";

function lookup(dict: Dict, key: string): string {
  let cur: unknown = dict;
  for (const part of key.split(".")) {
    if (typeof cur !== "object" || cur === null) return key;
    cur = (cur as Record<string, unknown>)[part];
  }
  return typeof cur === "string" ? cur : key;
}

export interface I18n {
  lang: UiLanguage;
  setLang: (l: UiLanguage) => void;
  t: (key: TKey, vars?: TVars) => string;
  formatDate: (iso: string) => string;
  formatDateTime: (iso: string) => string;
  formatNumber: (n: number) => string;
  formatPercent: (n: number) => string;
  formatCurrency: (n: number) => string;
  languageName: (code: string) => string;
}

const Ctx = createContext<I18n | null>(null);

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<UiLanguage>("hu");

  useEffect(() => {
    const stored = window.localStorage.getItem(LANG_KEY);
    if (stored === "hu" || stored === "en") setLangState(stored);
  }, []);

  useEffect(() => {
    setRequestLanguage(lang);
    document.documentElement.lang = lang;
  }, [lang]);

  const setLang = useCallback((l: UiLanguage) => {
    window.localStorage.setItem(LANG_KEY, l);
    setLangState(l);
  }, []);

  const value = useMemo<I18n>(() => {
    const dict = DICTS[lang];
    const locale = lang === "hu" ? "hu-HU" : "en-GB";
    const dn = new Intl.DisplayNames([locale], { type: "language" });
    return {
      lang,
      setLang,
      t: (key, vars) => {
        let s = lookup(dict, key);
        if (vars) for (const [k, v] of Object.entries(vars)) s = s.split(`{${k}}`).join(String(v));
        return s;
      },
      formatDate: (iso) => new Intl.DateTimeFormat(locale, { dateStyle: "medium" }).format(new Date(iso)),
      formatDateTime: (iso) => new Intl.DateTimeFormat(locale, { dateStyle: "medium", timeStyle: "short" }).format(new Date(iso)),
      formatNumber: (n) => new Intl.NumberFormat(locale).format(n),
      formatPercent: (n) => new Intl.NumberFormat(locale, { style: "percent", maximumFractionDigits: 0 }).format(n),
      formatCurrency: (n) => new Intl.NumberFormat(locale, { style: "currency", currency: "HUF", maximumFractionDigits: 0 }).format(n),
      languageName: (code) => {
        const name = dn.of(code) ?? code;
        return name.charAt(0).toUpperCase() + name.slice(1);
      },
    };
  }, [lang, setLang]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useI18n(): I18n {
  const v = useContext(Ctx);
  if (!v) throw new Error("useI18n outside I18nProvider");
  return v;
}
