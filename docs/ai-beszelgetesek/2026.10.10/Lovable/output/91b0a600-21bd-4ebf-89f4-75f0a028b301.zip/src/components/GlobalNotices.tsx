import { useEffect, useState } from "react";
import { subscribeNotices, type Notice } from "@/api";
import { useI18n } from "@/i18n";

/** Shows the wrapper's global 429 / 5xx / network notices, announced to screen readers. */
export function GlobalNotices() {
  const { t } = useI18n();
  const [notice, setNotice] = useState<Notice | null>(null);

  useEffect(() => subscribeNotices(setNotice), []);
  useEffect(() => {
    if (!notice) return;
    const ms = notice.kind === "rate_limited" ? (notice.retry_after ?? 10) * 1000 : 8000;
    const id = setTimeout(() => setNotice(null), ms);
    return () => clearTimeout(id);
  }, [notice]);

  return (
    <div aria-live="assertive" className="container">
      {notice && (
        <div className="alert alert-error notice" role="alert">
          <p>
            {notice.kind === "rate_limited"
              ? t("errors.rateLimited", { seconds: notice.retry_after ?? 30 })
              : notice.kind === "network_error"
                ? t("errors.network")
                : t("errors.server")}
          </p>
          <button type="button" className="btn btn-ghost btn-sm" aria-label={t("errors.dismiss")} onClick={() => setNotice(null)}>
            ✕
          </button>
        </div>
      )}
    </div>
  );
}
