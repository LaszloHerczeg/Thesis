import { Link } from "@tanstack/react-router";
import type { CaseStatus } from "@/api/types";
import { useI18n } from "@/i18n";

export function StatusBadge({ status }: { status: CaseStatus }) {
  const { t } = useI18n();
  return <span className={`badge badge-${status}`}>{t(`status.${status}`)}</span>;
}

export function ShortDisclaimer({ withGuarantee = false }: { withGuarantee?: boolean }) {
  const { t } = useI18n();
  return (
    <aside className="disclaimer" aria-label={t("footer.disclaimer")}>
      <p>
        <span aria-hidden="true">ⓘ </span>
        {t("disclaimer.short")} {withGuarantee && t("disclaimer.noGuarantee")}{" "}
        <Link to="/disclaimer">{t("disclaimer.fullLink")}</Link>
      </p>
    </aside>
  );
}

export function Pagination({
  page,
  pageSize,
  total,
  onPage,
}: {
  page: number;
  pageSize: number;
  total: number;
  onPage: (p: number) => void;
}) {
  const { t } = useI18n();
  const pages = Math.max(1, Math.ceil(total / pageSize));
  if (pages <= 1) return null;
  return (
    <nav className="pagination" aria-label={t("common.pagination")}>
      <button type="button" className="btn btn-secondary btn-sm" disabled={page <= 1} onClick={() => onPage(page - 1)}>
        ← {t("common.previous")}
      </button>
      <span aria-current="page">{t("common.pageOf", { page, pages })}</span>
      <button type="button" className="btn btn-secondary btn-sm" disabled={page >= pages} onClick={() => onPage(page + 1)}>
        {t("common.next")} →
      </button>
    </nav>
  );
}

export function PageHeader({ title, children }: { title: string; children?: React.ReactNode }) {
  return (
    <div className="page-header">
      <h1>{title}</h1>
      {children && <div className="page-actions">{children}</div>}
    </div>
  );
}
