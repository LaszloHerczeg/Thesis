import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { isApiError } from "@/api";
import { useI18n } from "@/i18n";

export function Loading({ label }: { label?: string }) {
  const { t } = useI18n();
  return (
    <div className="loading" role="status" aria-live="polite">
      <span className="spinner" aria-hidden="true" />
      <span>{label ?? t("common.loading")}</span>
    </div>
  );
}

export function StatusPage({ title, text }: { title: string; text: string }) {
  const { t } = useI18n();
  return (
    <section className="container status-page">
      <h1>{title}</h1>
      <p>{text}</p>
      <Link to="/" className="btn btn-primary">{t("errors.goHome")}</Link>
    </section>
  );
}

export function AccessDenied() {
  const { t } = useI18n();
  return <StatusPage title={t("errors.accessDeniedTitle")} text={t("errors.accessDeniedText")} />;
}

export function NotFound() {
  const { t } = useI18n();
  return <StatusPage title={t("errors.notFoundTitle")} text={t("errors.notFoundText")} />;
}

export function ErrorState({ error, onRetry }: { error: unknown; onRetry?: () => void }) {
  const { t } = useI18n();
  if (isApiError(error) && error.status === 404) return <NotFound />;
  if (isApiError(error) && error.status === 403) return <AccessDenied />;
  if (isApiError(error) && error.status === 401) return <Loading />;
  return (
    <div className="alert alert-error" role="alert">
      <p>{t("errors.loadFailed")}</p>
      {onRetry && (
        <button type="button" className="btn btn-secondary btn-sm" onClick={onRetry}>{t("common.retry")}</button>
      )}
    </div>
  );
}

export function EmptyState({ title, text, action }: { title: string; text?: string; action?: ReactNode }) {
  return (
    <div className="empty">
      <p className="empty-title">{title}</p>
      {text && <p>{text}</p>}
      {action}
    </div>
  );
}

/** Renders loading / error / content for a useAsync state. */
export function DataView<T>({
  state,
  children,
}: {
  state: { data: T | undefined; error: unknown; loading: boolean; reload: () => void };
  children: (data: T) => ReactNode;
}) {
  if (state.error) return <ErrorState error={state.error} onRetry={state.reload} />;
  if (state.loading && state.data === undefined) return <Loading />;
  if (state.data === undefined) return <Loading />;
  return <>{children(state.data)}</>;
}
