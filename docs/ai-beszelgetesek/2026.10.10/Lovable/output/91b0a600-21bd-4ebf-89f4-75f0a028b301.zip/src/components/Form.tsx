import { useId, useState, type ReactNode } from "react";
import { isApiError } from "@/api";
import { useI18n } from "@/i18n";
import { passwordStrength } from "@/lib/password";

export interface FieldA11y {
  id: string;
  "aria-describedby"?: string;
  "aria-invalid"?: boolean;
}

export function Field({
  label,
  hint,
  error,
  optional,
  children,
}: {
  label: ReactNode;
  hint?: ReactNode;
  error?: string | undefined;
  optional?: boolean;
  children: (a11y: FieldA11y) => ReactNode;
}) {
  const { t } = useI18n();
  const id = useId();
  const hintId = `${id}-hint`;
  const errId = `${id}-err`;
  const describedBy = [hint ? hintId : "", error ? errId : ""].filter(Boolean).join(" ");
  const a11y: FieldA11y = { id };
  if (describedBy) a11y["aria-describedby"] = describedBy;
  if (error) a11y["aria-invalid"] = true;
  return (
    <div className={`field ${error ? "field-invalid" : ""}`}>
      <label htmlFor={id} className="label">
        {label} {optional && <span className="optional">{t("common.optional")}</span>}
      </label>
      {hint && <p id={hintId} className="hint">{hint}</p>}
      {children(a11y)}
      {error && (
        <p id={errId} className="error-text" role="alert">
          {error}
        </p>
      )}
    </div>
  );
}

export function CheckboxGroup<T extends string>({
  legend,
  options,
  value,
  onChange,
  error,
  hint,
}: {
  legend: string;
  options: { value: T; label: string }[];
  value: T[];
  onChange: (v: T[]) => void;
  error?: string | undefined;
  hint?: string;
}) {
  const id = useId();
  return (
    <fieldset className={`field fieldset ${error ? "field-invalid" : ""}`} aria-describedby={error ? `${id}-err` : undefined}>
      <legend className="label">{legend}</legend>
      {hint && <p className="hint">{hint}</p>}
      <div className="choice-grid">
        {options.map((o) => (
          <label key={o.value} className="choice">
            <input
              type="checkbox"
              checked={value.includes(o.value)}
              onChange={(e) => onChange(e.target.checked ? [...value, o.value] : value.filter((v) => v !== o.value))}
            />
            <span>{o.label}</span>
          </label>
        ))}
      </div>
      {error && <p id={`${id}-err`} className="error-text" role="alert">{error}</p>}
    </fieldset>
  );
}

export function RadioGroup<T extends string>({
  legend,
  name,
  options,
  value,
  onChange,
  error,
}: {
  legend: string;
  name: string;
  options: { value: T; label: string }[];
  value: T | "";
  onChange: (v: T) => void;
  error?: string | undefined;
}) {
  return (
    <fieldset className={`field fieldset ${error ? "field-invalid" : ""}`}>
      <legend className="label">{legend}</legend>
      <div className="choice-grid">
        {options.map((o) => (
          <label key={o.value} className="choice">
            <input type="radio" name={name} checked={value === o.value} onChange={() => onChange(o.value)} />
            <span>{o.label}</span>
          </label>
        ))}
      </div>
      {error && <p className="error-text" role="alert">{error}</p>}
    </fieldset>
  );
}

export function FormAlert({ message, tone = "error" }: { message: string | null; tone?: "error" | "success" | "info" }) {
  if (!message) return null;
  return (
    <div className={`alert alert-${tone}`} role={tone === "error" ? "alert" : "status"}>
      <p>{message}</p>
    </div>
  );
}

/** Field errors from an ApiError (422 or detail.field_errors). */
export function apiFieldErrors(e: unknown): Record<string, string> {
  return isApiError(e) && e.field_errors ? e.field_errors : {};
}

export function PasswordInput({
  value,
  onChange,
  a11y,
  autoComplete,
}: {
  value: string;
  onChange: (v: string) => void;
  a11y: FieldA11y;
  autoComplete: string;
}) {
  const { t } = useI18n();
  const [show, setShow] = useState(false);
  return (
    <div className="password-wrap">
      <input
        {...a11y}
        className="input"
        type={show ? "text" : "password"}
        value={value}
        autoComplete={autoComplete}
        onChange={(e) => onChange(e.target.value)}
      />
      <button
        type="button"
        className="btn btn-ghost btn-sm password-toggle"
        aria-pressed={show}
        aria-controls={a11y.id}
        onClick={() => setShow((s) => !s)}
      >
        {show ? t("auth.hidePassword") : t("auth.showPassword")}
      </button>
    </div>
  );
}

export function StrengthMeter({ password }: { password: string }) {
  const { t } = useI18n();
  if (!password) return null;
  const { score, common } = passwordStrength(password);
  const label = t(`strength.${score}`);
  return (
    <div className="strength" aria-live="polite">
      <div className="strength-bar" data-score={score} aria-hidden="true">
        {[0, 1, 2, 3].map((i) => (
          <span key={i} className={i < Math.max(1, score) ? "on" : ""} />
        ))}
      </div>
      <p className="hint">
        {t("strength.label")}: <strong>{label}</strong>
        {common && <> – {t("strength.common")}</>}
      </p>
    </div>
  );
}
