import { useNavigate } from "@tanstack/react-router";
import { useEffect, useId, useRef, useState, type KeyboardEvent } from "react";
import { useApp } from "@/context/AppContext";
import { useI18n } from "@/i18n";
import styles from "./Layout.module.css";

/** Profile dropdown: opens on hover, click/tap and keyboard (Enter/Space/↓, arrows, Esc). */
export function ProfileMenu({ username }: { username: string }) {
  const { t } = useI18n();
  const { logout } = useApp();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const wrapRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);
  const itemsRef = useRef<(HTMLButtonElement | null)[]>([]);
  const menuId = useId();

  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, [open]);

  const focusItem = (i: number) => {
    const n = itemsRef.current.length;
    itemsRef.current[((i % n) + n) % n]?.focus();
  };

  const choose = async (action: "cases" | "profile" | "logout") => {
    setOpen(false);
    if (action === "cases") await navigate({ to: "/cases" });
    else if (action === "profile") await navigate({ to: "/profile" });
    else {
      await logout();
      await navigate({ to: "/" });
    }
  };

  const onButtonKey = (e: KeyboardEvent) => {
    if (e.key === "ArrowDown" || e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      setOpen(true);
      requestAnimationFrame(() => focusItem(0));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setOpen(true);
      requestAnimationFrame(() => focusItem(-1));
    }
  };

  const onMenuKey = (e: KeyboardEvent) => {
    const idx = itemsRef.current.findIndex((el) => el === document.activeElement);
    if (e.key === "ArrowDown") { e.preventDefault(); focusItem(idx + 1); }
    else if (e.key === "ArrowUp") { e.preventDefault(); focusItem(idx - 1); }
    else if (e.key === "Home") { e.preventDefault(); focusItem(0); }
    else if (e.key === "End") { e.preventDefault(); focusItem(-1); }
    else if (e.key === "Escape") { e.preventDefault(); setOpen(false); buttonRef.current?.focus(); }
    else if (e.key === "Tab") setOpen(false);
  };

  const items: { key: "cases" | "profile" | "logout"; label: string }[] = [
    { key: "cases", label: t("nav.myCases") },
    { key: "profile", label: t("nav.editProfile") },
    { key: "logout", label: t("nav.logout") },
  ];

  return (
    <div
      ref={wrapRef}
      className={styles.profile}
      onMouseEnter={() => setOpen(true)}
      onMouseLeave={() => setOpen(false)}
    >
      <button
        ref={buttonRef}
        type="button"
        className={styles.profileButton}
        aria-haspopup="menu"
        aria-expanded={open}
        aria-controls={menuId}
        aria-label={t("nav.profileMenu", { name: username })}
        onClick={() => setOpen((o) => !o)}
        onKeyDown={onButtonKey}
      >
        <svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <circle cx="12" cy="8" r="4" />
          <path d="M4 21c0-4 4-6 8-6s8 2 8 6" />
        </svg>
        <span>{username}</span>
        <span aria-hidden="true">▾</span>
      </button>
      <ul id={menuId} role="menu" aria-label={username} className={styles.menu} hidden={!open} onKeyDown={onMenuKey}>
        {items.map((it, i) => (
          <li role="none" key={it.key}>
            <button
              ref={(el) => {
                itemsRef.current[i] = el;
              }}
              type="button"
              role="menuitem"
              tabIndex={-1}
              className={styles.menuItem}
              onClick={() => void choose(it.key)}
            >
              {it.label}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
