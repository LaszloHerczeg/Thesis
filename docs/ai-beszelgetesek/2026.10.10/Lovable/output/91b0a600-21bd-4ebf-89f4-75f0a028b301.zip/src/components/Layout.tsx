import { Link, Outlet, useLocation, useRouter } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { setUnauthorizedHandler } from "@/api";
import { useApp } from "@/context/AppContext";
import { useI18n } from "@/i18n";
import { GlobalNotices } from "./GlobalNotices";
import { Flash } from "./Flash";
import { LanguageSwitcher } from "./LanguageSwitcher";
import { ProfileMenu } from "./ProfileMenu";
import { Loading } from "./DataState";
import styles from "./Layout.module.css";

export function Layout() {
  const { t } = useI18n();
  const { user, ready, bootError, setUser, reload } = useApp();
  const router = useRouter();
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    setUnauthorizedHandler(() => {
      setUser(null);
      const current = router.state.location.pathname;
      if (current.startsWith("/login")) return;
      void router.navigate({ to: "/login", search: { redirect: current } });
    });
    return () => setUnauthorizedHandler(null);
  }, [router, setUser]);

  useEffect(() => setMenuOpen(false), [location.pathname]);

  const isAdmin = user?.role === "admin";
  const navCls = { className: styles.navLink, activeProps: { className: `${styles.navLink} ${styles.active}` } };

  return (
    <div className={styles.shell}>
      <a href="#main" className={styles.skip}>
        {t("nav.skipToContent")}
      </a>
      <header className={styles.header}>
        <div className={`container ${styles.headerInner}`}>
          <Link to="/" className={styles.brand}>
            <span className={styles.brandMark} aria-hidden="true">§</span>
            <span>
              <span className={styles.brandName}>{t("app.name")}</span>
              <span className={styles.brandTag}>{t("app.tagline")}</span>
            </span>
          </Link>
          <button
            type="button"
            className={`btn btn-ghost ${styles.menuToggle}`}
            aria-expanded={menuOpen}
            aria-controls="main-menubar"
            onClick={() => setMenuOpen((o) => !o)}
          >
            ☰ {t("nav.menu")}
          </button>
          <nav id="main-menubar" aria-label={t("nav.mainNav")} className={`${styles.nav} ${menuOpen ? styles.navOpen : ""}`}>
            {isAdmin && (
              <ul className={styles.navList} aria-label={t("nav.adminNav")}>
                <li><Link to="/admin" activeOptions={{ exact: true }} {...navCls}>{t("nav.admin")}</Link></li>
                <li><Link to="/admin/cases" {...navCls}>{t("nav.cases")}</Link></li>
                <li><Link to="/admin/users" {...navCls}>{t("nav.users")}</Link></li>
                <li><Link to="/admin/warnings" {...navCls}>{t("nav.warnings")}</Link></li>
                <li><Link to="/admin/logs" {...navCls}>{t("nav.logs")}</Link></li>
                <li><Link to="/admin/metrics" {...navCls}>{t("nav.metrics")}</Link></li>
              </ul>
            )}
            <div className={styles.navRight}>
              <LanguageSwitcher />
              {ready && !user && (
                <>
                  <Link to="/register" search={{}} className="btn btn-secondary btn-sm">{t("nav.signup")}</Link>
                  <Link to="/login" search={{}} className="btn btn-primary btn-sm">{t("nav.login")}</Link>
                </>
              )}
              {ready && user && <ProfileMenu username={user.username} />}
            </div>
          </nav>
        </div>
      </header>
      <GlobalNotices />
      <Flash />
      <main id="main" tabIndex={-1} className={styles.main}>
        {!ready ? (
          <Loading />
        ) : bootError ? (
          <div className="container">
            <div className="alert alert-error" role="alert">
              <p>{t("errors.network")}</p>
              <button type="button" className="btn btn-secondary btn-sm" onClick={reload}>{t("common.retry")}</button>
            </div>
          </div>
        ) : (
          <Outlet />
        )}
      </main>
      <footer className={styles.footer}>
        <div className={`container ${styles.footerInner}`}>
          <p>{t("footer.rights", { year: new Date().getFullYear() })} · {t("footer.notice")}</p>
          <ul className={styles.footerLinks}>
            <li><Link to="/disclaimer">{t("footer.disclaimer")}</Link></li>
            <li><Link to="/privacy">{t("footer.privacy")}</Link></li>
          </ul>
        </div>
      </footer>
    </div>
  );
}
