import { useState } from "react";
import { casesService, isApiError } from "@/api";
import type { CaseDetail, CriterionMatch, LawyerContact, Recommendation } from "@/api/types";
import { useI18n } from "@/i18n";
import { ShortDisclaimer } from "./Misc";
import styles from "./Recommendations.module.css";

function criterionText(c: CriterionMatch, r: Recommendation, specialty: string, t: ReturnType<typeof useI18n>["t"], i18n: ReturnType<typeof useI18n>): string {
  const l = r.lawyer;
  const value =
    c.criterion === "specialty"
      ? specialty
      : c.criterion === "location"
        ? l.city
        : c.criterion === "language"
          ? l.languages.map(i18n.languageName).join(", ")
          : c.criterion === "format"
            ? l.consultation_formats.map((f) => t(`formats.${f}`)).join(", ")
            : t("common.perHour", { price: i18n.formatCurrency(l.price_per_hour) });
  return t(`wizard.criteria.${c.criterion}`, { value });
}

export function ContactCard({ contact }: { contact: LawyerContact }) {
  const i18n = useI18n();
  const { t } = i18n;
  return (
    <section className={`card ${styles.contact}`} aria-labelledby="contact-title">
      <h3 id="contact-title">{t("wizard.contactTitle", { name: contact.name })}</h3>
      <dl className="dl">
        <dt>{t("wizard.phone")}</dt>
        <dd><a href={`tel:${contact.phone.replace(/[^\d+]/g, "")}`}>{contact.phone}</a></dd>
        <dt>{t("wizard.email")}</dt>
        <dd><a href={`mailto:${contact.email}`}>{contact.email}</a></dd>
        <dt>{t("wizard.address")}</dt>
        <dd>{contact.office_address}</dd>
        {contact.website && (
          <>
            <dt>{t("wizard.website")}</dt>
            <dd><a href={contact.website} target="_blank" rel="noopener noreferrer">{contact.website}</a></dd>
          </>
        )}
        {contact.booking_url && (
          <>
            <dt>{t("wizard.booking")}</dt>
            <dd><a href={contact.booking_url} target="_blank" rel="noopener noreferrer">{contact.booking_url}</a></dd>
          </>
        )}
        <dt>{t("wizard.formats")}</dt>
        <dd>{contact.consultation_formats.map((f) => t(`formats.${f}`)).join(", ")}</dd>
        <dt>{t("wizard.fee")}</dt>
        <dd>{t("common.perHour", { price: i18n.formatCurrency(contact.price_per_hour) })}</dd>
      </dl>
      <p className="hint">{t("wizard.privacyNote")}</p>
    </section>
  );
}

/** Up to three recommendations with ✓/✗ breakdown, choice, contact details and re-do (US-06/07/08). */
export function RecommendationsPanel({ data, onChange }: { data: CaseDetail; onChange: (c: CaseDetail) => void }) {
  const i18n = useI18n();
  const { t } = i18n;
  const [busy, setBusy] = useState<string | null>(null);
  const [inactive, setInactive] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showList, setShowList] = useState(data.choice === null);
  const specialty = data.classification?.category?.plain_name ?? "";

  const choose = async (r: Recommendation) => {
    setBusy(r.id);
    setError(null);
    setInactive(false);
    try {
      const updated = await casesService.chooseLawyer(data.id, r.id);
      onChange(updated);
      setShowList(false);
    } catch (e) {
      if (isApiError(e) && e.code === "lawyer_inactive") {
        setInactive(true);
        onChange({ ...data, recommendations: data.recommendations.map((x) => (x.id === r.id ? { ...x, lawyer_active: false } : x)) });
      } else setError(t("errors.generic"));
    } finally {
      setBusy(null);
    }
  };

  const redo = async () => {
    setBusy("redo");
    setError(null);
    try {
      const updated = await casesService.recommend(data.id);
      setInactive(false);
      setShowList(true);
      onChange(updated);
    } catch {
      setError(t("wizard.analysisErrorTitle"));
    } finally {
      setBusy(null);
    }
  };

  const choiceInactive = data.choice !== null && data.recommendations.some((r) => r.id === data.choice?.recommendation_id && !r.lawyer_active);

  if (data.choice && !showList) {
    return (
      <div className="stack">
        {choiceInactive && (
          <div className="alert alert-warning" role="alert">
            <p>{t("wizard.inactiveNote")}</p>
          </div>
        )}
        <ContactCard contact={data.choice.contact} />
        <ShortDisclaimer withGuarantee />
        <div className="row">
          <button type="button" className="btn btn-secondary" onClick={() => setShowList(true)}>
            {t("wizard.changeChoice")}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="stack">
      {inactive && (
        <div className="alert alert-warning" role="alert">
          <p><strong>{t("wizard.lawyerInactiveTitle")}</strong></p>
          <p>{t("wizard.lawyerInactiveText")}</p>
          <button type="button" className="btn btn-primary btn-sm" disabled={busy !== null} onClick={() => void redo()}>
            {busy === "redo" ? t("common.working") : t("wizard.redo")}
          </button>
        </div>
      )}
      {error && <div className="alert alert-error" role="alert"><p>{error}</p></div>}
      {data.recommendations.length === 0 && <div className="alert alert-info"><p>{t("wizard.noLawyers")}</p></div>}
      {data.recommendations.length > 0 && data.recommendations.length < 3 && (
        <p className="hint">{t("wizard.fewer", { count: data.recommendations.length })}</p>
      )}
      <ol className={styles.list}>
        {data.recommendations.map((r) => {
          const chosen = data.choice?.recommendation_id === r.id;
          return (
            <li key={r.id} className={`card ${styles.item} ${chosen ? styles.chosen : ""}`}>
              <div className={styles.itemHead}>
                <span className={styles.rank}>{t("wizard.rank", { rank: r.rank })}</span>
                {chosen && <span className="badge badge-lawyer_chosen">{t("wizard.chosenBadge")}</span>}
              </div>
              <h3 className={styles.name}>{r.lawyer.name}</h3>
              <p className={styles.summary}>{r.summary}</p>
              <h4 className={styles.whyTitle}>{t("wizard.whyTitle")}</h4>
              <ul className={styles.criteria}>
                {r.criteria.map((c) => (
                  <li key={c.criterion} className={c.matched ? styles.met : styles.notMet}>
                    <span aria-hidden="true">{c.matched ? "✓" : "✗"}</span>{" "}
                    <span className="sr-only">{c.matched ? t("wizard.criterionMet") : t("wizard.criterionNotMet")}: </span>
                    {criterionText(c, r, specialty, t, i18n)}
                  </li>
                ))}
              </ul>
              {!r.lawyer_active ? (
                <p className="alert alert-warning">{t("wizard.inactiveNote")}</p>
              ) : (
                <button type="button" className="btn btn-primary" disabled={busy !== null || chosen} onClick={() => void choose(r)}>
                  {busy === r.id ? t("common.working") : chosen ? t("wizard.chosenBadge") : t("wizard.choose")}
                </button>
              )}
            </li>
          );
        })}
      </ol>
      {data.choice && (
        <div className="row">
          <button type="button" className="btn btn-secondary" onClick={() => setShowList(false)}>{t("common.back")}</button>
        </div>
      )}
      {!inactive && data.recommendations.some((r) => !r.lawyer_active) && (
        <div className="row">
          <button type="button" className="btn btn-secondary" disabled={busy !== null} onClick={() => void redo()}>
            {busy === "redo" ? t("common.working") : t("wizard.redo")}
          </button>
        </div>
      )}
    </div>
  );
}
