import { useI18n } from "@/i18n";
import styles from "./Layout.module.css";

export function LanguageSwitcher() {
  const { lang, setLang, t } = useI18n();
  return (
    <div role="group" aria-label={t("nav.language")} className={styles.lang}>
      {(["hu", "en"] as const).map((l) => (
        <button
          key={l}
          type="button"
          lang={l}
          aria-pressed={lang === l}
          className={`${styles.langBtn} ${lang === l ? styles.langActive : ""}`}
          onClick={() => setLang(l)}
        >
          {l === "hu" ? "Magyar" : "English"}
        </button>
      ))}
    </div>
  );
}
