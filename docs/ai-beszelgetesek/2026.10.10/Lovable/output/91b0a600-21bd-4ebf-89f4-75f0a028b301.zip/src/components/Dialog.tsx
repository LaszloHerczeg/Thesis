import { useEffect, useId, useRef, type ReactNode } from "react";
import { useI18n } from "@/i18n";
import styles from "./Dialog.module.css";

/** Accessible modal on native <dialog>: focus trap, Esc to close, focus restored. */
export function Dialog({
  open,
  title,
  onClose,
  children,
  actions,
}: {
  open: boolean;
  title: string;
  onClose: () => void;
  children: ReactNode;
  actions: ReactNode;
}) {
  const { t } = useI18n();
  const ref = useRef<HTMLDialogElement>(null);
  const titleId = useId();
  const lastFocus = useRef<HTMLElement | null>(null);

  useEffect(() => {
    const d = ref.current;
    if (!d) return;
    if (open && !d.open) {
      lastFocus.current = document.activeElement as HTMLElement | null;
      d.showModal();
    } else if (!open && d.open) {
      d.close();
      lastFocus.current?.focus();
    }
  }, [open]);

  return (
    <dialog
      ref={ref}
      className={styles.dialog}
      aria-labelledby={titleId}
      onCancel={(e) => {
        e.preventDefault();
        onClose();
      }}
    >
      <div className={styles.head}>
        <h2 id={titleId}>{title}</h2>
        <button type="button" className="btn btn-ghost btn-sm" aria-label={t("common.close")} onClick={onClose}>✕</button>
      </div>
      <div className={styles.body}>{children}</div>
      <div className={styles.actions}>{actions}</div>
    </dialog>
  );
}
