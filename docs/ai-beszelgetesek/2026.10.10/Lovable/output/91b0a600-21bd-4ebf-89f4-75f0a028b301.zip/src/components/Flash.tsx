import { useEffect, useState } from "react";
import { setFlash, subscribeFlash } from "@/lib/flash";
import { useI18n } from "@/i18n";

export function Flash() {
  const { t } = useI18n();
  const [msg, setMsg] = useState<string | null>(null);
  useEffect(() => subscribeFlash(setMsg), []);
  useEffect(() => {
    if (!msg) return;
    const id = setTimeout(() => setFlash(null), 7000);
    return () => clearTimeout(id);
  }, [msg]);
  return (
    <div aria-live="polite" className="container">
      {msg && (
        <div className="alert alert-success notice" role="status">
          <p>{msg}</p>
          <button type="button" className="btn btn-ghost btn-sm" aria-label={t("errors.dismiss")} onClick={() => setFlash(null)}>✕</button>
        </div>
      )}
    </div>
  );
}
