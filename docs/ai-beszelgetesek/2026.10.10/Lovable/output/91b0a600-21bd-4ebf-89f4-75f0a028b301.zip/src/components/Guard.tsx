import { useLocation, useRouter } from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";
import type { Role } from "@/api/types";
import { useApp } from "@/context/AppContext";
import { AccessDenied, Loading } from "./DataState";

/**
 * Convenience route guard (the server enforces access).
 * - visitors on screening pages → registration with explanation (US-18)
 * - visitors elsewhere → log-in, remembering the page (US-27)
 * - wrong role → "Access denied"
 */
export function RequireAuth({ role, screening = false, children }: { role?: Role; screening?: boolean; children: ReactNode }) {
  const { user } = useApp();
  const router = useRouter();
  const current = useLocation({ select: (l) => l.pathname });

  useEffect(() => {
    if (user) return;
    if (screening) void router.navigate({ to: "/register", search: { from: "screening", redirect: current } });
    else void router.navigate({ to: "/login", search: { redirect: current } });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  if (!user) return <Loading />;
  if (role && user.role !== role) return <AccessDenied />;
  return <>{children}</>;
}

/** Only allow same-site relative redirects. */
export function safeRedirect(target: string | undefined): string | null {
  return target && target.startsWith("/") && !target.startsWith("//") ? target : null;
}
