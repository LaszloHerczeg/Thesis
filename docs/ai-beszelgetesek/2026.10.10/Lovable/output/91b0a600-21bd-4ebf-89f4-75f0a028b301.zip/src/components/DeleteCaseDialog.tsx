import { useState } from "react";
import { casesService } from "@/api";
import { useI18n } from "@/i18n";
import { Dialog } from "./Dialog";

export function DeleteCaseDialog({
  target,
  onClose,
  onDeleted,
}: {
  target: { id: string; created_at: string; title: string } | null;
  onClose: () => void;
  onDeleted: () => void;
}) {
  const { t, formatDate } = useI18n();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const confirm = async () => {
    if (!target) return;
    setBusy(true);
    setError(null);
    try {
      await casesService.remove(target.id);
      onDeleted();
    } catch {
      setError(t("errors.generic"));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog
      open={target !== null}
      title={t("deleteCase.title")}
      onClose={onClose}
      actions={
        <>
          <button type="button" className="btn btn-secondary" onClick={onClose}>{t("common.cancel")}</button>
          <button type="button" className="btn btn-danger" disabled={busy} onClick={() => void confirm()}>
            {busy ? t("common.working") : t("deleteCase.confirm")}
          </button>
        </>
      }
    >
      {target && (
        <>
          <p>{t("deleteCase.text", { date: formatDate(target.created_at), title: target.title })}</p>
          <p><strong>{t("deleteCase.willDelete")}</strong></p>
          <ul>
            {(["item1", "item2", "item3", "item4", "item5", "item6"] as const).map((k) => (
              <li key={k}>{t(`deleteCase.${k}`)}</li>
            ))}
          </ul>
          <p className="alert alert-warning">{t("deleteCase.irreversible")}</p>
          {error && <p className="error-text" role="alert">{error}</p>}
        </>
      )}
    </Dialog>
  );
}
