/**
 * Central runtime configuration. Only this file reads environment variables.
 * Switching to the real FastAPI backend only requires changing
 * VITE_API_BASE_URL and VITE_USE_MOCKS (see .env.example).
 *
 * Tunable business values (description length, question limits, page sizes,
 * password length, inactivity timeout …) are NOT here: they are loaded from
 * GET /config at start-up (see src/api/services/config.ts).
 */

const env: Record<string, unknown> = import.meta.env;

function readString(key: string, fallback: string): string {
  const value = env[key];
  return typeof value === "string" && value.trim() !== "" ? value.trim() : fallback;
}

function readBool(key: string, fallback: boolean): boolean {
  const value = env[key];
  if (typeof value !== "string" || value.trim() === "") return fallback;
  return value.trim().toLowerCase() === "true";
}

export const config = {
  /** Base URL of the backend API, e.g. http://localhost:8000/api/v1 */
  apiBaseUrl: readString("VITE_API_BASE_URL", "http://localhost:8000/api/v1").replace(/\/+$/, ""),
  /** When true every request is answered by the in-browser mock server. */
  useMocks: readBool("VITE_USE_MOCKS", true),
  /** Header that carries the CSRF token on POST/PUT/PATCH/DELETE requests. */
  csrfHeaderName: "X-CSRF-Token",
  /** Endpoint that issues a CSRF token: returns { csrf_token }. */
  csrfEndpoint: "/auth/csrf",
  /** Simulated latency of the mock server, in milliseconds. */
  mockDelayMs: { min: 300, max: 800 },
  /** sessionStorage key of the mock database (the only browser-stored data). */
  mockStorageKey: "lpslm-mock-db-v1",
} as const;
