<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Architecture rules
- All data access goes through `src/api/services/*` → `src/api/http.ts`; pages never call fetch or import mocks. Why: swapping mock ↔ FastAPI must not touch UI code.
- Mocks are a transport swap inside `http.ts` (`src/api/mock/server.ts`), selected by `config.useMocks`. Why: the same wrapper (CSRF, error mapping, 401/429 handling) is exercised in both modes.
- API types in `src/api/types.ts` use backend snake_case names. Why: no mapping layer when the real backend arrives.
- `src/config.ts` is the only reader of env vars; tunable business values come from GET /config. Why: no hard-coded tunables in components.
- Styling is plain CSS: tokens in `src/styles/global.css` + CSS Modules with generated `.module.css.d.ts` (`scripts/gen-css-types.py`). Why: brief forbids Tailwind/CSS-in-JS and TS config disallows index-signature access.
- All UI text lives in `src/i18n/{hu,en}.ts`; en is typed against hu. Why: missing translations fail the typecheck.
- The root route is `ssr: false` (client-only SPA). Why: session is a backend cookie and the mock DB lives in sessionStorage.
