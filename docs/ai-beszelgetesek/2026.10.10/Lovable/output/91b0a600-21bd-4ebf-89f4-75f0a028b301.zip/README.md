# Jogútmutató – Legal Problem Screening & Lawyer Matching (frontend)

Frontend only. Every request goes through `src/api/http.ts`; by default an in-browser mock server answers. A Python FastAPI backend can replace the mocks without touching pages or components.

## Setup

```bash
bun install        # or npm install
cp .env.example .env
bun run dev        # http://localhost:8080
bun run test
```

Stack: React 19 + TypeScript (strict), TanStack Router/Start in client-only (SPA) mode, plain CSS (one global stylesheet `src/styles/global.css` with custom properties + CSS Modules). After adding or renaming classes in a `*.module.css`, run `python3 scripts/gen-css-types.py` to refresh its typed `.d.ts`.

## Switching from mocks to the real API

Edit `.env`:

```
VITE_API_BASE_URL=https://your-api.example.com/api/v1
VITE_USE_MOCKS=false
```

That's all. The backend must:
- set an **HttpOnly session cookie** (requests use `credentials: "include"`; allow CORS with credentials for the frontend origin);
- issue CSRF tokens at `GET /auth/csrf` → `{ "csrf_token": "..." }` and verify the `X-CSRF-Token` header on POST/PUT/PATCH/DELETE, answering `403 {"detail":{"code":"csrf_invalid"}}` when invalid (the client refetches and retries once);
- return errors as `{"detail": {"code","message","field_errors"?, ...}}` or FastAPI's standard 422 `{"detail":[{"loc":[...],"msg":"..."}]}`;
- send `Retry-After` with 429.

Business values (description length, questions per round, max rounds, page sizes, password length, inactivity timeout, retention) come from `GET /config`.

### How the mock works
`config.useMocks` swaps the **transport** inside `http.ts` (fetch ↔ `src/api/mock/server.ts`). The mock server receives the same method/path/query/headers/body, enforces the same rules (auth, roles, ownership → 404, CSRF, validation 422, duplicates, banned e-mails, leaked passwords, lockout, inactivity timeout, account status) and persists its database in `sessionStorage`. Handlers are organised per area in `src/api/mock/handlers/` (auth, account, catalog, cases, admin, metrics). Services in `src/api/services/` are the only API pages use.

Test hooks:
- A description containing `[teszt:hiba]` or `[test:fail]` makes the first classification fail with 503 → shows the US-38 "Try again" error.
- *Dr. Balogh Tamás* is deactivated after seed recommendations were made → open the "Recommendations ready" case of `kovacs_anna` to see the inactive-lawyer note and "Re-do recommendation".
- 5 wrong passwords in a row lock that account for 2 minutes.
- Reset mock data: clear the browser tab's sessionStorage (or close the tab).

## Mock test accounts

| Username | Password | Role / state |
|---|---|---|
| `kovacs_anna` (anna.kovacs@example.hu) | `Tavaszi-szel-2026` | client, cases in every status |
| `admin_peter` (peter.admin@example.hu) | `Biztonsagos-Admin-2026` | admin |
| `nagy_bela` | `Teszt-jelszo-2026` | client (owns a case others must get 404 for) |
| `felfuggesztett_feri` | `Teszt-jelszo-2026` | suspended by admin (with end date) |
| `auto_zsuzsa` | `Teszt-jelszo-2026` | suspended automatically |
| `kitiltott_karoly` | `Teszt-jelszo-2026` | banned |

Banned e-mails: `karoly@example.hu`, `spam@example.com`, `tiltott@example.hu`. Leaked passwords include `password`, `12345678`, `jelszo123`, `qwertzui`.

## Endpoints (basis for the OpenAPI spec, US-17)

All paths are relative to `VITE_API_BASE_URL`. Types are in `src/api/types.ts` (snake_case, ISO 8601 dates, UUID ids). Every state-changing request requires `X-CSRF-Token`. Common errors: **401** not logged in / session expired, **403** wrong role or `csrf_invalid`, **404** missing or not owned, **422** validation, **429** rate limited (`Retry-After`), **5xx** server error.

Roles: V = visitor (public), C = logged-in client or admin, A = admin only.

### Config & auth
| Method | Path | Role | Request | Response | Errors |
|---|---|---|---|---|---|
| GET | `/config` | V | – | `AppSettings` | 5xx |
| GET | `/auth/csrf` | V | – | `CsrfResponse` | 5xx |
| GET | `/auth/me` | C | – | `User` | 401 |
| POST | `/auth/register` | V | `RegisterRequest` | 201 `User` + session cookie | 409 (`conflict`: duplicate username/email, `field_errors`), 422 (validation / `email_banned` / leaked password), 429 |
| POST | `/auth/login` | V | `LoginRequest` | `User` + session cookie | 401 `invalid_credentials` (generic), 403 `account_suspended`/`account_suspended_auto`/`account_banned` with `status`, `suspended_until` (only after correct password), 429 `login_locked` |
| POST | `/auth/logout` | V | – | 204, session ended server-side | – |
| POST | `/auth/password-reset` | V | `PasswordResetRequest` | 202 `{message}` (placeholder, US-51) | 422, 429 |

### Account
| Method | Path | Role | Request | Response | Errors |
|---|---|---|---|---|---|
| PATCH | `/account/profile` | C | `ProfileUpdateRequest` (`current_password` required when email changes) | `User` | 401, 409, 422 |
| POST | `/account/password` | C | `PasswordChangeRequest` | 204 (other sessions ended) | 401, 422 |
| POST | `/account/consent` | C | `ConsentRequest` | `User` | 401, 422 |
| GET | `/account/export` | C | – | `DataExport` | 401 |
| DELETE | `/account` | C | `AccountDeleteRequest` | 204 | 401, 422 |

### Categories & lawyers (client side)
| Method | Path | Role | Request | Response | Errors |
|---|---|---|---|---|---|
| GET | `/categories` | V | – | `CategoryList` (active, current taxonomy version) | – |
| GET | `/lawyers?category_id&city&page&page_size` | C | – | `Page<LawyerPublic>` (no contact data) | 401 |

### Cases / screening (owner only; other users' cases → 404)
| Method | Path | Role | Request | Response | Errors |
|---|---|---|---|---|---|
| GET | `/cases?status&category_id&page&page_size` | C | – | `Page<CaseSummary>` newest first | 401 |
| POST | `/cases` | C | `CreateCaseRequest` | 201 `CaseDetail` (step `documents`) | 401, 403 `consent_required`, 422 |
| GET | `/cases/{case_id}` | C | – | `CaseDetail` (unmasked) | 401, 404 |
| DELETE | `/cases/{case_id}` | C | – | 204 | 401, 404 |
| POST | `/cases/{case_id}/documents` | C | multipart `file` | 201 `CaseDocument` with extracted fields | 401, 404, 422 (type/size), 5xx |
| PUT | `/cases/{case_id}/documents/{document_id}/confirm` | C | `DocumentConfirmRequest` | `CaseDocument` | 401, 404, 422 |
| DELETE | `/cases/{case_id}/documents/{document_id}` | C | – | 204 | 401, 404 |
| POST | `/cases/{case_id}/questions` | C | – | `CaseDetail` with next open round | 401, 404, 409 `max_rounds_reached`, 5xx |
| POST | `/cases/{case_id}/questions/{round}/answers` | C | `AnswersRequest` (skipped = `status:"not_answered"`, `value:null`) | `CaseDetail` (step `classification`) | 401, 404, 422 |
| POST | `/cases/{case_id}/classify` | C | – | `CaseDetail`; `classification.result` = `classified` → step `preferences`, `needs_more_info` → new round, `not_supported` → status `unclassified` | 401, 404, 503 `analysis_failed` |
| PUT | `/cases/{case_id}/preferences` | C | `Preferences` | `CaseDetail` | 401, 404, 409 `not_classified`, 422 |
| POST | `/cases/{case_id}/recommendations` | C | – | `CaseDetail` with ≤3 `Recommendation` (clears choice; also "re-do") | 401, 404, 409 `preferences_missing`, 5xx |
| POST | `/cases/{case_id}/choice` | C | `ChoiceRequest` | `CaseDetail` with `choice.contact` | 401, 404, 409 `lawyer_inactive`, 422 |

### Admin
| Method | Path | Role | Request | Response | Errors |
|---|---|---|---|---|---|
| GET | `/admin/dashboard` | A | – | `AdminDashboard` | 401, 403 |
| GET | `/admin/lawyers?q&category_id&city&language&format&active&page&page_size` | A | – | `Page<Lawyer>` | 401, 403 |
| GET | `/admin/lawyers/{lawyer_id}` | A | – | `Lawyer` | 401, 403, 404 |
| POST | `/admin/lawyers` | A | `LawyerInput` | 201 `Lawyer` | 401, 403, 422 |
| PUT | `/admin/lawyers/{lawyer_id}` | A | `LawyerInput` | `Lawyer` | 401, 403, 404, 422 |
| GET | `/admin/categories` | A | – | `AdminCategoryList` | 401, 403 |
| GET | `/admin/categories/versions` | A | – | `TaxonomyVersion[]` | 401, 403 |
| POST | `/admin/categories` | A | `CategoryInput` | 201 `AdminCategory` (new taxonomy version) | 401, 403, 422 |
| PUT | `/admin/categories/{category_id}` | A | `CategoryInput` | `AdminCategory` | 401, 403, 404, 409 `category_in_use` (+`lawyers`), 422 |
| DELETE | `/admin/categories/{category_id}` | A | – | 204 | 401, 403, 404, 409 `category_in_use` (+`lawyers`) |
| GET | `/admin/cases?q&category_id&status&date_from&date_to&confidence_max&lawyer_id&has_documents&sort&order&page&page_size` | A | – | `Page<AdminCaseRow>` (`sort` ∈ created_at, case_number, username, category, status, chosen_lawyer, updated_at) | 401, 403 |
| GET | `/admin/cases/{case_id}` | A | – | `AdminCaseDetail` (masked, no files; opening is logged) | 401, 403, 404 |
| GET | `/admin/metrics/evaluations` | A | – | `EvaluationRun[]` | 401, 403 |
| GET | `/admin/metrics/evaluations/{run_id}` | A | – | `EvaluationRunDetail` | 401, 403, 404 |
| POST | `/admin/metrics/evaluations` | A | – | 201 `EvaluationRunDetail` | 401, 403 |

No endpoint creates, promotes or demotes administrators (US-14 is a server-side script).

## Folder structure

```
src/api            http.ts (single fetch wrapper), types.ts, services/*, index.ts
src/api/mock       in-browser mock server: db, seed, engine, handlers/*
src/pages          page components (public, auth, screening wizard, cases, profile, admin)
src/components     layout, menubar, profile menu, dialog, form fields, recommendations…
src/i18n           hu.ts (default), en.ts, provider with Intl formatting
src/styles         global.css (tokens + primitives)
src/routes         thin TanStack route files (URL → page)
src/config.ts      the only file reading env variables
```
